function [def_int]=termstructuredefint(cdstermstruc, zerotermstruc, deffreq, spreadfreq, RR)
%function to bootstrap the default intensities (lambda) under the  assumption of piecewise constant default intensities
%inputs: cdstermstructure: term structure of cds having maturities (in months) in the first column and CDS spreads (in bps) in the second column
% zerotermstruc: term structure of risk free zero coupon bond rates having  maturities (in months) in the first column and zero rates in the second
% column
% deffreq: frequency (in months) at which default can occur (e.g. 1=once a month)
% spreadfreq: frequency (in months) at which spreads are paid
% RR: recovery rate (e.g. 0.4)

Nspreads=length(cdstermstruc(:,1));
def_int=zeros(Nspreads,1);

for i=1:Nspreads
    T=cdstermstruc(i,1);
    mT=T/deffreq;
    nT=T/spreadfreq;
    def_intensity=fzero(@(x) myfun(x, mT, nT, deffreq, spreadfreq, RR, zerotermstruc, cdstermstruc, def_int, i), 0.07); 
    def_int(i,1)=def_intensity
end

function diffspread=myfun(x, mT, nT, deffreq, spreadfreq, RR, zerotermstruc, cdstermstruc, def_int, i)
%function to minimize: difference between market spread and fair spread
    for m=1:mT
       tm=m*deffreq;
       indx1=min(find(zerotermstruc(:,1)>=tm));
       zerodf(m,1)=exp(-zerotermstruc(indx1,2)*tm/12);
       indx2=min(find(cdstermstruc(:,1)>=tm));
       if indx2==1
            probdef=exp(-x*tm/12);
       else
            probdef=exp(-x*(tm/12-cdstermstruc((indx2-1),1)/12));
            indx2=indx2-1;
            while indx2>0
                if indx2==1
                    probdef=probdef*exp(-def_int(indx2)*cdstermstruc(indx2,1)/12);
                else
                    probdef=probdef*exp(-def_int(indx2)*(cdstermstruc(indx2,1)-cdstermstruc((indx2-1),1))/12);
                end
                indx2=indx2-1;
            end
       end
       probdefv(m,1)=probdef;
       if m==1
           defprobvec(m,1)=1-probdef;
       else
           defprobvec(m,1)=probdefv(m-1,1)-probdefv(m,1);
       end       
    end
    numerator=(1-RR)*sum(zerodf.*defprobvec);       %numerator of fair CDS spread calculation
    
    for n=1:nT
       tn=n*spreadfreq;
       indx1=min(find(zerotermstruc(:,1)>=tn));
       zerodf2(n,1)=exp(-zerotermstruc(indx1,2)*tn/12);
       indx2=min(find(cdstermstruc(:,1)>=tn));
       if indx2==1
            probdef=exp(-x*tn/12);
       else
            probdef=exp(-x*(tn/12-cdstermstruc((indx2-1),1)/12));
            indx2=indx2-1;
            while indx2>0
                if indx2==1
                    probdef=probdef*exp(-def_int(indx2)*cdstermstruc(indx2,1)/12);
                else
                    probdef=probdef*exp(-def_int(indx2)*(cdstermstruc(indx2,1)-cdstermstruc((indx2-1),1))/12);
                end
                indx2=indx2-1;
            end
       end
       probdefv2(n,1)=probdef;
       if n==1
           probvec(n,1)=probdef+0.5*(1-probdef);
       else
           probvec(n,1)=probdefv2(n,1)+0.5*(probdefv2(n-1,1)-probdefv2(n,1));
       end       
    end
    denominator=(spreadfreq/12)*sum(zerodf2.*probvec);      %denominator (RPV01)
    diffspread=(cdstermstruc(i,2)/10000)-numerator/denominator;
    