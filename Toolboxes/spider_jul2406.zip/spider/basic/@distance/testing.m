
function d = testing(a,d)
  
  d=set_x(d,feval('get_kernel',a,d,a.dat)); 
