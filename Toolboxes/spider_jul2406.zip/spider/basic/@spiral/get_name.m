function s=get_name(a)

s=[get_name(a.algorithm)];
eval_name


s=[s ' m=' num2str(a.m)];      
if a.n~=30          s=[s ' n='  num2str(a.n)];      end;