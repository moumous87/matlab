function [ind,fInd] = get_index(dat),
  ind= dat.index;
  fInd = dat.findex;
