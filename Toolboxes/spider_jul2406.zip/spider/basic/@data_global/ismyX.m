function ret = ismyX(dat),
  ret=0;
  if ~isempty(dat.myX),
    ret=1;
  end
