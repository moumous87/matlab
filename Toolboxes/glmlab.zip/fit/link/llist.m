lid.m
llog.m
lrecip.m
lsqroot.m
lpower.m
llogit.m
lprobit.m
lcomplog.m
%Add the names of your own link functions AFTER THIS LINE
%The names of the files MUST be in the form:  lname.m
%or you'll get a whole stack of errors.
%And while I'm at it, DON'T CHANGE ANYTHING IN THIS FILE
%BEFORE THESE COMMENTS, or things will probably go wonky.
