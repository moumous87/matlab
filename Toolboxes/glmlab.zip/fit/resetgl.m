%RESETGL  Resets the glmlab user data properties

%Copyright 1997 Peter Dunn
%01 August 1997

set(findobj('tag','glmlab_main'),'UserData',GLMLAB_INFO_);
