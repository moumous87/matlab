%Just a dummy file to find that data diretory quickly

%Copyright 1996 Peter Dunn
%11/11/1996
