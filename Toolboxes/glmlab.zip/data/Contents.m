% GLMLAB: fitting generalised linear models
% Version 2.2, March 1998.
% Copyright 1996--1998 Peter Dunn
%
%In the /data directory:
% Contents:      a help file for the contents of the directory
% chemical.hlp:  A file explaining  chemical.mat
% chemical.mat:  The data from Example 3.2 of `Learning glmlab'
% dummydta.m:    A file to quickly find the data directory
% loadme.hlp:    A file explaining  loadme.mat
% loadme.mat:    An example data set (see section 2.3 of `Learning glmlab')
% leuk.hlp:      A file explaining  leuk.mat
% leuk.mat:      An example data set
% tester.hlp:    A file explaining  tester.txt
% tester.txt:    An example data set (see section 2.3 of `Learning glmlab')
% turkey.hlp:    A file explaining  turkeys.mat.
% turkeys.mat:   The data from Example 3.1 of `Learning glmlab'
