%Just a dummy file to find that model directory quickly

%Copyright 1997 Peter Dunn
%28 August 1997

