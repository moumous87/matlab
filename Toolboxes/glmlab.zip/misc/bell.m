%BELL Issues a warning sound (bell sound?)

%Copyright 1996 Peter Dunn
%November 11 199

disp(setstr(7));
