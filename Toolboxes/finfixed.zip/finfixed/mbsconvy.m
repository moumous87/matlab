function Convexity = mbsconvy(Yield, Settle, Maturity, IssueDate, ...
       GrossRate, varargin)
%MBSCONVY Convexity of passthrough given yield.
%    Modified Convexity of NMBS number of mortgage pool given mortgage
%    yields and prepayment assumptions. 
%
%    Convexity = mbsconvy(Yield, Settle, Maturity, IssueDate, GrossRate)
%    Convexity = mbsconvy(Yield, Settle, Maturity, IssueDate, GrossRate, ...
%       CouponRate)
%    Convexity = mbsconvy(Yield, Settle, Maturity, IssueDate, GrossRate, ...
%       CouponRate, Delay)
%    Convexity = mbsconvy(Yield, Settle, Maturity, IssueDate, GrossRate, ...
%       CouponRate, Delay, PrepaySpeed)  
%    Convexity = mbsconvy(Yield, Settle, Maturity, IssueDate, GrossRate, ...
%       CouponRate, Delay, [], PrepayMatrix)
%
%    Optional Inputs: CouponRate, Delay, PrepaySpeed, PrepayMatrix
%
%    Inputs:
%            Yield - NMBSx1 vector of mortgage yields, in decimal and 
%                    monthly compounded.
%
%           Settle - NMBSx1 vector of Settlement Date.
%
%         Maturity - NMBSx1 vector of Maturity Date.
%
%        IssueDate - NMBSx1 vector of Issue Date.
%
%        GrossRate - NMBSx1 vector of Gross Coupon Rate, in decimal.
%
%    Optional Inputs:
%      CouponRate  - NMBSx1 vector of Net Coupon Rate, in decimal.
%                    Default is equal to GrossRate.
%
%           Delay  - NMBSx1 vector of delay in days.
%
%     PrepaySpeed  - NMBSx1 vector of speed relative to PSA standard. PSA
%                    standard is 100. 
%                    Default is 0 (zero) prepayment speed.
%
%     PrepayMatrix - Customized prepayment vector. A matrix of size
%                    [max(TermRemaining) x NMBS]. Missing values are padded
%                    with NaNs.  Each column corresponds to each MBS, and
%                    each row corresponds to each month after settlement.
%
%    Outputs:
%        Convexity - Periodic convexity of mortgage pool
%
%    Example:
%      Yield = 0.0729841;
%      Settle    = '15-Apr-2002';
%      Maturity  = '01 Jan 2030';
%      IssueDate = '01-Jan-2000';
%      GrossRate = 0.08125;
%      CouponRate = 0.075;;
%      Delay = 14;
%      Speed = 100;
%
%      Convexity = mbsconvy(Yield, Settle, Maturity, IssueDate, ...
%                      GrossRate, CouponRate, Delay, Speed)
%
%      Convexity = 
%          71.6299
%
%   See also MBSCONVP, MBSDURY, MBSDURP
%
%   Note: This function is PSA compliant.
%   Reference: PSA Uniform Practices, SF-49

%   Copyright 2002-2005 The MathWorks, Inc.
%   $Revision: 1.6.6.8 $  $Date: 2008/02/02 13:05:46 $

if nargin > 9
    error('finfixed:mbsconvy:invalidMoreInputs',...
        'Too many input arguments.');
end

if nargin < 5
    error('finfixed:mbsconvy:invalidLessInputs',...
        'Need at least Yield, Settle, Maturity, IssueDate, and GrossRate.');
    
else
    MEY = Yield;
end


% convert the monthly yield to semi-annual yield 
BEY = 2*((1+MEY/12).^6 - 1);

% Calculate the clean price and accrued interest
[Price, AccrInt, CFlowAmounts, TFactors] = mbsprice(MEY, Settle, ...
    Maturity, IssueDate, GrossRate, varargin{1:end});

% expand Yield to correct size
[BEY, dummy] = finargsz(1,BEY(:), Price); %#ok

% Annualized time
TFactors = TFactors/12;
NumCF = size(CFlowAmounts,2);

% Calculate dirty price
P = (Price + AccrInt)/100;

% Calculate convexity based on PSA Uniform Practices, SF-49
Convexity = 1./(P.*(1+BEY/2).^2) .* ...
    (sum((TFactors.*(TFactors+0.5).*CFlowAmounts./...
    ((1+BEY(:,ones(NumCF,1))/2).^(2.*TFactors))), 2));


% [EOF]
