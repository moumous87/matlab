function ForwardRate = nelsonsiegelforward(t,theta)
%NELSONSIEGELFORWARD Evaluates Nelson Siegel equation for the Forward Rate
%
%   ForwardRate = nelsonsiegelforward(t,theta)
%
%   Inputs:
%   t: Time To Maturity
%   theta: 1 x 4 vector of parameters (Beta0, Beta1, Beta2, Tau1)
%          for the Nelson Siegel equation
%
%   Outputs:
%   ForwardRate: Forward Rate for each of the input Time To Maturities
%
%   See also NELSONSIEGELZERO

% Reference:
%    Nelson, C.R., Siegel, A.F., (1987), "Parsimonious modelling of yield
%     curves", Journal of Business, 60, pp 473-89 

%   Copyright 2008 The MathWorks, Inc.
%   $Revision: 1.1.6.1 $  $Date: 2008/05/12 21:25:29 $

Beta0 = theta(1);
Beta1 = theta(2);
Beta2 = theta(3);
Tau1 = theta(4);

ForwardRate = Beta0 + Beta1*(exp(-t/Tau1)) + Beta2*(t/Tau1).*(exp(-t/Tau1));
ForwardRate(t == 0) = Beta0 + Beta1;
ForwardRate = ForwardRate/100;