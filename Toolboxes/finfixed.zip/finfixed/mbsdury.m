function [YearDuration,ModDuration] = mbsdury(Yield, Settle, Maturity, ...
    IssueDate, GrossRate, varargin)
%MBSDURY Macaulay and Modified duration given yield to maturity.
%    Modified duration, in unit of years, given bond-equivalent
%    yields and prepayment vectors of NMBS mortgage pools.
%
%    [YearDuration, ModDuration] = mbsdury(Yield, Settle, Maturity, IssueDate, ...
%       GrossRate)
%    [YearDuration, ModDuration] = mbsdury(Yield, Settle, Maturity, IssueDate, ...
%       GrossRate, CouponRate)
%    [YearDuration, ModDuration] = mbsdury(Yield, Settle, Maturity, IssueDate, ...
%       GrossRate, CouponRate, Delay)
%    [YearDuration, ModDuration] = mbsdury(Yield, Settle, Maturity, IssueDate, ...
%       GrossRate, CouponRate, Delay, PrepaySpeed)
%    [YearDuration, ModDuration] = mbsdury(Yield, Settle, Maturity, IssueDate, ...
%       GrossRate, CouponRate, Delay, PrepaySpeed, PrepayMatrix)
%
%   Optional Inputs: CouponRate, Delay, [], PrepayMatrix
%
%   Inputs:
%             Yield - NMBSx1 vector of mortgage yield (monthly compounded)
%                     yield in decimal.
%
%            Settle - NMBSx1 vector of settlement date.
%
%          Maturity - NMBSx1 vector of maturity date.
%
%         IssueDate - NMBSx1 vector of issue date.
%
%         GrossRate - NMBSx1 vector of gross coupon rate, in decimal.
%
%   Optional Inputs:
%       CouponRate  - NMBSx1 vector of Net Coupon Rate, in decimal.
%                     Default is equal to GrossRate.
%
%            Delay  - NMBSx1 vector of delay in days.
%
%      PrepaySpeed  - NMBSx1 vector of speed relative to PSA standard.
%                     PSA standard is 100.
%                     Default is 0 (zero) prepayment speed.
%
%      PrepayMatrix - Customized prepayment vector. A matrix of size
%                     [max(TermRemaining) x NMBS]. Missing values are
%                     padded with NaNs.  Each column corresponds to each
%                     MBS, and each row corresponds to each month after
%                     settlement.
%
%   Outputs:
%      YearDuration  - Macaulay duration in years
%
%       ModDuration  - Modified duration in years
%
%   Example:
%     Yield =  0.07298413;
%     Settle    = '15-Apr-2002';
%     Maturity  = '01 Jan 2030';
%     IssueDate = '01-Jan-2000';
%     GrossRate = 0.08125;
%     CouponRate = 0.075;;
%     Delay = 14;
%     Speed = 100;
%
%     [YearDuration, ModDuration] = mbsdury(Yield, Settle, Maturity, ...
%         IssueDate, GrossRate, CouponRate, Delay, Speed)
%
%     YearDuration =
%        6.4380
%
%     ModDuration  =
%        6.2080
%
%   See also:  MBSDURP, MBSCONVY, MBSCONVP
%
%   Note: This function is PSA compliant.
%   Reference: PSA Uniform Practices, SF-49

%   Copyright 2002-2005 The MathWorks, Inc.
%   $Revision: 1.6.6.7 $  $Date: 2005/06/17 20:25:16 $

if nargin > 9
    error('finfixed:mbsdury:invalidMoreInputs', 'Too many input arguments.');
end

if nargin < 5
    error('finfixed:mbsdury:invalidLessInputs',...
        'Need at least Yield, Settle, Maturity, IssueDate, and GrossRate.');
end


% get price, cash flow, and time factors
[Price, AccrInt, CFlowAmounts, TFactors] = mbsprice(Yield, Settle, ...
    Maturity, IssueDate, GrossRate, varargin{1:end});

% expand Yield to correct size
Yield = finargsz(1,Yield(:), Price);

% convert the monthly yield to semi-annual yield
BEY = 2*( (1+Yield/12).^6 - 1 );

% Denominator is Cash Price
P = (Price + AccrInt)/100;
NumCF = size(CFlowAmounts,2);

% zero the NaNs
CFlowAmounts(isnan(CFlowAmounts)) = 0;
TFactors(isnan(TFactors)) = 0;

% annualize time factors
TFactors = TFactors./12;

% Compute duration based on PSA Uniform Practices, SF-49
YearDuration = 1./P .* sum(((TFactors).*CFlowAmounts./...
    (1+BEY(:, ones(NumCF,1))/2).^(2.*TFactors)),2);

ModDuration = YearDuration./(1+BEY/2);


% [EOF]
