classdef IRFitOptions < handle
    %IRFITOPTIONS Options object for fitting an IRFUNCTIONCURVE
    %   The IRFITOPTIONS object allows the user to specify options relating to
    %   the fitting process for an IRFUNCTIONCURVE.  The properties of an
    %   IR Fit Options object include the following:
    %
    %   InitialGuess: Determines an initial guess for the function parameters
    %   FitType: Price, Yield, or DurationWeightedPrice -- determines which is
    %   minimized in the curve fitting process
    %   UpperBound: Lower bound for the parameters of the curve function
    %   LowerBound: Upper bound for the parameters of the curve function
    %   OptOptions: Optimization structure for LSQNONLIN
    %
    % See also IRFUNCTIONCURVE
    
    % Copyright 2008 The MathWorks, Inc.
    % $Revision: 1.1.6.3 $   $Date: 2008/06/16 16:38:24 $
    
    properties (SetAccess = public, GetAccess = public)
        FitType
        InitialGuess
        UpperBound
        LowerBound
        OptOptions
    end
    methods
        function obj = IRFitOptions(initialguess,varargin)
            %IRFITOPTIONS Create an IR Fit Options structure
            %   IRFO = IRFITOPTIONS(INITGUESS) creates an IR Fit Options
            %   structure with an initial guess
            %
            %   Optional inputs include FitType, UpperBound, LowerBound,
            %   and OptOptions, specified in parameter value pairs.
            %
            %   Example: Create with an initial guess
            %
            %           rr = IRFitOptions([.5 .4 .3]);
            %
            %   Example: Create with an initial guess and bounds
            %
            %           rr = IRFitOptions([.5 .4 .3],'LowerBound',[0 -Inf 0],...
            %                           'UpperBound',[Inf Inf Inf]);
            %
            p = inputParser;
            
            p.addParamValue('fittype','durationweightedprice',...
                @(x) ismember(x,{'durationweightedprice','price','yield'}));
            p.addRequired('initialguess',@isnumeric);
            p.addParamValue('upperbound',[],@isnumeric);
            p.addParamValue('lowerbound',[],@isnumeric);
            p.addParamValue('optoptions',[],@isstruct);
            
            try
                p.parse(initialguess,varargin{:});
            catch ME
                newME = MException('finfixed:IRFitOptions:optionalInputError',...
                    'Error in optional parameter value inputs');
                newME = addCause(newME,ME);
                throw(newME)
            end
            
            fittype = p.Results.fittype;
            initialguess = p.Results.initialguess;
            upperbound = p.Results.upperbound;
            lowerbound = p.Results.lowerbound;
            optoptions = p.Results.optoptions;
            
            % Check to make sure that the bounds and initial guess are of
            % equal lengths and vectors
            if all(size(initialguess) > 1) || all(size(upperbound) > 1) || ...
                    all(size(lowerbound) > 1)
                error('finfixed:IRFitOptions:invalidInputSizes',...
                    'Initial Guess, Upper Bound and Lower Bound must be vectors.')
            end
            
            if ~isempty(lowerbound)
                if (length(initialguess) ~= length(lowerbound))
                    error('finfixed:IRFitOptions:GuessandLowerBoundSize',...
                        'Initial Guess and Lower Bound must have the same lengths.')
                end
            end
            
            if ~isempty(upperbound)
                if (length(initialguess) ~= length(upperbound))
                    error('finfixed:IRFitOptions:GuessandUpperBoundSize',...
                        'Initial Guess and Upper Bound must have the same lengths.')
                end
            end
            
            if ~isempty(lowerbound) && ~isempty(upperbound)
                if (length(upperbound) ~= length(lowerbound))
                    error('finfixed:IRFitOptions:BoundSizes',...
                        'Upper Bound and Lower Bound must have the same lengths.')
                end
            end
            
            obj.FitType = fittype;
            obj.InitialGuess = initialguess;
            obj.UpperBound = upperbound;
            obj.LowerBound = lowerbound;
            obj.OptOptions = optoptions;
            
        end
    end
end