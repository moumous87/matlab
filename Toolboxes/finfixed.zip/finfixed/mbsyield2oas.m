function OAS = mbsyield2oas(ZeroCurve, Yield, Settle, Maturity,...
    IssueDate, GrossRate, varargin)
%MBSYIELD2OAS OAS given yield, prepayment, and benchmark spot curve.
%   OAS for NMBS number of mortgage pool given mortgage-yields,
%   prepayment assumptions, and benchmark spot curve.
%
%   OAS = mbsyield2oas(ZeroCurve, Yield, Settle, Maturity, IssueDate,...
%       GrossRate)
%   OAS = mbsyield2oas(ZeroCurve, Yield, Settle, Maturity, IssueDate,...
%       GrossRate, CouponRate)
%   OAS = mbsyield2oas(ZeroCurve, Yield, Settle, Maturity, IssueDate,...
%       GrossRate, CouponRate, Delay)
%   OAS = mbsyield2oas(ZeroCurve, Yield, Settle, Maturity, IssueDate,...
%       GrossRate, CouponRate, Delay, Interpolation)
%   OAS = mbsyield2oas(ZeroCurve, Yield, Settle, Maturity, IssueDate,...
%       GrossRate, CouponRate, Delay, Interpolation, PrepaySpeed)
%   OAS = mbsyield2oas(ZeroCurve, Yield, Settle, Maturity, IssueDate,...
%       GrossRate, CouponRate, Delay, Interpolation, [], PrepayMatrix)
%
%   Optional Inputs: CouponRate, Delay, Interpolation, PrepaySpeed,
%                    PrepayMatrix
%
%   Inputs:
%        ZeroCurve - Three-column matrix, the first is serial date,
%                     the second contains Spot Rates with maturities
%                     corresponding to the dates in the first column,
%                     in decimal (e.g. 0.075), and the third column is
%                     the Compounding of the rates given in the first
%                     column.
%
%                     Example: [datenum('1-Jan-2003')  0.0154  12;
%                               datenum('1-Jan-2004')  0.0250  12;
%                               ......
%                               datenum('1-Jan-2020')  0.0675   2];
%
%             Yield - NMBSx1 vector of mortgage yield
%                     (monthly compounded).
%
%            Settle - NMBSx1 vector of settlement date.
%
%          Maturity - NMBSx1 vector of maturity date.
%
%         IssueDate - NMBSx1 vector of issue date.
%
%         GrossRate - NMBSx1 vector of gross coupon rate,
%                     in decimal.
%
%   Optional Inputs:
%        CouponRate - NMBSx1 vector of Net Coupon Rate,
%                     in decimal.
%                     Default is equal to GrossRate.
%
%             Delay - NMBSx1 vector of delay in days.
%
%     Interpolation - Scalar value
%                     Interpolation method, to compute for the
%                     corresponding spot rates for the bond's cash flow.
%                     Default is (1), linear.
%                     Available methods are (0) nearest, (1) linear, and
%                     (2) cubic spline.
%
%       PrepaySpeed - NMBSx1 vector of speed relative to PSA standard. PSA
%                     standard is 100.
%                     Default is 0 (zero) prepayment speed.
%
%      PrepayMatrix - Customized prepayment vector. A matrix of size
%                     [max(TermRemaining) x NMBS]. Missing values are
%                     padded with NaNs.  Each column corresponds to each
%                     MBS, and each row corresponds to each month after
%                     settlement.
%
%   Outputs:
%               OAS - OAS, in basis point (bp).
%
%   Example:
%     This examples calculates OAS of 30-year fixed rate with about
%     28 year WAM left given an assumption of 0, 50, and 100 PSA
%     prepayment:
%
%   Create Bonds matrix
%     Bonds = [datenum('11/21/2002')   0       100  0  2  1;
%              datenum('02/20/2003')   0       100  0  2  1;
%              datenum('07/31/2004')   0.03    100  2  3  1;
%              datenum('08/15/2007')  0.035    100  2  3  1;
%              datenum('08/15/2012')  0.04875  100  2  3  1;
%              datenum('02/15/2031')  0.05375  100  2  3  1];
%
%   Settle Date:
%     Settle  = datenum('20-Aug-2002');
%
%   Clean prices for the bonds:
%     Prices =  [ 98.97467;
%                 98.58044;
%                100.10534;
%                 98.18054;
%                101.38136;
%                 99.25411];
%
%   SpotCompounding for the bonds:
%     SpotCompounding = 2*ones(size(Prices));
%
%   Call ZBTPRICE
%     [ZeroRatesP, CurveDatesP] = zbtprice(Bonds, Prices, Settle)
%     ZeroCurve = [CurveDatesP, ZeroRatesP, SpotCompounding];
%
%   Assign the parameters
%     Price     = 95;
%     Maturity  = datenum('02-Jan-2030');
%     IssueDate = '2-Jan-2000';
%     GrossRate = 0.08125;
%     CouponRate = 0.075;
%     Delay = 14;
%     Interpolation = 1;
%     PrepaySpeed = [0; 50; 100];
%
%     [mbsyld, beyld] = mbsyield(Price, Settle, Maturity, IssueDate,...
%         GrossRate, CouponRate, Delay, PrepaySpeed);
%
%     OAS = mbsyield2oas(ZeroCurve, mbsyld, Settle, Maturity, IssueDate,...
%         GrossRate, CouponRate, Delay, Interpolation, PrepaySpeed)
%
%     OAS =
%       26.0502
%       28.6348
%       31.2222
%
%   See also MBSOAS2PRICE, MBSPRICE2OAS, MBSOAS2YIELD

%   Copyright 2002-2004 The MathWorks, Inc.
%   $Revision 1.8.6.3.2.1 $  $Date: 2005/06/17 20:25:26 $

if nargin <6
    error('finfixed:mbsyield2oas:invalidInputs',...
        sprintf(['Need at least ZeroMatrix, Price, ',...
        'Settle, Maturity, IssueDate, and GrossRate.']));
else
    CurveDates = ZeroCurve(:,1);

    % Make sure align these arrays into Column
    CurveDates = CurveDates(:);
    Settle     = datenum(Settle);

    if any(Settle ~= Settle(1))
        error('finfixed:mbsyield2oas:invalidSettle',...
            sprintf(['Please make sure that all Settle date are ',...
            'the same, or simply input a scalar Settle date.']));
    end

    Maturity  = datenum(Maturity);
    IssueDate = datenum(IssueDate);
end

if nargin <7 || isempty(varargin{1})
    CouponRate = GrossRate;
else
    CouponRate = varargin{1}(:);
end

if nargin <8 || isempty(varargin{2})
    Delay = 0;
else
    Delay = varargin{2}(:);
end

if ~(nargin <9 || isempty(varargin{3}))
    Interpolation = varargin{3}(:);
    if any(Interpolation ~=Interpolation(1))
        error('finfixed:mbsyield2oas:invalidInterpolation',...
            sprintf(['Please make sure that all Interpolation is of ',...
            'ONE type, or simply input a scalar value for Interpolation.']));
    end
end

if nargin < 10 || isempty(varargin{4})
    Speed = 0;
else
    Speed = varargin{4};
end

if nargin == 11;
    isCustomized = true;
else
    isCustomized = false;
end

if isCustomized
    if ~isempty(varargin{4})
        error('finfixed:mbsyield2oas:invalidPrePaySpeed',...
            sprintf(['Cannot use benchmark when supplying customized ', ...
            'prepayment CPR.\nPut empty matrices ([]) for 10th ',...
            'input arguments.']));
    end

    % check that prepayment is supplied and not empty.
    if isempty(varargin{5})
        error('finfixed:mbsyield2oas:invalidPrePayMatrix',...
            sprintf(['Please supply a prepayment (SMM) matrix when',...
            'you do not use benchmarked prepayment.']));
    end

    [Yield Settle, Maturity, IssueDate, GrossRate, ...
        CouponRate, Delay] = ...
        finargsz(1,Yield(:), Settle(:), Maturity(:), IssueDate(:),  ...
        GrossRate(:),CouponRate(:), Delay(:));
else
    [Yield, Settle, Maturity, IssueDate, GrossRate, ...
        CouponRate, Delay, Speed] = ...
        finargsz(1, Yield(:), Settle(:), Maturity(:), IssueDate(:), ...
        GrossRate(:),CouponRate(:), Delay(:), Speed(:));
end

% Check Settle-Maturity vs Spot Dates consistency
% The case with "outdated" Spot Curve
if any(Settle > min(CurveDates))
    error('finfixed:mbsyield2oas:invalidSpotCurve',...
        sprintf(['Settle is less than the earliest point in the ', ...
        'Spot curve.\nThe Spot Curve is outdated.']));
end

if isCustomized
    Price = mbsprice(Yield, Settle, Maturity, IssueDate, ...
        GrossRate, CouponRate, Delay, [], PrepayMatrix);
else
    Price = mbsprice(Yield, Settle, Maturity, IssueDate, ...
        GrossRate, CouponRate, Delay, Speed);
end

% calculate OAS given with modified varargin
OAS = mbsprice2oas(ZeroCurve, Price, Settle, Maturity,...
    IssueDate, GrossRate, varargin{1:end});

% [EOF]
