classdef IRCurve < handle
%IRCURVE Base abstract class for interest rate curves
%   IRCURVE is an abstract class, and you cannot create instances of
%   it directly.  You can create IRFUNCTIONCURVE and IRDATACURVE objects
%   that are derived from this class.
%
%   The class has the following properties:
%
%   Type: Forward, Zero, Discount -- type of curve
%   Settle: Settle Date
%   Compounding: -1,1,2,3,4,6,12 -- compounding for IRCurve
%   Basis: 0-12, day count convention for IRCurve
%
%   Classes that inherit from IRCURVE must implement the following methods:
%
%   GETFORWARDRATES: Returns forward rates for input dates
%   GETZERORATES: Returns zero rates for input dates
%   GETDISCOUNTFACTORS: Returns discount factors for input dates
%   GETPARYIELDS: Returns par yields for input dates
%   TORATESPEC: Converts to be a RateSpec object, like the ones produced by
%   INTSENVSET, for input dates
%
% See also IRFUNCTIONCURVE, IRDATACURVE, INTENVSET

    properties (SetAccess = protected, GetAccess = public)
        Type
        Settle
        Compounding = 2;
        Basis = 0;
    end

    methods (Abstract)
        getForwardRates(obj,Dates)
        getZeroRates(obj,Dates)
        getDiscountFactors(obj,Dates)
        getParYields(obj,Dates)
        toRateSpec(obj)
    end
end