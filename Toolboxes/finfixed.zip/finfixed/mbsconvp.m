function Convexity = mbsconvp(Price, Settle, Maturity, IssueDate, ...
          GrossRate, varargin)
%MBSCONVP Convexity of mortgage pool given price.
%    Modified Convexity of NMBS number of mortgage pool given prices
%    and prepayment assumptions.
%
%    Convexity = mbsconvp(Price, Settle, Maturity, IssueDate, GrossRate)
%    Convexity = mbsconvp(Price, Settle, Maturity, IssueDate, GrossRate, ...
%       CouponRate)
%    Convexity = mbsconvp(Price, Settle, Maturity, IssueDate, GrossRate, ...
%       CouponRate, Delay)
%    Convexity = mbsconvp(Price, Settle, Maturity, IssueDate, GrossRate, ...
%       CouponRate, Delay, PrepaySpeed)
%    Convexity = mbsconvp(Price, Settle, Maturity, IssueDate, GrossRate, ...
%       CouponRate, Delay, [], PrepayMatrix)
%
%    Optional Inputs: CouponRate, Delay, PrepaySpeed, PrepayMatrix
%
%    Inputs:
%           Price - NMBSx1 vector of clean price for every $100 face
%
%          Settle - NMBSx1 vector of settlement date.
%
%        Maturity - NMBSx1 vector of Maturity Date.
%
%       IssueDate - NMBSx1 vector of Issue Date.
%
%       GrossRate - NMBSx1 vector of Gross Coupon Rate, in decimal.
%
%    Optional Inputs:
%      CouponRate  - NMBSx1 vector of Net Coupon Rate, in decimal.
%                    Default is equal to GrossRate.
%
%           Delay  - NMBSx1 vector of delay in days.
%
%     PrepaySpeed  - NMBSx1 vector of speed relative to PSA standard. 
%                    PSA standard is 100.
%                    Default is 0 (zero) prepayment speed.
%
%     PrepayMatrix - Customized prepayment vector. A matrix of size
%                    [max(TermRemaining) x NMBS]. Missing values are padded
%                    with NaNs.  Each column corresponds to each MBS, and
%                    each row corresponds to each month after settlement.
%
%    Outputs:
%       Convexity  - Periodic convexity of mortgage pool.
%
%    Example:
%      Price      = 101;
%      Settle     = '15-Apr-2002';
%      Maturity   = '01 Jan 2030';
%      IssueDate  = '01-Jan-2000';
%      GrossRate  = 0.08125;
%      CouponRate = 0.075;;
%      Delay      = 14;
%      Speed      = 100;
% 
%      Convexity = mbsconvp(Price, Settle, Maturity, ...
%           IssueDate, GrossRate, CouponRate, Delay, Speed)
%
%      Convexity = 
%         71.6299
%
%   See also MBSCONVY, MBSDURY, MBSDURP
%
%   Note: This function is PSA compliant.
%   Reference: PSA Uniform Practices, SF-49

%   Copyright 2002-2005 The MathWorks, Inc.
%   $Revision: 1.6.6.8 $  $Date: 2008/02/02 13:05:45 $


if nargin > 9
    error('finfixed:mbsconvp:invalidMoreInputs', 'Too many input arguments.');
end

if nargin < 5
    error('finfixed:mbsconvp:invalidLessInputs',...
        'Need at least Price, Settle, Maturity, IssueDate, and GrossRate.');
end

% Calculate monthly yield
MEY = mbsyield(Price, Settle, Maturity, IssueDate, GrossRate, varargin{1:end});

% Call mbsconvy to calculate Convexity
Convexity = mbsconvy(MEY,Settle, Maturity, IssueDate, ...
    GrossRate, varargin{1:end});


% [EOF]
