function Yield = cdyield(varargin)
%CDYIELD Simple yield to maturity of CD (Certificate of Deposit).
%   Simple yield of NCD number of CD (interest-bearing paper) given its
%   clean price.
%
%   Yield = cdyield(Price, CouponRate, Settle, Maturity, IssueDate)
%   Yield = cdyield(Price, CouponRate, Settle, Maturity, IssueDate, Basis)
%
%   Optional Inputs: Basis
%
%   Inputs:
%        Price - NCDx1 Clean Price of CD per $100 notional
%
%   CouponRate - NCDx1 vector of coupon rate in decimal
%
%       Settle - NCDx1 vector of Settlement date
%
%     Maturity - NCDx1 vector of Maturity date
%
%    IssueDate - NCDx1 vector of Issue date
%
%   Optional Inputs:
%        Basis - NCDx1 vector of accrual basis
%
%                Possible values are:
%                0 - actual/actual
%                1 - 30/360 (SIA compliant) (default)
%                2 - actual/360
%                3 - actual/365
%                4 - 30/360 PSA
%                5 - 30/360 ISDA
%                6 - 30/360 European
%                7 - actual/365 Japanese
%                8 - actual/actual ISMA
%                9 - actual/360 ISMA
%               10 - actual/365 ISMA
%               11 - 30/360 ISMA
%               12 - actual/365 (ISDA)
%
%   Outputs:
%        Yield - NCDx1 vector of simple Yield to maturity of CD.
%
%   Example:
%     Price      = 101.125;
%     CouponRate = 0.05;
%     Settle     = '02-Jan-2002';
%     Maturity   = '31-Mar-2002';
%     IssueDate  = '01-Oct-2001';
%
%     Yield = cdyield(Price, CouponRate, Settle, Maturity, IssueDate)
%     Yield =
%         0.0039


%   Copyright 2002-2007 The MathWorks, Inc.
%   $Revision: 1.9.6.9 $   $Date: 2007/11/07 18:32:55 $

% Input arguments check
if nargin < 5
    error('finfixed:cdyield:invalidInputs', 'Incorrect number of inputs.');

else
    Price  = varargin{1}(:);
    CouponRate = varargin{2}(:);
    Settle     = datenum(varargin{3});
    Maturity   = datenum(varargin{4});
    IssueDate  = datenum(varargin{5});
end

if nargin < 6 || isempty(varargin{6})
    Basis = 2;

else
    Basis = varargin{6}(:);
    if any(~isvalidbasis(Basis))
        error('finfixed:cdyield:invalidBasis', 'Invalid day count basis.');
    end
end

% size check
[Price, CouponRate, Settle, Maturity, IssueDate, Basis] = ...
    finargsz(1, Price, CouponRate, Settle(:), Maturity(:), IssueDate(:), Basis(:));

% making sure that IssueDate <= Settle <= Maturity
if any(IssueDate > Settle)
    error('finfixed:cdyield:invalidIssueDate',...
        'IssueDate must be less than or equal to Settle.');
end

if any(Settle > Maturity)
    error('finfixed:cdyield:invalidSettleDate',...
        'Settle must be less than or equal to Maturity.');
end

Tis = yearfrac(IssueDate, Settle, Basis);
Tim = yearfrac(IssueDate, Maturity, Basis);
Tsm = yearfrac(Settle, Maturity, Basis);

AccrInt = CouponRate .* Tis;

B = Price/100 + AccrInt;

Yield = ((1 + CouponRate.*Tim) ./ B  - 1) .* (1./Tsm);


% [EOF]
