function [YearDuration, ModDuration] = mbsdurp(Price, Settle, Maturity,...
    IssueDate, GrossRate, varargin )
%MBSDURP Macaulay and Modified duration given price and prepayment.
%   Modified duration, in unit of years, given prices of NMBS number of
%   mortgage-pools and their prepayment vectors. 
%
%   [YearDuration, ModDuration] = mbsdurp(Price, Settle, Maturity, IssueDate, ...
%      GrossRate)
%   [YearDuration, ModDuration] = mbsdurp(Price, Settle, Maturity, IssueDate, ...
%      GrossRate, CouponRate)
%   [YearDuration, ModDuration] = mbsdurp(Price, Settle, Maturity, IssueDate, ...
%      GrossRate, CouponRate, Delay)
%   [YearDuration, ModDuration] = mbsdurp(Price, Settle, Maturity, IssueDate, ...
%      GrossRate, CouponRate, Delay, PrepaySpeed)
%   [YearDuration, ModDuration] = mbsdurp(Price, Settle, Maturity, IssueDate, ...
%      GrossRate, CouponRate, Delay, [], PrepayMatrix)
%
%   Optional Inputs: CouponRate, Delay, PrepaySpeed, PrepayMatrix
%  
%   Inputs:
%             Price - NMBSx1 vector of clean price for every $100 face of issue.
%
%            Settle - NMBSx1 vector of settlement date.
%
%          Maturity - NMBSx1 vector of maturity date.
%
%         IssueDate - NMBSx1 vector of issue date.
%
%         GrossRate - NMBSx1 vector of gross coupon rate, in decimal.
%
%   Optional Inputs:
%        CouponRate - NMBSx1 vector of Net Coupon Rate, in decimal.
%                     Default is equal to GrossRate.
%
%             Delay - NMBSx1 vector of delay in days.
%
%       PrepaySpeed - NMBSx1 vector of speed relative to PSA standard. 
%                     PSA standard is 100.
%                     Default is 0 (zero) prepayment speed.
%
%      PrepayMatrix - Customized prepayment vector. A matrix of size
%                     [max(TermRemaining) x NMBS]. Missing values are
%                     padded with NaNs.  Each column corresponds to each
%                     MBS, and each row corresponds to each month after
%                     settlement.
%
%   Outputs:
%      YearDuration - Macaulay duration in years
%
%       ModDuration - Modified duration in years
%
%   Example:
%     Price = 101;
%     Settle    = '15-Apr-2002';
%     Maturity  = '01 Jan 2030';
%     IssueDate = '01-Jan-2000';
%     GrossRate = 0.08125;
%     CouponRate = 0.075;;
%     Delay = 14;
%     Speed = 100;
%
%     [YearDuration, ModDuration] = mbsdurp(Price, Settle, Maturity, ...
%        IssueDate, GrossRate, CouponRate, Delay, Speed)
%
%     YearDuration =
%         6.4380
%    
%     ModDuration  =
%         6.2080
%
%   See also:  MBSDURY, MBSCONVY, MBSCONVP
%
%   Note: This function is PSA compliant.
%   Reference: PSA Uniform Practices, SF-49

%   Copyright 2002-2005 The MathWorks, Inc.
%   $Revision: 1.6.6.7 $  $Date: 2005/06/17 20:25:15 $

if nargin > 9
    error('finfixed:mbsdurp:invalidMoreInputs', 'Too many input arguments.');
end

if nargin < 5
    error('finfixed:mbsdurp:invalidLessInputs',...
        'Need at least Price, Settle, Maturity, IssueDate, and GrossRate.');
end

% compute the mortgage yield
montlyld = mbsyield(Price, Settle, Maturity, IssueDate, GrossRate, ...
    varargin{1:end});

% calculate the duration
[YearDuration, ModDuration] = mbsdury(montlyld, Settle, Maturity, ...
    IssueDate, GrossRate, varargin{1:end});


% [EOF]
