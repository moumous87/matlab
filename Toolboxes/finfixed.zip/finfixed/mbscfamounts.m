function varargout = mbscfamounts(Settle, Maturity, IssueDate, ...
    GrossRate, varargin)
%   MBSCFAMOUNTS Cash flow and time mapping  for mortgage-pool.
%      CashFlows amounts and timing for NMBS number of mortgage
%      pools given pool specification and prepayment vectors.
%
%     [CFlowAmounts, CFlowDates, TFactors, Factors] = mbscfamounts(...
%        Settle, Maturity, IssueDate, GrossRate)
%     [CFlowAmounts, CFlowDates, TFactors, Factors] = mbscfamounts(...
%        Settle, Maturity, IssueDate, GrossRate, CouponRate)
%     [CFlowAmounts, CFlowDates, TFactors, Factors] = mbscfamounts(...
%        Settle, Maturity, IssueDate, GrossRate, CouponRate, Delay)
%     [CFlowAmounts, CFlowDates, TFactors, Factors] = mbscfamounts(...
%        Settle, Maturity, IssueDate, GrossRate, CouponRate, Delay, ...
%        PrepaySpeed)
%     [CFlowAmounts, CFlowDates, TFactors, Factors] = mbscfamounts(...
%        Settle, Maturity, IssueDate, GrossRate, CouponRate, Delay, [],
%        PrepayMatrix)
%
%   Optional Inputs: CouponRate, Delay, PrepaySpeed, PrepayMatrix
%
%   Inputs:
%           Settle - NMBSx1 vector of Settlement Date.
%
%         Maturity - NMBSx1 vector of Maturity Date.
%
%        IssueDate - NMBSx1 vector of Issue Date.
%
%        GrossRate - NMBSx1 vector of Gross Coupon Rate,
%                    in decimal.
%
%   Optional Inputs:
%       CouponRate - NMBSx1 vector of Net Coupon Rate,
%                    in decimal. Default is equal to GrossRate.
%
%            Delay - NMBSx1 vector of payment delay in days.
%                    Default is 0 (no delay).
%
%      PrepaySpeed - NMBSx1 vector of speed relative to
%                    PSA standard. PSA standard is 100.
%                    Default is 0 (zero) prepayment speed.
%
%     PrepayMatrix - Customized prepayment vector. A matrix of size
%                    [max(TermRemaining) x NMBS]. Missing values are padded
%                    with NaNs.  Each column corresponds to each MBS, and
%                    each row corresponds to each month after settlement.
%
%   Outputs:
%     CFlowAmounts - NMBSxP matrix of cash flows, start from end of first
%                    monthly period and end at the last monthly period
%                    (Maturity).
%
%       CFlowDates - NMBSxP matrix of dates when cash flows occur,
%                    including Settlement, where possible negative (accrued
%                    interest) payments occur
%
%         TFactors - NMBSxP matrix of time in months from Settle
%                    corresponding to each cash flow.
%
%          Factors - NMBSxP matrix of the mortgage factor, which indicates
%                    fraction of balance still outstanding at the end of
%                    the month.
%
%   Example:  Given a mortgage with the following characteristics, compute
%   the cash flow amounts and dates, the time factors, and the mortgage
%   factors.
%
%      Settle     = datenum('17-Apr-2002');
%      Maturity   = datenum('01-Jan-2030');
%      IssueDate  = datenum('01-Jan-2000');
%      GrossRate  = 0.08125;
%      CouponRate = 0.075;
%      Delay      = 14;
%      Speed      = 100;
%
%      CFlowAmounts = mbscfamounts( Settle, Maturity, IssueDate, ...
%                GrossRate, CouponRate, Delay, Speed)
%
%      CFlowAmounts =
%             Columns 1 through 4
%             -0.00333333  0.01183739  0.01195201  0.01206316 ...
%              ...
%             Columns 331 through 334
%              0.00140712  0.00139362  0.00138018  0.00136680
%
%    Reference: PSA Uniform Practices, SF-4
%
%    Note: This function is PSA compliant.
%
%   See also MBSPASSTHROUGH, MBSNOPREPAY

%   Author(s): K. Lui, 3/2004;
%   Copyright 2002-2004 The MathWorks, Inc.
%   $Revision 1.3 $  $Date: 2007/09/11 11:45:49 $


if nargin > 9
    error('finfixed:mbscfamounts:invalidMoreInputs',...
        sprintf(['Too many input arguments. ', ...
        'Type "help mbscfamounts" for information.']));
end

if nargin < 4
    error('finfixed:mbscfamounts:invalidLessInputs',...
        'Need at least Settle, Maturity, IssueDate, and GrossRate')
else
    Settle    = datenum(Settle);
    Maturity  = datenum(Maturity);
    IssueDate = datenum(IssueDate);
    if any(IssueDate > Settle)
        error('finfixed:mbscfamounts:invalidSettle',...
            sprintf(['Settle must be at, or after IssueDate.',...
            'Settle before IssueDate is unsupported \nat this time.']));
    end
end

if nargin <5 || isempty(varargin{1})
    CouponRate = GrossRate;
else
    CouponRate = varargin{1};
end

if nargin <6 || isempty(varargin{2})
    Delay = 0;
else
    Delay = varargin{2};
end

if nargin <8 || isempty(varargin{4});
    isCustomized = false;
else
    isCustomized = true;
end

if nargin <9 || isempty(varargin{5});
    Period = 12;
else
    Period = varargin{5};
end

% check that not both prepayment matrix and benchmark is empty
if (nargin <8 || isempty(varargin{4}))&&(nargin <7 ||isempty(varargin{3}))
    error('finfixed:mbscfamounts:invalidPrepayMatrix',...
        sprintf(['Please supply a prepayment(SMM) ',...
        'matrix when you do not use \nbenchmarked prepayment.']));
end

if ~isCustomized
    if nargin < 7 || isempty(varargin{3})
        Speed = 0;
    else
        Speed = varargin{3};
    end

    [Settle, Maturity, IssueDate, GrossRate, CouponRate, Delay, Speed] = ...
        finargsz(1,Settle(:), Maturity(:), IssueDate(:), GrossRate(:), ...
        CouponRate(:), Delay(:), Speed(:));

    vec_Issue = datevec(IssueDate);
    vec_Maturity = datevec(Maturity);

    if any(vec_Issue(:,3)-vec_Maturity(:,3))
        warning('finfixed:mbscfamounts:diffIssueMaturity',...
            ['The Issue date is different from Maturity.',...
            'At this time MATLAB \ndoes not handle ''odd''',...
            'coupon for MBS. MATLAB has now changed the ',...
            'Maturity \ndate to be equal to Issue date.']);
        vec_Maturity(:,3) = vec_Issue(:,3);
        Maturity = datenum(vec_Maturity);
    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Building CashFlow dates to be in-sync vs. IssueDate     %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    CFlowDates = cfdates(Settle, Maturity, Period, 4, 1, IssueDate);
    % append the Settlement date, too.
    CFlowDates = [Settle, CFlowDates];

    NumCouponsRemaining = cpncount(IssueDate, Maturity, Period, ...
        4, 1, IssueDate);

    NumCouponsRemaining(:,2) = cpncount(Settle, Maturity, Period, ...
        4, 1, IssueDate);
else

    if ~isempty(varargin{3})
        error('finfixed:mbscfamounts:invalidPrepaySpeed',...
            sprintf(['Cannot use benchmark when supplying ',...
            'customized prepayment CPR - Put ',...
            '\nempty matrices, [], for 7th input arguments.']));
    end

    % check that prepayment is supplied and not empty.
    if isempty(varargin{4})
        error('finfixed:mbscfamounts:invalidPrepayMatrix',...
            sprintf(['Please supply a prepayment(SMM) ',...
            'matrix when you do not use \nbenchmarked prepayment.']));
    else
        SMMRel = varargin{4};
    end

    [Settle, Maturity, IssueDate, GrossRate, CouponRate, Delay] = ...
        finargsz(1,Settle(:), Maturity(:), IssueDate(:), GrossRate(:), ...
        CouponRate(:), Delay(:));

    % TIME processing
    vec_Issue = datevec(IssueDate);
    vec_Maturity = datevec(Maturity);

    if any(vec_Issue(:,3)-vec_Maturity(:,3))
        warning('finfixed:mbscfamounts:diffIssueMaturity',...
            ['The Issue date is different from Maturity. ',...
            'At this time MATLAB does not \nhandle ''odd''',...
            ' coupon for MBS. MATLAB has now changed the ',...
            'Maturity date to be equal \nto Issue date.']);
        vec_Maturity(:,3) = vec_Issue(:,3);
        Maturity = datenum(vec_Maturity);
    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Building CashFlow dates to be in-sync vs. IssueDate     %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    CFlowDates = cfdates(Settle, Maturity, Period, 4, 1, IssueDate);
    % append the Settlement date, too.
    CFlowDates = [Settle, CFlowDates];

    NumCouponsRemaining(:,1) = cpncount(IssueDate, Maturity, Period, ...
        4, 1, IssueDate);

    NumCouponsRemaining(:,2) = cpncount(Settle, Maturity, Period, ...
        4, 1, IssueDate);

    % check the size
    if any(size(SMMRel) ~= [max(NumCouponsRemaining(:,2)), length(Settle)])
        error('finfixed:mbscfamounts:invalidSizeCustomPrepayMatrix',...
            sprintf('Size of customized SMM must be max(TermRemaining) x NumMBS.'));
    end
end

if any(NumCouponsRemaining(:,1) > 360)
    error('finfixed:mbscfamounts:invalidMortgageTerm',...
        sprintf(['Mortgage term is more than 360 months and is' ...
        'unsupported at this time.']));
end

% days to next payment - NOT coupon
NumDaysNext  = ...
    cpndaysn(Settle, Maturity, Period, 4, 1, IssueDate);

% calculate delay based on periodicity
delayInPeriod = (Delay./(360/Period))./Period;

% calculate fraction based on periodicity
FracPerNext = (NumDaysNext./(360/Period) - 1)./Period;

NumMBS = length(Settle);
NumCFs = NumCouponsRemaining(:,2)+1;

TFactors = nan(NumMBS, max(NumCFs));
CFlowAmounts = TFactors;

for idx = 1:NumMBS
    % Build Time Factors based on CPY
    TFactors(idx,1:(NumCouponsRemaining(idx,2)+1)) = ...
        [0,(1:(NumCFs(idx)-1))./Period + FracPerNext(idx) + ...
        delayInPeriod(idx)];

    % Convert to monthly time factors
    TFactors(idx,:) = TFactors(idx,:).*12;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                              %
% CASHFLOW construction process                %
%                                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Accrued Interest is found by finding how many days
% it is since last coupon divided by days in period, or alternatively
% how many days to next coupon divided by the days in a period.

AccrInt = (1 - NumDaysNext/(360/Period)).*CouponRate./Period;

% Different way of expanding, and building SMM matrix
% for customized and benchmarked cases:

if isCustomized
    [Factors, Payment, Principal, Interest, Prepayment] = ...
        mbspassthrough(1, GrossRate, NumCouponsRemaining(:,1), ...
        NumCouponsRemaining(:,2), [], SMMRel, Period);
else
    [Factors, Payment, Principal, Interest, Prepayment] = ...
        mbspassthrough(1, GrossRate, NumCouponsRemaining(:,1), ...
        NumCouponsRemaining(:,2), Speed,[], Period);
end

for i = 1:NumMBS
    CFlowAmounts(i,:) = [-AccrInt(i) , ...
        (Principal(:,i)+Prepayment(:,i)+ ...
        Interest(:,i)*CouponRate(i)/GrossRate(i))'];
end

corrected_maturity = Maturity;

varargout = {CFlowAmounts, CFlowDates, TFactors, ...
    [ones(length(Settle),1) , Factors'], corrected_maturity, ...
    Payment, Principal, Prepayment, Interest};

% [EOF]
