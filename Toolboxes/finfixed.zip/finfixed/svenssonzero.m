function ZeroRate = svenssonzero(t,theta)
%SVENSSONZERO Evaluates Svensson equation for the Zero Rate
%
%   ZERORATE = SVENSSONZERO(T,THETA)
%
%   Inputs:
%   t: Time To Maturity
%   theta: 1 x 6 vector of parameters (Beta0, Beta1, Beta2, Beta3, Tau1, Tau2)
%          for the Svensson equation
%
%   Outputs:
%   ZeroRate: ZeroRate for each of the input Time To Maturities
%
%   See also SVENSSONFORWARD

% Reference:
%    Svensson, L.E.O. (1994), "Estimating and interpreting forward interest
%     rates: Sweden 1992-4", International Monetary Fund, IMF Working Paper,
%     1994/114

%   Copyright 2008 The MathWorks, Inc.
%   $Revision: 1.1.6.2 $  $Date: 2008/05/31 23:18:27 $

Beta0 = theta(1);
Beta1 = theta(2);
Beta2 = theta(3);
Beta3 = theta(4);
Tau1 = theta(5);
Tau2 = theta(6);

ZeroRate = Beta0 + Beta1.*(1-exp(-t./Tau1)).*(Tau1./t) + ...
    Beta2.*((1-exp(-t./Tau1)).*(Tau1./t) - exp(-t./Tau1)) + ...
    Beta3.*((1-exp(-t./Tau2)).*(Tau2./t) - exp(-t./Tau2));
ZeroRate(t == 0) = Beta0 + Beta1;
ZeroRate = ZeroRate/100;