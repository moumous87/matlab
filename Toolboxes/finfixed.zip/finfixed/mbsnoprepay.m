function [Balance Interest Payment Principal] = mbsnoprepay(...
    OriginalBalance, GrossRate, Term, varargin)
%  MBSNOPREPAY End-of-month mortgage cash-flows.
%    The function returns amortizing cash flows and balances of NMBS funds
%    over a specified term of P periods, with no prepayment.  When length
%    of funds are not the same, MATLAB will pad the shorter ones with NaNs
%    (not-a-number). 
%
%  [Balance, Interest, Payment, Principal] = ....
%    mbsnoprepay(OriginalBalance, GrossRate, Term)
%
%  Inputs:
%    OriginaBalance - NMBSx1 vector of Original Face value in dollars. 
%
%        CouponRate - NMBSx1 vector of Gross Coupon Rate, 
%                     in decimal. 
%
%              Term - NMBSx1 vector of mortgage term,
%                     in months.
%  Outputs: 
%           Balance - PxNMBS matrix of end-of-month balances over the life
%                     of the Passthrough. 
%
%          Interest - PxNMBS matrix of end-of-month interest payments over
%                     the life of the Passthrough
%
%           Payment - PxNMBS matrix of end-of-month payments over the life
%                     of the Passthrough 
%
%         Principal - PxNMBS matrix of scheduled end-of-month principal
%                     payments over the life of the Passthrough
%
%  Example:
%    Computing cash-flows and balances of a 3-month and 5-month old
%    mortgage pool with original term of 360 months: 
%
%    OriginalBalance = 400000000;
%    CouponRate = 0.08125;
%    Term = [357;355];
%
%    Balance = mbsnoprepay(OriginalBalance, CouponRate, Term);
%
%    Balance = 
%       399732465.09  399728465.50
%       399463118.75  399455092.49
%       399191948.71  399179868.52
%       398918942.62  398902781.05
%       398644088.05  398623817.47
%       398367372.49  398342965.07
%       .             .
%       .             .
%       11704678.43   5899748.95
%       8808060.61    2959827.33
%       5891830.28    0
%       2955854.64    NaN
%       0             NaN
%
%    Note: Suppose the Term is 360, and the remaining is 355.5
%          months, then the RemainingBalance will be 355 by 1 column vector,  
%          indicating end-of-month balances in month 5 through month 360.
%          This means also that we are past month 4 and currently in month
%          5. 
%
%   See also MBSCFAMOUNTS, MBSPASSTHROUGH

%   Copyright 2002-2004 The MathWorks, Inc.
%   $Revision: 1.7.6.6 $  $Date: 2008/03/28 15:23:58 $

if nargin < 3
  error('finfixed:mbsnoprepay:invalidInputs',...
      ['Not enough input, need at least OriginalBalance,\n', ...
         'GrossRate, and Term.']);
end

if nargin <4 || isempty(varargin{1});
    Period = 12;
else
    Period = varargin{1};
end

% expand the arguments into the correct number of rows.
[OriginalBalance, GrossRate, Term, Period] = ...
  finargsz(1, OriginalBalance(:), GrossRate(:), Term(:), Period(:));

NumMBS = length(OriginalBalance);
NumCFmax = max(Term);

% Initialize matrix size NUmCFmax x NumMBS
Balance  = nan(NumCFmax, NumMBS);
Interest = nan(NumCFmax, NumMBS); 
Payment  = nan(NumCFmax, NumMBS); 
Principal= nan(NumCFmax, NumMBS); 

% We are making sure it is integer, floor it because avoid 
% the fractional first month with AI
Term  = floor(Term);

for i = 1:NumMBS    
    % All Balance
    Balance(1:Term(i),i)   = ...
      OriginalBalance(i).* ((1+GrossRate(i)/Period(i)).^Term(i) - ...
        (1 + GrossRate(i)/Period(i)).^(1:Term(i))') / ...
          ( (1+GrossRate(i)/Period(i)).^Term(i) - 1); 
    
    % All Interest
    Interest(1:Term(i),i)  = ...
      [OriginalBalance(i); Balance(1:Term(i)-1, i)] * ...
        GrossRate(i)/Period(i); 
    
    % All Payment - Gross cash flow to Passthrough holder
    Payment(1:Term(i),i)   = ...
      OriginalBalance(i) * (GrossRate(i)/Period(i)) * ...
        ((1 + GrossRate(i)/Period(i)).^Term(i)) / ...
          ( (1 + GrossRate(i)/Period(i)).^Term(i) - 1);
    
    % All Principal
    Principal(1:Term(i),i) = ...
      OriginalBalance(i) * (GrossRate(i)/Period(i)) * ...
       ( (1 + GrossRate(i)/Period(i)).^(0:Term(i)-1)' ) / ...
         ( (1+GrossRate(i)/Period(i)).^Term(i) - 1);
end

%  [EOF]
