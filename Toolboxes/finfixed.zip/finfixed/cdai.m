function AccrInt = cdai(varargin)
%CDAI Accrued Interest of Certificate of Deposits (CD).
%   Rates are based on basis that can be optionally defined.
%
%   AccrInt = cdai(CouponRate, Settle, Maturity, IssueDate)
%   AccrInt = cdai(CouponRate, Settle, Maturity, IssueDate, Basis)
%
%   Optional Inputs: Basis
%
%   Inputs:
%        Rate - NCDx1 vector of coupon rate in decimal form.
%
%      Settle - NCDx1 vector of Settlement date.
%
%    Maturity - NCDx1 vector of Maturity date.
%
%   IssueDate - NCDx1 vector of Issue date of the CD.
%
%   Optional Inputs:
%       Basis - NCDx1 vector of Accrual basis.
%                0 - actual/actual
%                1 - 30/360 (SIA compliant) (default)
%                2 - actual/360
%                3 - actual/365
%                4 - 30/360 PSA
%                5 - 30/360 ISDA
%                6 - 30/360 European
%                7 - actual/365 Japanese
%                8 - actual/actual ISMA
%                9 - actual/360 ISMA
%               10 - actual/365 ISMA
%               11 - 30/360 ISMA
%               12 - actual/365 ISDA
%
%   Outputs:
%     AccrInt - NCDx1 vector of Accrued Interest per $100 face value.
%
%   Example:
%     Rate       = 0.05;
%     Settle     = '02-Jan-2002';
%     Maturity   = '31-Mar-2002';
%     IssueDate  = '01-Oct-2001';
%
%     AccrInt = cdai(Rate, Settle, Maturity, IssueDate)
%     AccrInt =
%         1.2917


%  Copyright 2002-2005 The MathWorks, Inc.
%  $Revision: 1.8.6.9 $   $Date: 2007/11/07 18:32:52 $

% Input arguments check
if nargin < 4
    error('finfixed:cdai:invalidInputs',...
        'Incorrect number of inputs.');

else
    CouponRate = varargin{1}(:);
    Settle     = datenum(varargin{2});
    Maturity   = datenum(varargin{3});
    IssueDate  = datenum(varargin{4});
end

if nargin < 5 || isempty(varargin{5})
    Basis = 2;

else
    Basis = varargin{5}(:);
    if any(~isvalidbasis(Basis))
        error('finfixed:cdai:invalidBasis',...
            'Invalid day count basis.');
    end
end

[CouponRate, Settle, Maturity, IssueDate, Basis] = ...
    finargsz(1, CouponRate, Settle(:), Maturity(:), IssueDate(:), Basis(:));

% making sure that IssueDate <= Settle <= Maturity
if any(IssueDate > Settle)
    error('finfixed:cdai:invalidIssueDate',...
        'IssueDate must be less than or equal to Settle.');
end

if any(Settle > Maturity)
    error('finfixed:cdai:invalidSettleDate',...
        'Settle must be less than or equal to Maturity.');
end

Tis = yearfrac(IssueDate, Settle, Basis);

% Tis: Time from Issue to Settle
AccrInt = 100 * CouponRate .* Tis;


% [EOF]
