function varargout = mbsyield2speed(Yield, Settle, Maturity, IssueDate,...
    GrossRate, PrepayMatrix, varargin)
%   MBSYIELD2SPEED Implied PSA prepayment speed given yields.
%      Calculate PSA prepayment speed implied by pool yields and projected
%      (user-defined) prepayment vectors. The calculated PSA speed will
%      produce the same yield, modified duration, or modified convexity
%      depending on output requested.
%
%    [ImpSpdOnYld, ImpSpdOnDur, ImpSpdOnCnv] = mbsyield2speed(Yield, ...
%       Settle, Maturity, IssueDate, GrossRate, PrepayMatrix)
%    [ImpSpdOnYld, ImpSpdOnDur, ImpSpdOnCnv] = mbsyield2speed(Yield, ...
%       Settle, Maturity, IssueDate, GrossRate, PrepayMatrix, ...
%       CouponRate)
%    [ImpSpdOnYld, ImpSpdOnDur, ImpSpdOnCnv] = mbsyield2speed(Yield, ...
%       Settle, Maturity, IssueDate, GrossRate, PrepayMatrix, ...
%       CouponRate, Delay);
%
%    Optional Inputs:  CouponRate, Delay
%
%    Inputs:
%                Yield - NMBSx1 vector of mortgage yield, in decimal and
%                        monthly compounded. 
%
%               Settle - NMBSx1 vector of settlement date.
%
%             Maturity - NMBSx1 vector of maturity date.
%
%            IssueDate - NMBSx1 vector of issue date.
%
%            GrossRate - NMBSx1 vector of gross coupon rate,
%                        in decimal.
%
%         PrepayMatrix - Customized prepayment vector. A matrix of size
%                        [max(TermRemaining) x NMBS]. Missing values are
%                        padded with NaNs.  Each column corresponds to each
%                        MBS, and each row corresponds to each month after
%                        settlement.
%
%    Optional Inputs:
%           CouponRate - NMBSx1 vector of Net Coupon Rate,
%                        in decimal.
%                        Default is equal to GrossRate.
%
%                Delay - NMBSx1 vector of delay in days.
%
%    Outputs:
%          ImpSpdOnYld - NMBSx1 vector of calculated equivalent PSA
%                        benchmark prepayment speed for the passthrough to
%                        carry the same yield. 
%
%          ImpSpdOnDur - NMBSx1 vector of calculated equivalent PSA
%                        benchmark prepayment speed for the passthrough to
%                        carry the same modified duration. 
%
%          ImpSpdOnCnv - NMBSx1 vector of calculated equivalent PSA
%                        benchmark prepayment speed for the passthrough to
%                        carry the same modified convexity. 
%
%    Example: Calculate the implied speed of the MBS from the mortgage
%             yield.
%      Yield     = 0.065;
%      Settle    = datenum('01-Jan-2000');
%      Maturity  = datenum('01-Jan-2030');
%      IssueDate = datenum('01-Jan-2000');
%      GrossRate = 0.08125;
%      PrepayMatrix = 0.005*ones(360,1);
%      CouponRate = 0.075;
%      Delay = 14;
% 
%     [ImpSpdOnYld, ImpSpdOnDur, ImpSpdOnCnv] = mbsyield2speed(Yield, ...
%         Settle, Maturity, IssueDate, GrossRate, PrepayMatrix, ...
%         CouponRate, Delay);
% 
%     ImpSpdOnYld =  
%         117.76435188
%     ImpSpdOnDur =
%         116.74363896
%     ImpSpdOnCnv = 
%         108.33089806
%
%   See also MBSPRICE2SPEED

%   Copyright 2002-2004 The MathWorks, Inc.
%   $Revision 1.9.6.3.2.1 $  $Date: 2005/06/17 20:25:27 $

if nargin > 8
    error('finfixed:mbsyield2speed:invalidMoreInputs',...
        sprintf(['Too many input arguments.\n',...
        'Type "help mbsyield2speed" for information.']));
end

if nargin < 6
    error('finfixed:mbsyield2speed:invalidLessInputs',...
        sprintf(['Need at least Yield, Settle, Maturity, IssueDate, \n',...
        'GrossRate, and PrepayMatrix.']));
else
    Settle    = datenum(Settle);
    Maturity  = datenum(Maturity);
    IssueDate = datenum(IssueDate);
    SMMRel    = PrepayMatrix;
end

if nargin <7 || isempty(varargin{1})
    CouponRate = GrossRate;
else
    CouponRate = varargin{1}(:);
end

if nargin <8 || isempty(varargin{2})
    Delay = 0;
else
    Delay = varargin{2}(:);
end

[Yield, Settle, Maturity, IssueDate, GrossRate, CouponRate, Delay] = ...
    finargsz(1, Yield(:), Settle(:), Maturity(:), IssueDate(:), ...
    GrossRate(:), CouponRate(:), Delay(:));

% Check and Expansion of SMMREl
colSMM = size(SMMRel,2);

if colSMM ~= length(Yield)
    if colSMM == 1
        SMMRel = SMMRel(:,ones(length(Yield),1));
    else
        error('finfixed:mbsyield2speed:invalidPrepayMatrix',...
            sprintf(['Size inconsistency, The number of column in ',...
            'prepayment \nmatrix must be equal to number of passthrough']));
    end
end

% Calculate clean price and accrued interest
Price = mbsprice(Yield, Settle, Maturity, IssueDate, GrossRate, ...
    CouponRate, Delay, [], SMMRel); 

% Calculate Speed with Price with mbsprice2speed
[SpeedPrc, SpeedDur, SpeedCnv] = mbsprice2speed(Price, Settle, Maturity,...
    IssueDate, GrossRate, PrepayMatrix, varargin{1:end});

% assign varargout
varargout = {SpeedPrc, SpeedDur, SpeedCnv};

% [EOF]
