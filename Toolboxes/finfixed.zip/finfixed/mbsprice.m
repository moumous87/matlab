function varargout = mbsprice(Yield, Settle, Maturity,  ...
     IssueDate, GrossRate, varargin )
%  MBSPRICE Passthrough price given its mortgage yield.
%     Theoretical prices of NMBS number of mortgage-pool
%     given their yields and prepayment assumptions.
%
%    [Price, AccrInt] = mbsprice(Yield, Settle, Maturity, IssueDate, ...
%       GrossRate)
%    [Price, AccrInt] = mbsprice(Yield, Settle, Maturity, IssueDate, ...
%       GrossRate, CouponRate)
%    [Price, AccrInt] = mbsprice(Yield, Settle, Maturity, IssueDate, ...
%       GrossRate, CouponRate, Delay)
%    [Price, AccrInt] = mbsprice(Yield, Settle, Maturity, IssueDate, ...
%       GrossRate, CouponRate, Delay, PrepaySpeed)
%    [Price, AccrInt] = mbsprice(Yield, Settle, Maturity, IssueDate, ...
%       GrossRate, CouponRate, Delay, [], PrepayMatrix)
%
%    Optional Inputs:  CouponRate, Delay, PrepaySpeed, PrepayMatrix
%
%    Inputs:
%             Yield - NMBSx1 vector of Mortgage yield in decimal
%                    (compounded monthly or 12 times annually) 
%
%            Settle - NMBSx1 vector of settlement date.
%
%          Maturity - NMBSx1 vector of maturity date.
%
%         IssueDate - NMBSx1 vector of issue date.
%
%         GrossRate - NMBSx1 vector of gross coupon rate, in decimal.
%
%    Optional Inputs:
%        CouponRate - NMBSx1 vector of Net Coupon Rate,
%                     in decimal.
%                     Default is equal to GrossRate.
%
%             Delay - NMBSx1 vector of delay in days.
%
%       PrepaySpeed - NMBSx1 vector of speed relative to
%                     PSA standard. PSA standard is 100.
%                     Default is 0 (zero) prepayment speed.
%
%      PrepayMatrix - Customized prepayment vector. A matrix of size
%                     [max(TermRemaining) x NMBS]. Missing values are
%                     padded with NaNs.  Each column corresponds to each
%                     MBS, and each row corresponds to each month after
%                     settlement.
%
%    Outputs:
%             Price - NMBSx1 vector of clean price for every $100 face
%                     value of securities. 
%
%           AccrInt - NMBSx1 vector of accrued interest of the mortgage
%                     backed securities. 
%
%    Example:
%      Yield = 0.0725;
%      Settle     = datenum('15-Apr-2002');
%      Maturity   = datenum('01 Jan 2030');
%      IssueDate  = datenum('01-Jan-2000');
%      GrossRate = 0.08125;
%      CouponRate = 0.075;
%      Delay = 14;
%      Speed = 100;
% 
%      [Price AccrInt] = mbsprice(Yield, Settle, Maturity, IssueDate,  ...
%             GrossRate, CouponRate, Delay, Speed)
%
%  See also MBSYIELD
%
%  Note: This function is PSA compliant.
%  Reference: PSA Uniform Practices, SF-49

%   Copyright 2002-2004 The MathWorks, Inc.
%   $Revision: 1.6.6.7 $  $Date: 2006/11/08 17:48:51 $

if nargin > 9
    error('finfixed:mbsprice:invalidMoreInputs',...
        'Too many input arguments. Type "help mbsyield" for information.');
end

if nargin < 5
    error('finfixed:mbsprice:invalidLessInputs',...
        'Need at least Settle, Maturity, IssueDate, and GrossRate.');
else
    Settle    = datenum(Settle);
    Maturity  = datenum(Maturity);
    IssueDate = datenum(IssueDate);
    if any(IssueDate > Settle)
        error('finfixed:mbsprice:invalidSettle',...
            sprintf(['Settle must be at, or after IssueDate.\n',...
            'Settle before IssueDate is unsupported at this time.']));
    end
end

if nargin <6 || isempty(varargin{1})
    CouponRate = GrossRate;
else
    CouponRate = varargin{1}(:);
end

if nargin <7 || isempty(varargin{2})
    Delay = 0;
else
    Delay = varargin{2}(:);
end

if nargin == 9;
    isCustomized = true;
else
    isCustomized = false;
end

if isCustomized 
    if ~isempty(varargin{3})
        error('finfixed:mbsprice:invalidPrepaySpeed',...
            sprintf(['Cannot use benchmark when supplying ', ...
            'customized prepayment CPR - Put \n', ...
            'empty matrices ([]) for 8th input arguments.']));
    end

    % check that prepayment is supplied and not empty.
    if isempty(varargin{4})
        error('finfixed:mbsprice:invalidPrepayMatrix',...
            sprintf(['Please supply a prepayment (SMM) \n', ...
            'matrix when you do not use benchmarked prepayment.']));
    else
        SMMRel = varargin{4};
    end

    [Yield, Settle, Maturity, IssueDate, GrossRate, ...
        CouponRate, Delay] = ...
        finargsz(1,Yield(:), Settle(:), Maturity(:), ...
        IssueDate(:), GrossRate(:), CouponRate(:), Delay(:));

    % Call mbscfamounts to get the Amounts and
    % Time the cash flows occurring when own prepayment is used
    [CFlowAmounts dummy TFactors] = mbscfamounts(Settle, Maturity,  ...
        IssueDate,GrossRate, CouponRate, Delay, [], SMMRel);

else

    if nargin < 8 || isempty(varargin{3})
        Speed = 0;
    else
        Speed = varargin{3};
    end

    % Expansion of scalar into vector when necessary
    [Yield, Settle, Maturity, IssueDate, GrossRate, ...
        CouponRate, Delay, Speed] = ...
        finargsz(1,Yield(:), Settle(:), Maturity(:), ...
        IssueDate(:), GrossRate(:), CouponRate(:), Delay(:), Speed(:));

    % Call mbscfamounts to get the Amounts and Time the
    % cash flows occurring when std benchmark used
    [CFlowAmounts dummy TFactors] = mbscfamounts(Settle, Maturity, IssueDate, ...
        GrossRate, CouponRate, Delay, Speed);
end

% Accrued interest is the first element of CFlowAmounts
AccrInt = -CFlowAmounts(:,1);

NumCF = size(CFlowAmounts, 2);

% Calculate the clean price
PerDisc = (1+Yield(:, ones(NumCF,1))/12).^(-TFactors);

% Compute the present value of every cash flow (including accrued
% interest payment at settlement)
CFlowPVs = CFlowAmounts .* PerDisc;

% Sum the present value cash flows horizontally to get the clean price
idx = isnan(CFlowPVs);

for i=1:size(CFlowPVs,1)
    Price(i) = sum(CFlowPVs(i,~idx(i,:)));
end

Price = Price(:);

varargout = {100*Price, 100*AccrInt, CFlowAmounts, TFactors};

% [EOF]
