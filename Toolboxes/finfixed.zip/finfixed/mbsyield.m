function varargout = mbsyield(Price, Settle, Maturity, IssueDate, ...
    GrossRate, varargin)
%MBSYIELD Mortgage pool yield to maturity given price and prepayment.
%   Theoretical yields of NMBS number of mortgage-pool given their prices and
%   prepayment assumptions.
%
%    [myield, bembsyld] = mbsyield(Price, Settle, Maturity, IssueDate, ...
%        GrossRate)
%    [myield, bembsyld] = mbsyield(Price, Settle, Maturity, IssueDate, ...
%        GrossRate, CouponRate)
%    [myield, bembsyld] = mbsyield(Price, Settle, Maturity, IssueDate, ...
%        GrossRate, CouponRate, Delay)
%    [myield, bembsyld] = mbsyield(Price, Settle, Maturity, IssueDate, ...
%        GrossRate, CouponRate, Delay, PrepaySpeed)
%    [mbsyld, bembsyld] = mbsyield(Price, Settle, Maturity, IssueDate,
%        GrossRate, CouponRate, Delay, [], PrepayMatrix)
%
%    Optional Inputs:  CouponRate, Delay, PrepaySpeed, PrepayMatrix
%
%    Inputs:
%             Price - NMBSx1 vector of clean price for every
%                     $100 face of issue.
%
%            Settle - NMBSx1 vector of settlement date.
%
%          Maturity - NMBSx1 vector of maturity date.
%
%         IssueDate - NMBSx1 vector of issue date.
%
%         GrossRate - NMBSx1 vector of gross coupon rate, in decimal.
%
%    Optional Inputs:
%        CouponRate - NMBSx1 vector of Net Coupon Rate, in decimal.
%                     Default is equal to GrossRate.
%
%             Delay - NMBSx1 vector of delay in days.
%
%       PrepaySpeed - NMBSx1 vector of speed relative to PSA standard. PSA
%                     standard is 100.
%                     Default is 0 (zero) prepayment speed.
%
%      PrepayMatrix - Customized prepayment vector. A matrix of size
%                     [max(TermRemaining) x NMBS]. Missing values are
%                     padded with NaNs.  Each column corresponds to each
%                     MBS, and each row corresponds to each month after
%                     settlement.
%
%    Outputs:
%            myield - NMBSx1 vector of yield to maturity of MBS, or
%                     mortgage yield.
%                     This yield is compounded monthly (12 times a year).
%
%          bembsyld - NMBSx1vector corresponding Bond equivalent yield of
%                     MBS.
%                     This yield is compounded semiannually (twice a year).
%
%
%    Example:
%       Price = 102;
%       Settle    = datenum('15-Apr-2002');
%       Maturity  = datenum('01 Jan 2030');
%       IssueDate = datenum('01-Jan-2000');
%       GrossRate = 0.08125;
%       CouponRate = 0.075;
%       Delay = 14;
%       Speed = 100;
%
%       [mbsyld, beyld] = mbsyield(Price, Settle, ...
%          Maturity, IssueDate, GrossRate, CouponRate, Delay, Speed)
%
%       mbsyld =
%         0.0714548624
%
%       beyld =
%         0.0725270532
%
%   See also MBSPRICE
%
%   Note: This function is PSA compliant.
%   Reference: PSA Uniform Practices, SF-49

%   Copyright 2002-2006 The MathWorks, Inc.
%   $Revision: 1.6.6.8 $  $Date: 2006/06/16 20:12:21 $

if nargin > 9
    error('finfixed:mbsyield:invalidMoreInputs',...
        'Too many input arguments. Type "help mbsyield" for information.');
end


if nargin < 5
    error('finfixed:mbsyield:invalidLessInputs',...
        'Need at least Price, Settle, Maturity, IssueDate, and GrossRate.');
else
    Settle    = datenum(Settle);
    Maturity  = datenum(Maturity);
    IssueDate = datenum(IssueDate);
    if any(IssueDate > Settle)
        error('finfixed:mbsyield:invalidSettle',...
            ['Settle must be at, or after IssueDate.\n',...
            'Settle before IssueDate is unsupported at this time']);
    end
end

if nargin < 6 || isempty(varargin{1})
    CouponRate = GrossRate;

else
    CouponRate = varargin{1}(:);
end

if nargin < 7 || isempty(varargin{2})
    Delay = 0;

else
    Delay = varargin{2}(:);
end

if (~isempty(varargin{3}) && nargin < 9 || isempty(varargin{4}))
    isCustomized = false;

else
    isCustomized = true;
end

% check that not both prepayment matrix and benchmark is empty
if (nargin < 8 || isempty(varargin{3}))&&(nargin < 9 ||isempty(varargin{4}))
    error('finfixed:mbsyield:invalidPrepayMatrix',...
        ['Please supply a prepayment(SMM) ',...
        'matrix when you do not use \nbenchmarked prepayment.']);
end

if isCustomized
    if ~isempty(varargin{3})
        error('finfixed:mbsyield:invalidPrepaySpeed',...
            ['Cannot use benchmark when supplying ',...
            'customized prepayment \nCPR - Put empty matrices ([]) for ',...
            '8th input arguments.']);
    end

    % check that prepayment is supplied and not empty.
    if isempty(varargin{4})
        error('finfixed:mbsyield:invalidPrepayMatrix',...
            ['Please supply a prepayment (SMM)\n', ...
            'matrix when you do not use benchmarked prepayment.']);

    else
        SMMRel = varargin{4};
    end

    % Call mbscfamounts to get cashflows when own prepayment is used
    [Price, Settle, Maturity, IssueDate, GrossRate, ...
        CouponRate, Delay] = ...
        finargsz(1,Price(:), Settle(:), Maturity(:), ...
        IssueDate(:), GrossRate(:), CouponRate(:), Delay(:));

    [CFlowAmounts dummy TFactor Factor] = ...
        mbscfamounts(Settle, Maturity, IssueDate, ...
        GrossRate, CouponRate, Delay, [], SMMRel); %#ok
else

    if nargin < 8 || isempty(varargin{3})
        Speed = 0;

    else
        Speed = varargin{3};
    end

    [Price, Settle, Maturity, IssueDate, GrossRate, ...
        CouponRate, Delay, Speed] = ...
        finargsz(1,Price(:), Settle(:), Maturity(:), IssueDate(:), ...
        GrossRate(:), CouponRate(:), Delay(:), Speed(:));

    % Call mbscfamounts to get cashflows when std benchmark used
    [CFlowAmounts dummy TFactor Factor] = ...
        mbscfamounts(Settle, Maturity, IssueDate, ...
        GrossRate, CouponRate, Delay, Speed); %#ok
end

% Subtract clean/quoted Price into the accrued interest to get NPV = 0
CFlowAmounts(:, 1) = CFlowAmounts(:, 1) - Price/100;
NumCF = size(CFlowAmounts, 2);

% use rate as first guess
x0 = 1./(1+CouponRate/12);

% Set options for FSOLVE
options1 = optimset('fzero');
options1 = optimset(options1 , 'Display', 'off');
options1 = optimset(options1 , 'TolX', 1e-10);

% if scalar use fzero first for speed purpose
if (numel(x0)<2)
    [X,FVAL,EXITFLAG] = fzero(@mbsintfun, x0, options1, ...
        CFlowAmounts, TFactor, NumCF);  %#ok

else
    EXITFLAG = -1;
end

% if fzero was unable to find a zero, try using fsolve
if (EXITFLAG < 0)
    fsoption = optimset('fsolve');
    fsoption = optimset(fsoption, 'TolX', 1e-14);
    fsoption = optimset(fsoption, 'TolFun', 1e-12);
    fsoption = optimset(fsoption, 'Display', 'off');
    fsoption = optimset(fsoption, 'LargeScale', 'off');

    [X,FVAL,EXITFLAG] = ...
        fsolve(@mbsintfun, x0, fsoption, CFlowAmounts, TFactor, NumCF);  %#ok
end

if (EXITFLAG <0)
    % convergence failure
    warning('finfixed:mbsyield:solutionConvergenceFailure',...
        'Could not solve for the yield.\n');
end

varargout{1} = ( 1./X - 1 ).*12; % Mortgage Yield
varargout{2} = 2*((1+varargout{1}/12).^6 - 1); % BE Yield
varargout{3} = CFlowAmounts;
varargout{4} = TFactor;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% This internal function computes the NPV
% of cash flows. The correct discount will
% sum dcf to zero.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function y = mbsintfun(x, CF, TF, b)

dcf = CF .* x(:, ones(b, 1)).^TF;
y = nansum(dcf, 2);


% [EOF]
