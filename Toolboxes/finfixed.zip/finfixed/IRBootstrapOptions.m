classdef IRBootstrapOptions < handle
%IRBOOTSTRAPOPTIONS Controls options for 
%   The IRBOOTSTRAPOPTIONS object allows the user to specify options
%   relating to the bootstrapping of an IRDATACURVE.  An IRBOOTSTRAPOPTIONS
%   object has the following property:
%
%   ConvexityAdjustment: Controls the convexity adjustment to interest rate
%   futures -- can be specified as a function handle that takes time to
%   maturity as an input or as an Nx1 vector of values, where N is the
%   number of interest rate futures
% 
% See also IRDATACURVE

% Copyright 2008 The MathWorks, Inc.  
% $Revision: 1.1.6.3 $   $Date: 2008/06/16 16:38:22 $

    properties (SetAccess = protected, GetAccess = public)
        ConvexityAdjustment
    end
    methods
        function obj = IRBootstrapOptions(varargin)
            %IRBOOTSTRAPOPTIONS Create an IR Bootstrap Options structure
            %   IRBO = IRBOOTSTRAPOPTIONS('CONVEXITYADJUSTMENT',@FUN) 
            %   creates an IR Bootstrap Options structure
            %
            %   Optional input arguments are specified in parameter value
            %   pairs, and include the following options:
            %
            %   ConvexityAdjustment
            %
            %   Example: Create with an initial guess
            %
            %     r = IRBootstrapOptions('ConvexityAdjustment',@(t) t.^2*.01.^2)
            %

            p = inputParser;
            
            p.addParamValue('convexityadjustment',[]);
            
            try
                p.parse(varargin{:});
            catch ME
                newME = MException('finfixed:IRBootstrapOptions:optionalInputError',...
                                    'Error in optional parameter value inputs');
                newME = addCause(newME,ME);
                throw(newME)
            end
            
            inConvAdj = p.Results.convexityadjustment;
            if isa(inConvAdj,'function_handle') || isa(inConvAdj,'numeric')
                obj.ConvexityAdjustment = inConvAdj;
            else
                error('finfixed:IRBootstrapOptions:convextiyAdjustment',...
                    'Convexity Adjustment must be a function handle or a vector')
            end
            
        end
    end
end