classdef IRFunctionCurve < IRCurve
    %IRFUNCTIONCURVE Interest rate curve represented with function
    %   An IRFUNCTIONCURVE is a representation of an interest
    %   rate curve with a function.  This can be constructed
    %   directly by specifying a function handle or a function can be
    %   fit to market data using methods of the object.  Once a curve has been
    %   constructed, forward and zero rates and discount factors can be
    %   extracted and it can be converted to a RateSpec structure -- and
    %   used with functions in the Financial Derivatives Toolbox.
    %
    %   An interest rate function curve has the following properties:
    %
    %   Type: Type of Curve, either Forward, Zero, or Discount
    %   Settle: Settle date
    %   Compounding: Compounding for curve, acceptable values are
    %   -1,1,2 (default) ,3,4,6,12
    %   Basis: Day-count basis.
    %       Possible values include:
    %           0 - actual/actual (default)
    %           1 - 30/360 SIA
    %           2 - actual/360
    %           3 - actual/365
    %           4 - 30/360 PSA
    %           5 - 30/360 ISDA
    %           6 - 30/360 European
    %           7 - actual/365 Japanese
    %           8 - actual/actual ISMA
    %           9 - actual/360 ISMA
    %           10 - actual/365 ISMA
    %           11 - 30/360 ISMA
    %           12 - actual/365 ISDA
    %   FunctionHandle: Function that defines the interest rate curve
    %
    %   An interest rate data curve has the following methods:
    %
    %   GETFORWARDRATES: Returns forward rates for input dates
    %   GETZERORATES: Returns zero rates for input dates
    %   GETDISCOUNTFACTORS: Returns discount factors for input dates
    %
    %   Optional inputs to the above methods are basis and compounding
    %
    %   TORATESPEC: Converts to be a RateSpec object, like the ones produced by
    %   INTENVSET, for input dates
    %   FITSMOOTHINGSPLINE: Fits a smoothing spline to market data
    %   FITSNELSONSIEGEL: Fits a smoothing spline to market data
    %   FITSVENSSON: Fits a smoothing spline to market data
    %   FITFUNCTION: Fits a user specified function to market data
    %
    % See also IRCURVE, IRFITOPTIONS
    
    % References:
    %
    % [1] Nelson, C.R., Siegel, A.F., (1987), "Parsimonious modelling of yield
    %     curves", Journal of Business, 60, pp 473-89
    %
    % [2] Svensson, L.E.O. (1994), "Estimating and interpreting forward interest
    %     rates: Sweden 1992-4", International Monetary Fund, IMF Working Paper,
    %     1994/114
    %
    % [3] Fisher, M., Nychka, D., Zervos, D. (1995), "Fitting the term
    %     structure of interest rates with smoothing splines", Board of Governors
    %     of the Federal Reserve System, Federal Reserve Board Working Paper 95-1
    %
    % [4] Anderson, N., Sleath, J. (1999), "New estimates of the UK real and
    %     nominal yield curves", Bank of England Quarterly Bulletin, November, pp
    %     384-92
    
    %   Copyright 2008 The MathWorks, Inc.
    %   $Revision: 1.1.6.2.2.1 $  $Date: 2008/08/01 15:31:50 $
    
    properties (SetAccess = protected, GetAccess = public)
        FunctionHandle
    end
    
    methods
        function obj = IRFunctionCurve(Type,Settle,functionHandle,varargin)
            %IRFUNCTIONCURVE Create an interest rate function curve.
            %   IRFC = IRFUNCTIONCURVE(TYPE,SETTLE) creates a curve with specified
            %   Type and Settle date
            %
            %   IRFC = IRFUNCTIONCURVE(TYPE, SETTLE, FUNCTIONHANDLE) creates
            %   a function curve with a function handle specified
            %
            %   Optional inputs include BASIS and COMPOUNDING, specified in parameter
            %   value pairs
            %
            %   Example:  Create a curve
            %
            %           c = IRFunctionCurve('Forward',today);
            %
            %   Example: Create a curve with dates and data
            %
            %           c = IRFunctionCurve('Forward',today,...
            %                           @(t) polyval([-0.0001 0.003 0.02],t));
            %
            
            % Parse inputs
            if all(~strcmpi(Type,{'forward','zero','discount'}))
                error('finfixed:IRFunctionCurve:invalidType',...
                    'Type must be forward, zero, or discount')
            end
            
            obj.Type = Type;
            try
                obj.Settle = datenum(Settle);
            catch E
                error('finfixed:IRFunctionCurve:invalidSettle',...
                    'Settle must be a Date')
            end
            
            if nargin > 2
                if isa(functionHandle,'function_handle') || isempty(functionHandle)
                    obj.FunctionHandle = functionHandle;
                else
                    error('finfixed:IRFunctionCurve:invalidFunctionHandle',...
                        'Please specify a valid function handle')
                end
            end
            
            % Parse inputs
            p = inputParser;
            
            p.addParamValue('compounding',2,@(x) ismember(x,[-1 1 2 3 4 6 12]));
            p.addParamValue('basis',0,@(x) ismember(x,0:12));
            
            try
                p.parse(varargin{:});
            catch ME
                newME = MException('finfixed:IRFunctionCurve:optionalInputError',...
                    'Error in optional parameter value inputs');
                newME = addCause(newME,ME);
                throw(newME)
            end
            
            obj.Compounding = p.Results.compounding;
            obj.Basis = p.Results.basis;
            
        end
        function outForwardRates = getForwardRates(obj,inpDates,varargin)
            %IRFUNCTIONCURVE/GETFORWARDRATES Get Forward Rates for input dates
            %   RATES = GETFORWARDRATES(IRFC,INPDATES) returns forward
            %   rates for the input dates -- where INPDATES is an N X 1 
            %   vector of MATLAB date numbers after the Curve Settle.
            %
            %   Optional inputs include output BASIS and COMPOUNDING,
            %   specified in parameter value pairs
            %
            %   Example:  Get rates
            %
            %   ForwardRates = getForwardRates(IRFC,[today:30:today+365])
            %
            inpDates = inpDates(:);
            [OutComp,OutBasis] = locParseOptional(varargin{:});
            if isempty(OutComp),OutComp = obj.Compounding;end
            if isempty(OutBasis),OutBasis = obj.Basis;end
            TimeToMaturity = yearfrac(obj.Settle,inpDates(:),obj.Basis);
            switch lower(obj.Type)
                case 'forward'
                    outForwardRates = feval(obj.FunctionHandle,TimeToMaturity);
                    outForwardRates = locConvert(outForwardRates,obj.Compounding,...
                        obj.Basis,OutComp,OutBasis);
                case 'zero'
                    ZeroRates = feval(obj.FunctionHandle,TimeToMaturity);
                    outForwardRates = zero2fwd(ZeroRates(:),inpDates(:), ...
                        obj.Settle, obj.Compounding, obj.Basis,OutComp,OutBasis);
                case 'discount'
                    DiscountRates = feval(obj.FunctionHandle,TimeToMaturity);
                    ZeroRates = disc2zero(DiscountRates,inpDates, ...
                        obj.Settle, obj.Compounding, obj.Basis);
                    
                    outForwardRates = zero2fwd(ZeroRates,inpDates, ...
                        obj.Settle, obj.Compounding, obj.Basis,OutComp,OutBasis);
            end
        end
        function outZeroRates = getZeroRates(obj,inpDates,varargin)
            %IRFUNCTIONCURVE/GETZERORATES Get Zero Rates for input dates
            %   RATES = GETZERORATES(IRFC,INPDATES) returns zero
            %   rates for the input dates -- where INPDATES is an N X 1 
            %   vector of MATLAB date numbers after the Curve Settle.
            %
            %   Optional inputs include output BASIS and COMPOUNDING,
            %   specified in parameter value pairs
            %
            %   Example:  Get rates
            %
            %   ZeroRates = getZeroRates(IRFC,[today:30:today+365])
            %
            inpDates = inpDates(:);
            [OutComp,OutBasis] = locParseOptional(varargin{:});
            if isempty(OutComp),OutComp = obj.Compounding;end
            if isempty(OutBasis),OutBasis = obj.Basis;end
            TimeToMaturity = yearfrac(obj.Settle,inpDates,obj.Basis);
            switch lower(obj.Type)
                case 'forward'
                    ZeroRates = zeros(size(TimeToMaturity));
                    for jdx=1:length(TimeToMaturity)
                        ZeroRates(jdx) = quadl(obj.FunctionHandle,0,TimeToMaturity(jdx));
                    end
                    outZeroRates = ZeroRates./TimeToMaturity;
                case 'zero'
                    tmpZeroRates = feval(obj.FunctionHandle,TimeToMaturity);
                    outZeroRates = locConvert(tmpZeroRates,obj.Compounding,...
                        obj.Basis,OutComp,OutBasis);
                case 'discount'
                    DiscountRates = feval(obj.FunctionHandle,TimeToMaturity);
                    outZeroRates = disc2zero(DiscountRates,inpDates, ...
                        obj.Settle, obj.Compounding, obj.Basis);
            end
        end
        function outParYields = getParYields(obj,inpDates,varargin)
            %IRFUNCTIONCURVE/GETPARYIELDS Get Par Yields for input dates
            %   PARYIELDS = GETPARYIELDS(IRFC,INPDATES) returns par
            %   yields for the input dates -- where INPDATES is an N X 1 
            %   vector of MATLAB date numbers after the Curve Settle.
            %
            %   Optional inputs include output BASIS and COMPOUNDING,
            %   specified in parameter value pairs
            %
            %   Example:  Get par yields
            %
            %   ParYields = getParYields(IRFC,[today:30:today+365])
            %
            inpDates = inpDates(:);
            [OutComp,OutBasis] = locParseOptional(varargin{:});
            if isempty(OutComp),OutComp = obj.Compounding;end
            if isempty(OutBasis),OutBasis = obj.Basis;end
            TimeToMaturity = yearfrac(obj.Settle,inpDates,obj.Basis);
            switch lower(obj.Type)
                case 'forward'
                    ZeroRates = zeros(size(TimeToMaturity));
                    for jdx=1:length(TimeToMaturity)
                        ZeroRates(jdx) = quadl(obj.FunctionHandle,0,TimeToMaturity(jdx));
                    end
                    ZeroRates = ZeroRates./TimeToMaturity;
                    outParYields = zero2pyld(ZeroRates, inpDates, obj.Settle,...
                        OutComp,OutBasis, obj.Compounding,obj.Basis);
                case 'zero'
                    tmpZeroRates = feval(obj.FunctionHandle,TimeToMaturity);
                    ZeroRates = locConvert(tmpZeroRates,obj.Compounding,...
                        obj.Basis,OutComp,OutBasis);
                    outParYields = zero2pyld(ZeroRates, inpDates, obj.Settle,...
                        OutComp,OutBasis, obj.Compounding,obj.Basis);
                case 'discount'
                    DiscountRates = feval(obj.FunctionHandle,TimeToMaturity);
                    ZeroRates = disc2zero(DiscountRates,inpDates, ...
                        obj.Settle, obj.Compounding, obj.Basis);
                    outParYields = zero2pyld(ZeroRates, inpDates, obj.Settle,...
                        OutComp,OutBasis, obj.Compounding,obj.Basis);
            end
        end
        function outDF = getDiscountFactors(obj,inpDates)
            %IRFUNCTIONCURVE/GETDISCOUNTFACTORS Get Discount Factors for input dates
            %   RATES = GETDISCOUNTFACTORS(IRFC,INPDATES) returns discount
            %   factors for the input dates -- where INPDATES is an N X 1 
            %   vector of MATLAB date numbers after the Curve Settle.
            %
            %   Example:  Get discount factors
            %
            %   ZeroRates = getDiscountFactors(IRFC,[today:30:today+365])
            %
            inpDates = inpDates(:);
            TimeToMaturity = yearfrac(obj.Settle,inpDates,obj.Basis);
            switch lower(obj.Type)
                case 'forward'
                    ZeroRates = zeros(size(TimeToMaturity));
                    for jdx=1:length(TimeToMaturity)
                        ZeroRates(jdx) = quadl(obj.FunctionHandle,0,TimeToMaturity(jdx));
                    end
                    ZeroRates = ZeroRates./TimeToMaturity;
                    
                    outDF = zero2disc(ZeroRates, inpDates, obj.Settle,...
                        obj.Compounding,obj.Basis);
                case 'zero'
                    tmpZeroRates = feval(obj.FunctionHandle,TimeToMaturity);
                    ZeroRates = locConvert(tmpZeroRates,obj.Compounding,...
                        obj.Basis,obj.Compounding,obj.Basis);
                    outDF = zero2disc(ZeroRates, inpDates, obj.Settle,...
                        obj.Compounding,obj.Basis);
                case 'discount'
                    outDF = feval(obj.FunctionHandle,TimeToMaturity);
            end
        end
        function RateSpec = toRateSpec(obj,inpDates)
            %IRFUNCTIONCURVE/TORATESPEC Converts to RateSpec
            %   RATESPEC = TORATESPEC(IRFC,INPDATES) returns a RateSpec
            %   object, like the one created by INTENVSET -- where INPDATES
            %   is an N X 1 vector of MATLAB date numbers after the Curve Settle.
            %
            %   Example:  Get a rate spec
            %
            %   RateSpec = toRateSpec(IRFC,[today:30:today+365])
            %
            inpDates = inpDates(:);
            ZeroRates = getZeroRates(obj,inpDates);
            RateSpec = intenvset('Rates', ZeroRates(:), 'EndDates',...
                inpDates(:),'StartDates',obj.Settle,...
                'Basis',obj.Basis,'Compounding',obj.Compounding);
        end
    end
    methods(Static = true)
        function obj = fitFunction(Type, CurveSettle, functionHandle,...
                Instruments, FitOptions, varargin)
            %IRFUNCTIONCURVE/FITFUNCTION Fits function to market data
            %   IRFC = IRFUNCTIONCURVE.FITFUNCTION(TYPE, SETTLE,...
            %                     FUNCTIONHANDLE,INSTRUMENTS,FITOPTIONS)
            %   fits an interest rate function curve to market data.  The
            %   function must accept two input arguments, time and a vector
            %   of parameters to be fit, and return one output:
            %   the rate specified by the curve (either Forward, Zero,
            %   or Discount).
            %
            %   TYPE: Forward, Zero
            %   SETTLE: Settle date
            %   FUNCTIONHANDLE: Function handle to be fit
            %   INSTRUMENTS: N X 4 data matrix for Instruments where the
            %   first column is Settle date, the second column is Maturity,
            %   the third column is Dirty Price and the fourth column is
            %   Coupon Rate.
            %
            %   FITFUNCTION can also be called with the following optional input
            %   parameters, specified in parameter value pairs, where these
            %   input arguments correspond to those in the class definition
            %   above.
            %
            %   BASIS
            %   COMPOUNDING
            %   IRFITOPTIONS: An IRFITOPTIONS object
            %
            %   Note that additional instrument parameters (Basis,
            %   Period, etc.) may be passed in via parameter value pairs by
            %   prepending the word 'instrument' to the parameter field
            %   (this distinguishes, for example, the instrument basis from
            %   the curve basis), e.g. the basis for all instruments would
            %   be specified by the parameter 'InstrumentBasis'.
            %
            %   Further note that simple interest can be specified for an
            %   instrument by specifying the period as 0.
            %
            %   Finally, if instrument basis and instrument period are
            %   not specified, the following default values are used:
            %
            %   Basis: 0 (act/act), Period: 2
            
            % Parse inputs
            p = inputParser;
            
            p.addRequired('type',@ischar);
            p.addRequired('settle');
            p.addRequired('functionhandle',@(x) isa(x,'function_handle'));
            p.addRequired('instruments',@isnumeric);
            p.addRequired('FitOptions',@(x) isa(x,'IRFitOptions'));
            
            p.addParamValue('compounding',2);
            p.addParamValue('basis',0);
            
            % No error checks here as INSTARGBOND will be used
            p.addParamValue('instrumentperiod',2);
            p.addParamValue('instrumentcouponrate',[]);
            p.addParamValue('instrumentbasis',0);
            p.addParamValue('instrumentendmonthrule',1);
            p.addParamValue('instrumentissuedate', []);
            p.addParamValue('instrumentfirstcoupondate', []);
            p.addParamValue('instrumentlastcoupondate', []);
            p.addParamValue('instrumentstartdate', []);
            p.addParamValue('instrumentface',100);
            
            try
                p.parse(Type, CurveSettle, functionHandle,Instruments,...
                                    FitOptions,varargin{:});
            catch ME
                newME = MException('finfixed:IRFunctionCurve:optionalInputError',...
                    'Error in optional parameter value inputs');
                newME = addCause(newME,ME);
                throw(newME)
            end
            
            Settle = Instruments(:,1);
            Maturity = Instruments(:,2);
            DirtyPrice = Instruments(:,3);
            CouponRate = Instruments(:,4);
            Compounding = p.Results.compounding;
            CurveBasis = p.Results.basis;
            Period = p.Results.instrumentperiod;
            Basis = p.Results.instrumentbasis;
            EndMonthRule = p.Results.instrumentendmonthrule;
            IssueDate = p.Results.instrumentissuedate;
            FirstCouponDate = p.Results.instrumentfirstcoupondate;
            LastCouponDate = p.Results.instrumentlastcoupondate;
            StartDate = p.Results.instrumentstartdate;
            Face = p.Results.instrumentface;
            
            % Confirm that the instrument settle is equal to the curve
            % settle
            Settle = unique(Settle);
            try
                Settle = datenum(Settle);
            catch E
                error('finfixed:IRFunctionCurve:invalidInstrumentSettle',...
                    'Instrument settle must be a Date')
            end
            if length(Settle) > 1 || Settle ~= CurveSettle
                error('finfixed:IRFunctionCurve:invalidSettle',...
                    ['Settle must be identical for all instruments and ' ...
                    'to the interest rate curve'])
            end
            
            % Construct an object with the inputs
            obj = IRFunctionCurve(Type,CurveSettle,[],...
                'Compounding',Compounding,'Basis',CurveBasis);
            
            % Because we are indexing in -- we need to scalar expand all
            % inputs
            [CouponRate, Settle, Maturity, Period, Basis, EndMonthRule, IssueDate, ...
                FirstCouponDate, LastCouponDate, StartDate, Face] = ...
                instargbond(CouponRate, Settle, Maturity, Period,...
                Basis, EndMonthRule, IssueDate, FirstCouponDate, LastCouponDate,...
                StartDate, Face);
            
            if strcmpi(FitOptions.FitType,'yield')
                ObservedYield =  bndyield(DirtyPrice, CouponRate, Settle, ...
                    Maturity, Period, Basis,EndMonthRule, ...
                    IssueDate, FirstCouponDate, LastCouponDate,...
                    StartDate, Face);
            elseif strcmpi(FitOptions.FitType,'durationweightedprice')
                Duration = bnddurp(DirtyPrice,CouponRate, Settle, Maturity,...
                    Period, Basis, EndMonthRule, IssueDate, ...
                    FirstCouponDate, LastCouponDate, StartDate, Face);
            end
            
            [CFlowAmounts, CFlowDates, TFactors] = cfamounts(CouponRate, Settle, Maturity);
            [CFBondDate, AllDates] = cfport(CFlowAmounts,CFlowDates,TFactors);
            
            % This addresses the case where payment dates are
            % on the settle
            if AllDates(1) == obj.Settle
                AllDates(1) = [];
                doAddSettle = 1;
            else
                doAddSettle = 0;
            end
            
            % Find the time to maturity for each of the payment dates
            t = yearfrac(obj.Settle,AllDates,obj.Basis);
            
            function f = costfun(x)
                
                Rates = functionHandle(t,x);
                
                switch Type
                    case 'Zero'
                        ZeroRate = Rates;
                        DF = zero2disc(ZeroRate,AllDates,obj.Settle,obj.Compounding,obj.Basis);
                    case 'Discount'
                        DF = Rates;
                    case 'Forward'
                        ZeroRates = zeros(size(t));
                        for jdx=1:length(t)
                            ZeroRates(jdx) = quadl(@(t) functionHandle(t,x),0,t(jdx));
                        end
                        ZeroRates = ZeroRates./t;

                        DF = zero2disc(ZeroRates,AllDates,obj.Settle,obj.Compounding,obj.Basis);
                end
                
                if doAddSettle
                    DF = [1;DF];
                end
                
                Pi = CFBondDate*DF;
                
                switch lower(FitOptions.FitType)
                    case 'price'
                        f = DirtyPrice - Pi;
                    case 'yield'
                        Yield = bndyield(Pi, CouponRate, Settle, ...
                            Maturity, Period, Basis,EndMonthRule, ...
                            IssueDate, FirstCouponDate, LastCouponDate,...
                            StartDate, Face);
                        f = ObservedYield - Yield;
                    case 'durationweightedprice'
                        f = (DirtyPrice - Pi)./Duration;
                end
                
            end
            
            x0 = FitOptions.InitialGuess;
            ub = FitOptions.UpperBound;
            lb = FitOptions.LowerBound;
            options = FitOptions.OptOptions;
            
            [Params,resnorm,residual,exitflag] = lsqnonlin(@costfun,x0,lb,ub,options);
            
            if (exitflag == 0)
                warning('finfixed:IRFunctionCurve:LimitExceeded',...
                    'Function evaluation or iteration limit exceeded');
            elseif (exitflag < 0)
                error('finfixed:IRFunctionCurve:NoSolution',...
                    'Error in optimization, check curve function')
            end
            
            obj.FunctionHandle = @(t) functionHandle(t,Params);
            
        end
        
        function obj = fitNelsonSiegel(Type,CurveSettle,Instruments,varargin)
            %IRFUNCTIONCURVE/FITNELSONSIEGEL Fits Nelson Siegel function to market data
            %   IRFC = IRFUNCTIONCURVE.FITNELSONSIEGEL(TYPE,
            %   SETTLE,INSTRUMENTS) fits a Nelson Siegel function
            %   to market data.
            %
            %   The Nelson Siegel function for the forward rate is the
            %   following:
            %
            %   f = Beta0 + Beta1*(exp(-t/Tau1)) +
            %   Beta2*(t/Tau1).*(exp(-t/Tau1))
            %
            %   TYPE: Forward, Zero
            %   SETTLE: Settle date
            %   INSTRUMENTS: N X 4 data matrix for Instruments where the
            %   first column is Settle date, the second column is Maturity,
            %   the third column is Dirty Price and the fourth column is
            %   Coupon Rate.
            %
            %   FITNELSONSIEGEL can also be called with the following optional input
            %   parameters, specified in parameter value pairs, where these
            %   input arguments correspond to those in the class definition
            %   above.
            %
            %   BASIS
            %   COMPOUNDING
            %   IRFITOPTIONS: An IRFITOPTIONS object
            %
            %   Note that additional instrument parameters (Basis,
            %   Period, etc.) may be passed in via parameter value pairs by
            %   prepending the word 'instrument' to the parameter field
            %   (this distinguishes, for example, the instrument basis from
            %   the curve basis), e.g. the basis for all instruments would
            %   be specified by the parameter 'InstrumentBasis'.
            %
            %   Further note that simple interest can be specified for an
            %   instrument by specifying the period as 0.
            %
            %   Finally, if instrument basis and instrument period are
            %   not specified, the following default values are used:
            %
            %   Basis: 0 (act/act), Period: 2
            
            switch Type
                case 'Forward'
                    functionHandle = @nelsonsiegelforward;
                case 'Zero'
                    functionHandle = @nelsonsiegelzero;
                otherwise
                    error('finfixed:IRFunctionCurve:invalidNelsonSiegelType',...
                        'FITNELSONSIEGEL requires either a Forward or Zero curve')
            end
            
            % Find out if an options structure has been input
            if any(strcmpi(varargin,'IRFitOptions'))
                optidx = find(strcmpi(varargin,'IRFitOptions')) + 1;
                fIRFitO = varargin{optidx};
                varargin(optidx-1:optidx) = [];
            else
                fIRFitO = IRFitOptions([7 -4 -2 2]);
                fIRFitO.LowerBound = [0 -Inf -Inf 0];
                fIRFitO.UpperBound = [Inf Inf Inf Inf];
                fIRFitO.OptOptions = optimset('lsqnonlin');
                fIRFitO.FitType = 'durationweightedprice';
            end
            
            obj = IRFunctionCurve.fitFunction(Type, CurveSettle, functionHandle,...
                Instruments, fIRFitO,varargin{:});
            
        end
        
        function obj = fitSvensson(Type,CurveSettle,Instruments,varargin)
            %IRFUNCTIONCURVE/FITSVENSSON Fits Svensson function to market data
            %   IRFC = IRFUNCTIONCURVE.FITSVENSSON(TYPE,
            %   SETTLE,INSTRUMENTS) fits a Svensson function to market data.
            %
            %   The Svensson function for the forward rate is the
            %   following:
            %
            %   f = Beta0 + Beta1*(exp(-t/Tau1)) + Beta2*(t/Tau1).*(exp(-t/Tau1)) + ...
            %   Beta3*(t/Tau2).*(exp(-t/Tau2));
            %
            %   TYPE: Forward, Zero
            %   SETTLE: Settle date
            %   INSTRUMENTS: N X 4 data matrix for Instruments where the
            %   first column is Settle date, the second column is Maturity,
            %   the third column is Dirty Price and the fourth column is
            %   Coupon Rate.
            %
            %   FITSVENSSON can also be called with the following optional input
            %   parameters, specified in parameter value pairs, where these
            %   input arguments correspond to those in the class definition
            %   above.
            %
            %   BASIS
            %   COMPOUNDING
            %   IRFITOPTIONS: An IRFITOPTIONS object
            %
            %   Note that additional instrument parameters (Basis,
            %   Period, etc.) may be passed in via parameter value pairs by
            %   prepending the word 'instrument' to the parameter field
            %   (this distinguishes, for example, the instrument basis from
            %   the curve basis), e.g. the basis for all instruments would
            %   be specified by the parameter 'InstrumentBasis'.
            %
            %   Further note that simple interest can be specified for an
            %   instrument by specifying the period as 0.
            %
            %   Finally, if instrument basis and instrument period are
            %   not specified, the following default values are used:
            %
            %   Basis: 0 (act/act), Period: 2
            
            switch Type
                case 'Forward'
                    functionHandle = @svenssonforward;
                case 'Zero'
                    functionHandle = @svenssonzero;
                otherwise
                    error('finfixed:IRFunctionCurve:invalidSvenssonType',...
                        'FITSVENSSON requires either a Forward or Zero curve')
            end
            
            % Find out if an options structure has been input
            if any(strcmpi(varargin,'IRFitOptions'))
                optidx = find(strcmpi(varargin,'IRFitOptions')) + 1;
                fIRFitO = varargin{optidx};
                varargin(optidx-1:optidx) = [];
            else
                fIRFitO = IRFitOptions([5.82 -2.55 -.87 0.45 3.9 0.44]);
                fIRFitO.LowerBound = [0 -Inf -Inf -Inf 0 0];
                fIRFitO.UpperBound = [Inf Inf Inf Inf Inf Inf];
                fIRFitO.OptOptions = optimset('lsqnonlin');
                fIRFitO.FitType = 'durationweightedprice';
            end
            
            obj = IRFunctionCurve.fitFunction(Type, CurveSettle, functionHandle,...
                Instruments, fIRFitO,varargin{:});
        end
        
        function obj = fitSmoothingSpline(Type, CurveSettle,...
                Instruments, lambdafun, varargin)
            %IRFUNCTIONCURVE/FITSMOOTHINGSPLINE Fits smoothing spline to market data
            %   IRFC = IRFUNCTIONCURVE.FITSMOOTHINGSPLINE(TYPE,
            %   SETTLE,INSTRUMENTS,LAMBDAFUN) fits a smoothing spline to market data.
            %
            %   The smoothing spline in this case represents the forward
            %   curve.  The spline is penalized for curvature by specifying
            %   a penalty function.
            %
            %   Note that the fit may only be done with duration weighted
            %   price.
            %
            %   TYPE: Forward, Zero
            %   SETTLE: Settle date
            %   INSTRUMENTS: N X 4 data matrix for Instruments where the
            %   first column is Settle date, the second column is Maturity,
            %   the third column is Dirty Price and the fourth column is
            %   Coupon Rate.
            %   LAMBDAFUN: Penalty function that takes as its input time
            %   and returns a penalty value
            %
            %   FITSMOOTHINGSPLINE can also be called with the optional input
            %   parameters BASIS and COMPOUNDING, specified in parameter
            %   value pairs, where these input arguments correspond to those
            %   in the class definition above.
            %
            %   An additional optional input parameter is a vector of
            %   knots, specified as a parameter value pair, where the knots
            %   are specified as times to maturity.  The default value for
            %   knots is a vector consisting of 0 and the time to maturity
            %   of the input instruments.
            %
            %   Note that FITSMOOTHINGSPLINE does not take an IRFITOPTIONS
            %   object as an input.
            %
            %   Note that additional instrument parameters (Basis,
            %   Period, etc.) may be passed in via parameter value pairs by
            %   prepending the word 'instrument' to the parameter field
            %   (this distinguishes, for example, the instrument basis from
            %   the curve basis), e.g. the basis for all instruments would
            %   be specified by the parameter 'InstrumentBasis'.
            %
            %   Further note that simple interest can be specified for an
            %   instrument by specifying the period as 0.
            %
            %   Finally, if instrument basis and instrument period are
            %   not specified, the following default values are used:
            %
            %   Basis: 0 (act/act), Period: 2
            
            % Check first to see if the Spline Toolbox is licensed
            if ~license('test','spline_toolbox')
                error('finfixed:IRFunctionCurve:missingSplineToolbox',...
                    ['You must have the Spline Toolbox to call the ' ...
                    'fitSmoothingSpline method'])
            end
            
            if ~strcmpi(Type,{'forward'})
                error('finfixed:IRDataCurve:invalidType',...
                    'FITSMOOTHINGSPLINE requires a forward curve')
            end
            
            % Parse inputs
            p = inputParser;
            
            p.addRequired('type',@ischar);
            p.addRequired('settle');
            p.addRequired('instruments',@isnumeric);
            p.addRequired('lambdafun',@(x) isa(x,'function_handle'));
            
            p.addParamValue('compounding',2);
            p.addParamValue('basis',0);
            p.addParamValue('knots',[],@isnumeric);
            
            % No error checks here as INSTARGBOND will be used
            p.addParamValue('instrumentperiod',2);
            p.addParamValue('instrumentcouponrate',[]);
            p.addParamValue('instrumentbasis',0);
            p.addParamValue('instrumentendmonthrule',1);
            p.addParamValue('instrumentissuedate', []);
            p.addParamValue('instrumentfirstcoupondate', []);
            p.addParamValue('instrumentlastcoupondate', []);
            p.addParamValue('instrumentstartdate', []);
            p.addParamValue('instrumentface',100);
            
            try
                p.parse(Type, CurveSettle,Instruments, lambdafun,varargin{:});
            catch ME
                newME = MException('finfixed:IRFunctionCurve:optionalInputError',...
                    'Error in input arguments');
                newME = addCause(newME,ME);
                throw(newME)
            end
            
            % Parse the inputs
            Settle = Instruments(:,1);
            Maturity = Instruments(:,2);
            DirtyPrice = Instruments(:,3);
            CouponRate = Instruments(:,4);
            
            Compounding = p.Results.compounding;
            CurveBasis = p.Results.basis;
            
            Period = p.Results.instrumentperiod;
            Basis = p.Results.instrumentbasis;
            EndMonthRule = p.Results.instrumentendmonthrule;
            IssueDate = p.Results.instrumentissuedate;
            FirstCouponDate = p.Results.instrumentfirstcoupondate;
            LastCouponDate = p.Results.instrumentlastcoupondate;
            StartDate = p.Results.instrumentstartdate;
            Face = p.Results.instrumentface;
            knots = p.Results.knots;
            
            % Confirm that the instrument settle is equal to the curve
            % settle
            Settle = unique(Settle);
            
            try
                Settle = datenum(Settle);
            catch E
                error('finfixed:IRFunctionCurve:invalidInstrumentSettle',...
                    'Instrument settle must be a Date')
            end
            
            if length(Settle) > 1 || Settle ~= CurveSettle
                error('finfixed:IRFunctionCurve:invalidSettle',...
                    ['Settle must be identical for all instruments and ' ...
                    'for the interest rate curve'])
            end
            
            % Construct an object with the inputs
            obj = IRFunctionCurve(Type,CurveSettle,[],...
                'Compounding',Compounding,'Basis',CurveBasis);
            
            % Because we are indexing in -- we need to scalar expand all
            % inputs
            [CouponRate, Settle, Maturity, Period, Basis, EndMonthRule, IssueDate, ...
                FirstCouponDate, LastCouponDate, StartDate, Face] = ...
                instargbond(CouponRate, Settle, Maturity, Period,...
                Basis, EndMonthRule, IssueDate, FirstCouponDate, LastCouponDate,...
                StartDate, Face);
            
            Duration = bnddurp(DirtyPrice,CouponRate, Settle, Maturity,...
                Period, Basis, EndMonthRule, IssueDate, ...
                FirstCouponDate, LastCouponDate, StartDate, Face);
            
            ytm = yearfrac(obj.Settle,Maturity);
            
            k = 4; % spline order
            
            if isempty(knots)
                knotLocations = [0 ytm'];
                knots = augknt(knotLocations,k);
            end
            
            % Decompose bonds into cash flows
            [CFlowAmounts, CFlowDates, TFactors] = cfamounts(CouponRate, Settle, Maturity);
            [CFBondDate, AllDates] = cfport(CFlowAmounts,CFlowDates,TFactors);
            
            % Find the time to maturity for each of the payment dates
            tau = yearfrac(Settle(1),AllDates);
            
            % Integrate the basis functions in the spline once -- this is used to
            % calculate the partial derivative of the price with respect to Beta
            basisspl = spmak(knots,eye(length(knots)-k));
            phi = fnval(fnint(basisspl),tau);
            
            iterSize = .1;
            tau2 = min(knots):iterSize:max(knots);
            colmat = spcol(knots,k,brk2knt(tau2,3));
            lambdaH = iterSize*bsxfun(@times,lambdafun(tau2(:)),colmat(3:3:end,:))'*colmat(3:3:end,:);
            
            function [f,g] = costfun(x)
                
                bspl = spmak(knots,x');
                DF = exp(-fnval(fnder(bspl,-1),tau));
                Pi = CFBondDate*DF;
                PenaltyTerm = x'*lambdaH*x;
                PriceTerm = sum(((DirtyPrice - Pi)./Duration).^2);
                f = PriceTerm + PenaltyTerm;
                
                dPidB = -CFBondDate*bsxfun(@times,DF,phi');
                
                g = 2*(((Pi-DirtyPrice)./Duration.^2)'*dPidB)' + (lambdaH + lambdaH')*x;
            end
            
            options = optimset('fminunc');
            options = optimset(options,'display','off','GradObj','on',...
                'DerivativeCheck','off');
            
            Beta0 = repmat(.05,length(knots) - k,1);
            
            [Beta,fval,exitflag] = fminunc(@(x) costfun(x),Beta0,options);
            
            if (exitflag == 0)
                warning('finfixed:IRFunctionCurve:SplineLimitExceeded',...
                    'Function evaluation or iteration limit exceeded');
            elseif (exitflag < 0)
                error('finfixed:IRFunctionCurve:SplineNoSolution',...
                    'Error in optimization, check knot specification')
            end
            
            fSpline = spmak(knots,Beta');
            
            obj.FunctionHandle = @(t) fnval(fSpline,t);
            
        end
    end
    
end

function outRate = locConvert(inRate,inComp,inBasis,outComp,outBasis,...
    StartDates,EndDates) %#ok

% Simple interest is signified with a 0 -- replace with a 1
inComp(inComp == 0) = 1;
if outComp == inComp
    outRate = inRate;
elseif outComp == -1
    outRate = log(1 + inRate/inComp)*inComp;
elseif inComp == -1
    outRate = outComp.*((exp(inRate).^(1/outComp)) - 1);
else
    outRate = ((1 + inRate/inComp).^(inComp/outComp) - 1).^outComp;
end
end

function [OutComp,OutBasis] = locParseOptional(varargin)

p = inputParser;

p.addParamValue('compounding',[],@(x) ismember(x,[-1 1 2 3 4 6 12]));
p.addParamValue('basis',[],@(x) ismember(x,0:12));

try
    p.parse(varargin{:});
catch ME
    newME = MException('finfixed:IRDataCurve:optionalInputError',...
        'Error in optional parameter value inputs');
    newME = addCause(newME,ME);
    throw(newME)
end

OutComp = p.Results.compounding;
OutBasis = p.Results.basis;

end