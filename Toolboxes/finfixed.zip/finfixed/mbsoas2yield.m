function [myield, beyield] = mbsoas2yield(ZeroCurve, OAS, Settle,  ...
      Maturity, IssueDate, GrossRate,varargin)
%MBSOAS2YIELD Price of mortgage pool from OAS and a spot curve.
%   Yield of mortgage pool given OAS, a spot curve, and prepayment vector.
%
%   [myield, beyield] = mbsoas2yield(ZeroCurve, OAS, Settle, Maturity, ...
%      IssueDate, GrossRate)
%   [myield, beyield] = mbsoas2yield(ZeroCurve, OAS, Settle, Maturity, ...
%      IssueDate, GrossRate, CouponRate)
%   [myield, beyield] = mbsoas2yield(ZeroCurve, OAS, Settle, Maturity, ...
%      IssueDate, GrossRate, CouponRate, Delay)
%   [myield, beyield] = mbsoas2yield(ZeroCurve, OAS, Settle, Maturity, ...
%      IssueDate, GrossRate, CouponRate, Delay, Interpolation)
%   [myield, beyield] = mbsoas2yield(ZeroCurve, OAS, Settle, Maturity, ...
%      IssueDate, GrossRate, CouponRate, Delay, Interpolation, ...
%      PrepaySpeed)
%   [myield, beyield] = mbsoas2yield(ZeroCurve, OAS, Settle, Maturity, ...
%      IssueDate, GrossRate, CouponRate, Delay, Interpolation, [], ...
%      PrepayMatrix)
%
% Optional Inputs:  CouponRate, Delay, Interpolation, PrepayMatrix,
%                   PrepaySpeed
%
% Inputs:
%        ZeroCurve - Three-column matrix, the first is serial date,
%                     the second contains Spot Rates with maturities
%                     corresponding to the dates in the first column,
%                     in decimal (e.g. 0.075), and the third column is
%                     the Compounding of the rates given in the first
%                     column.
%                     Allowable compounding are -1, 1,2,3,4,6,and 12.
%
%                     Example: [datenum('1-Jan-2003')  0.0154  12;
%                               datenum('1-Jan-2004')  0.0250  12;
%                               ......
%                               datenum('1-Jan-2020')  0.0675   2];
%
%               OAS - NMBSx1 vector of OAS in basis points.
%
%            Settle - NMBSx1 vector of settlement date.
%
%          Maturity - NMBSx1 vector of maturity date.
%
%         IssueDate - NMBSx1 vector of issue date.
%
%         GrossRate - NMBSx1 vector of gross coupon rate,
%                     in decimal.
%
% Optional Inputs:
%        CouponRate - NMBSx1 vector of Net Coupon Rate,
%                     in decimal.
%                     Default is equal to GrossRate.
%
%             Delay - NMBSx1 vector of delay in days.
%                     Default is zero.
%
%     Interpolation - Scalar value
%                     Interpolation method, to compute for the
%                     corresponding spot rates for the bond's cash flow.
%                     Default is (1), linear. 
%                     Available methods are (0) nearest, (1) linear, and
%                     (2) cubic spline.
%
%       PrepaySpeed - NMBSx1 vector of speed relative to
%                     PSA standard. PSA standard is 100.
%                     Default is 0 (zero) prepayment speed.
%
%      PrepayMatrix - Customized prepayment vector. A matrix of size
%                     [max(TermRemaining) x NMBS]. Missing values are
%                     padded with NaNs.  Each column corresponds to each
%                     MBS, and each row corresponds to each month after
%                     settlement.
%
% Output:
%            myield - Mortgage yield of passthrough in decimal.
%
%           beyield - Bond equivalent yield of passthrough in decimal.
%
%  Example:
%    This examples calculates the yield of 30-year fixed-rate mortgage pool
%    with about a 28-year WAM remaining given the PSA prepayment speeds of
%    0, 50, and 100: 
%
%  Create Bonds matrix
%     Bonds = [datenum('11/21/2002')   0       100  0  2  1;
%              datenum('02/20/2003')   0       100  0  2  1;
%              datenum('07/31/2004')   0.03    100  2  3  1;
%              datenum('08/15/2007')  0.035    100  2  3  1;
%              datenum('08/15/2012')  0.04875  100  2  3  1;
%              datenum('02/15/2031')  0.05375  100  2  3  1];
%
%  Settle Date:
%     Settle  = datenum('20-Aug-2002');
% 
%  Clean prices for the bonds:
%     Prices =  [ 98.97467;
%                 98.58044;
%                100.10534;
%                 98.18054;
%                101.38136;
%                 99.25411];
%  
%  SpotCompounding for the bonds:
%     SpotCompounding = 2*ones(size(Prices));
%
%  Call ZBTPRICE
%     [ZeroRatesP, CurveDatesP] = zbtprice(Bonds, Prices, Settle)
%     ZeroCurve = [CurveDatesP, ZeroRatesP, SpotCompounding];
%
%  Assign the parameters
%     OAS = [26.0502; 28.6348; 31.2222];
%     Maturity  = datenum('02-Jan-2030');
%     IssueDate = datenum('02-Jan-2000');
%     GrossRate = 0.08125;
%     CouponRate = 0.075;
%     Delay = 14;
%     Interpolation = 1;
%     PrepaySpeed = [0; 50; 100];
%
%    [myield beyield] = mbsoas2yield(ZeroCurve, OAS, Settle, ...
%        Maturity, IssueDate, GrossRate, CouponRate, Delay, ...
%        Interpolation, PrepaySpeed) 
%
%    myield =
%        0.0802
%        0.0814
%        0.0828
%    beyield =
%        0.0815
%        0.0828
%        0.0842
%
%  See also MBSOAS2PRICE, MBSPRICE2OAS, MBSYIELD2OAS

%   Copyright 2003-2004 The MathWorks, Inc.
%   $Revision: 1.8.6.5 $  $Date: 2005/06/17 20:25:19 $

if nargin <6
    error('finfixed:mbsoas2yield:invalidInputs',...
        sprintf(['Need at least ZeroMatrix, ZVOAS, ',...
        'Settle, Maturity, IssueDate, and GrossRate.']));
else
    CurveDates = ZeroCurve(:,1);    
    
    % Make sure align these arrays into Column
    CurveDates = CurveDates(:);
    Settle    = datenum(Settle);

    if any(Settle ~= Settle(1))
        error('finfixed:mbsoas2yield:invalidSettle',...
            sprintf(['Please make sure that all Settle date are the ',...
            'same, or simply input a scalar Settle date.']));
    end

    Maturity  = datenum(Maturity);
    IssueDate = datenum(IssueDate);
end

if nargin <7 || isempty(varargin{1})
    CouponRate = GrossRate;
else
    CouponRate = varargin{1}(:);
end

if nargin <8 || isempty(varargin{2})
    Delay = 0;
else
    Delay = varargin{2}(:);
end

if ~(nargin <9 || isempty(varargin{3}))
    Interpolation = varargin{3}(:);
    if any(Interpolation ~=Interpolation(1))
        error('finfixed:mbsoas2yield:invalidInterpolation',...
            sprintf(['Please make sure that all Interpolation is of ',...
            'ONE type, or simply input a scalar value for Interpolation.']));
    end
end

if nargin < 10 || isempty(varargin{4})
    Speed = 0;
else
    Speed = varargin{4};
end

if nargin == 11;
    isCustomized = true;
else
    isCustomized = false;
end

if isCustomized
    if ~isempty(varargin{4})
        error('finfixed:mbsoas2yield:invalidPrePaySpeed',...
            sprintf(['Cannot use benchmark when supplying customized ',...
            'prepayment CPR.\nPut empty matrices ([]) for 10th ',...
            'input arguments.']));
    end

    % check that prepayment is supplied and not empty.
    if isempty(varargin{5})
        error('finfixed:mbsoas2yield:invalidPrePayMatrix',...
            sprintf(['Please supply a prepayment (SMM) matrix when',...
            'you do not use benchmarked prepayment.']));
    end

    [Settle, Maturity, IssueDate, GrossRate, ...
        CouponRate, Delay] = ...
        finargsz(1, Settle(:), Maturity(:), IssueDate(:), ...
        GrossRate(:), CouponRate(:), Delay(:));

else
    [Settle, Maturity, IssueDate, GrossRate, ...
        CouponRate, Delay, Speed] = ...
        finargsz(1, Settle(:), Maturity(:), IssueDate(:), ...
        GrossRate(:), CouponRate(:), Delay(:), Speed(:));
end

% Check Settle-Maturity vs Spot Dates consistency
% The case with "outdated" Spot Curve
if any(Settle > min(CurveDates))
    error('finfixed:mbsoas2yield:invalidSpotCurve',...
        sprintf(['Settle is less than the earliest point in the ',...
        'Spot curve.  The Spot Curve is outdated.']));
end

Price = mbsoas2price(ZeroCurve, OAS, Settle,  ...
      Maturity, IssueDate, GrossRate, varargin{1:end});

if isCustomized
    [myield, beyield] = mbsyield(Price, Settle, Maturity, ...
        IssueDate, GrossRate, CouponRate, Delay, [], PrepayMatrix);
else
    [myield, beyield] = mbsyield(Price, Settle, Maturity, ...
        IssueDate, GrossRate, CouponRate, Delay, Speed);
end

% [EOF]
