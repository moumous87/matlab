function Price = zeroprice(Yield, Settle, Maturity, Period, Basis, ...
    EndMonthRule)
%ZEROPRICE Price of zero-coupon given reference bond yield.
%    The function computes prices of NZERO number of zero-coupon given
%    yields of reference bonds. In other words, if the zero-coupon computed
%    with this yield is used to discount the reference bond, the value of
%    that reference bond will be equal its price.
%
%    Price = zeroprice(Yield, Settle, Maturity)
%    Price = zeroprice(Yield, Settle, Maturity, Period)
%    Price = zeroprice(Yield, Settle, Maturity, Period, Basis)
%    Price = zeroprice(Yield, Settle, Maturity, Period, Basis,EndMonthRule)
%
%    Optional Inputs:  Period, Basis, EndMonthRule
%
%    Inputs:
%         Yield - NZEROx1 vector of reference bond
%                 yield, in decimal.
%
%        Settle - NZEROx1 vector of settlement date.
%
%      Maturity - NZEROx1 vector of maturity date.
%
%    Optional Inputs:
% 
%        Period - NZEROx1 vector of number of coupons
%                 in a year.
%                 1 - one coupon per year
%                 2 - semiannual     (default)
%                 3 - three times a year
%                 4 - quarterly
%                 6 - bi-monthly compounding
%                12 - monthly
%
%         Basis - NZEROx1 vector of day-count method,
%                 available values are:
%                 0 - actual/actual(default)
%                 1 - 30/360 SIA 
%                 2 - actual/360
%                 3 - actual/365
%                 4 - 30/360 PSA
%                 5 - 30/360 ISDA
%                 6 - 30/360 European
%                 7 - actual/365 Japanese
%                 8 - actual/actual ISMA
%                 9 - actual/360 ISMA
%                10 - actual/365 ISMA
%                11 - 30/360 ISMA
%                12 - act/365 (ISDA)
%
%  EndMonthRule - NZEROx1 vector of end-of-month rule.
%                 0 - off
%                 1 - on  (default)
%
%  Outputs:
%         Price - Price of the zero-coupon security
%                 per $100 notional.
%
%  Example:
%     Settle = datenum('02-03-2003');
%     Maturity = datenum('08-15-2009');
%     Period = 2;
%     Basis = 0;
%     Yield = 0.03496;
%
%     Price = zeroprice(Yield, Settle, Maturity, Period, Basis)
%
%     Price =
%       79.739356137
%
%   Reference: Standard Securities Calculation Methods: Fixed Income
%              Securities Formulas for Price, Yield, and Accrued Interest,
%              Jan Mayle, Vol 1, 3rd Edition. (c) 1993
%
%  See also ZEROYIELD

%  Copyright 2002-2004 The MathWorks, Inc.
%  $Revision: 1.7.6.9 $   $Date: 2007/11/07 18:33:04 $

if nargin<3
    error('finfixed:zeroprice:invalidInputs',...
        'Not enough input. Need at least Settle, Maturity, and Yield.');
end

if nargin<4 || isempty(Period)
    Period = 2;
else
    if any(Period ~= 1 & Period ~=2 & Period ~= 3 & Period ~=4 ...
            & Period ~= 6 & Period ~= 12)
        error('finfixed:zeroprice:invalidPeriod',...
            'Invalid number of coupon payment.');
    end
end

if nargin<5 || isempty(Basis)
    Basis  = 0;
else
     if any(~isvalidbasis(Basis))
        error('finfixed:zeroprice:invalidBasis',...
            'Invalid day count basis.');
    end
end

if nargin<6 || isempty(EndMonthRule)
    EndMonthRule = 1;
else
    if any(EndMonthRule ~=0 & EndMonthRule ~=1)
        error('finfixed:zeroprice:invalidEOM',...
            'Invalid End of Month Rule value; must be 0 or 1.');
    end
end

Settle = datenum(Settle);
Maturity = datenum(Maturity);

[Yield, Settle, Maturity, Period, Basis, EndMonthRule] = ...
    finargsz(1, Yield(:), Settle(:), Maturity(:), Period(:),...
    Basis(:), EndMonthRule(:));

Face = repmat(100,length(Yield),1);

% Find out how many quasi coupon left and choose algorithm based on that
numqcpn = cpncount(Settle, Maturity, Period, Basis, EndMonthRule);

% determine if one of less coupons for algorithm 
swt = (round(numqcpn) <= 1);

% determine which algorithm should be used with each
idx1 = (swt==1);

% initialize DSR and DSC
% DSR = # days from settle to redemption date
DSR = zeros(length(Yield),1);

% DSC = # days from settle to next quasi-coupon date
DSC = DSR;

% use price Formula 21 pg. 110
if any(idx1)
    % idx1 denotes less than one quasi coupon to maturity
    DSR(idx1) = daysdif(Settle(idx1), Maturity(idx1), Basis(idx1));

    Price(idx1) = prdisc_simple(Settle(idx1), Maturity(idx1), ...
        Face(idx1), Yield(idx1), Period(idx1), Basis(idx1), DSR(idx1), ...
        EndMonthRule(idx1));
end

% use price Formula 23 pg. 114
if any(~idx1)
    DSC(~idx1) = cpndaten(Settle(~idx1), Maturity(~idx1), Period(~idx1),...
        Basis(~idx1), EndMonthRule(~idx1));

    % idx0 denotes more than one quasi coupon to maturity
    DSC(~idx1) = daysdif(Settle(~idx1), DSC(~idx1), Basis(~idx1));
    
    Price(~idx1) = prdisc_pv(Settle(~idx1), Maturity(~idx1), Face(~idx1), ...
        Yield(~idx1), Period(~idx1), Basis(~idx1), numqcpn(~idx1), ...
        DSC(~idx1), EndMonthRule(~idx1));
end

Price = Price(:);

%=============================================================================

function p = prdisc_simple(sd,md,rv,yield,period,basis,DSR,EOM)

% prdisc_simple computes zero factor based on yields
E = cpnpersz(sd,md,period,basis,EOM);
p = rv ./ (1 + DSR.*yield./E./period);

%=============================================================================

function p = prdisc_pv(sd,md,rv,yield,period,basis,Nq,DSC,EOM)

% prdisc_PV computes zero factor based on yields
E = cpnpersz(sd,md,period,basis,EOM);
p = rv ./ (1 + yield./period).^(Nq-1+DSC./E);

%=============================================================================


% %% SIA Test Suite for ZEROPRICE
% function testzeroprice
% 
% clear; clc;
% 
% %SHORT TERM ZEROS:
% %==============
% % Benchmark 30A
% 
% Settle = '24-Jun-1993';
% Maturity = '1-Nov-1993';
% Period = 2;
% Basis = 0;
% Yield = 0.04;
% 
% Price30A = zeroprice(Yield, Settle, Maturity, Period, Basis)  %SIA = 98.606645
% 
% % Benchmark 30B
% 
% Settle = '24-Jun-1993';
% Maturity = '1-Nov-1993';
% Period = 2;
% Basis = 1;
% Yield = 0.04;
% 
% Price30B = zeroprice(Yield, Settle, Maturity, Period, Basis) %SIA = 98.608524
% 
% 
% %LONG TERM ZEROS:
% %============
% %Benchmark 32A
% 
% Settle = '24-Jun-1993';
% Maturity = '15-Jan-2024';
% Period = 2;
% Basis = 0;
% Yield = 0.1;
% 
% Price32A = zeroprice(Yield, Settle, Maturity, Period, Basis) %SIA = 5.069841
% 
% % Benchmark 32B
% 
% Settle = '24-Jun-1993';
% Maturity = '15-Jan-2024';
% Basis = 1;
% Yield = 0.1;
% Period = 2;
% Price32B = zeroprice(Yield, Settle, Maturity, Period, Basis) % SIA = 5.0696814
% 
% %Vector Input Test:
% %===============
% % Regular
% Pricevec = zeroprice(Yield, Settle, Maturity, [2,2], [0 1]) %SIA = [5.069841; 5.0696814]
% Pricevec2 = zeroprice(Yield, Settle, Maturity, [2,2], [0,1], [0 1]) %SIA = [5.069841; 5.0696814] - EOM has NO effect
% 
% % Test where one "short" the other "long" in vector form
% Settle = '24-Jun-1993';
% Maturity = ['01-Nov-1993'; '15-Jan-2024'];
% Basis = [0; 1];
% Period = [2;2];
% Yield = [0.04; 0.1];
% 
% Pricevec3 = zeroprice(Yield, Settle, Maturity, Period, Basis) %SIA = [98.606645   5.0696814]
% 
% 
% %Three Input arguments:
% %===============
% Price3inp = zeroprice(Yield, Settle, Maturity) %SIA = 5.069681


% [EOF]
