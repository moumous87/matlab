classdef IRDataCurve < IRCurve
    %IRDATACURVE Interest rate curve represented with data
    %   An IRDATACURVE is a representation of an interest
    %   rate curve with dates and data.  This can be constructed
    %   directly by specifying dates and corresponding interest rates
    %   or it can be bootstrapped from market data.  Once a curve has been
    %   constructed, forward and zero rates and discount factors can be
    %   extracted and it can be converted to a RateSpec structure -- and
    %   used with functions in the Financial Derivatives Toolbox.
    %
    %   An interest rate data curve has the following properties:
    %
    %   Type: Type of Curve, either Forward, Zero, or Discount
    %   Settle: Settle date
    %   Compounding: Compounding for curve, acceptable values are
    %   -1,1,2 (default) ,3,4,6,12
    %   Basis: Day-count basis.
    %       Possible values include:
    %           0 - actual/actual (default)
    %           1 - 30/360 SIA
    %           2 - actual/360
    %           3 - actual/365
    %           4 - 30/360 PSA
    %           5 - 30/360 ISDA
    %           6 - 30/360 European
    %           7 - actual/365 Japanese
    %           8 - actual/actual ISMA
    %           9 - actual/360 ISMA
    %           10 - actual/365 ISMA
    %           11 - 30/360 ISMA
    %           12 - actual/365 ISDA
    %   Dates: Dates corresponding to rate data below
    %   Data: Interest rate data for the curve
    %   InterpMethod = 'linear' (default), 'constant', 'pchip', 'spline'
    %
    %   An interest rate data curve has the following methods:
    %
    %   GETFORWARDRATES: Returns forward rates for input dates
    %   GETZERORATES: Returns zero rates for input dates
    %   GETDISCOUNTFACTORS: Returns discount factors for input dates
    %
    %   Optional inputs to the above methods are basis and compounding
    %
    %   TORATESPEC: Converts to be a RateSpec object, like the ones produced by
    %   INTSENVSET, for input dates
    %   BOOTSTRAP: Bootstraps an interest rate curve from market data.
    %
    % See also IRCURVE, IRBOOTSTRAPOPTIONS
    
    % References:
    % [1] Hagan, P., West, G. (2006), "Interpolation Methods for Curve
    %     Construction", Applied Mathematical Finance, Vol 13, No. 2
    %
    % [2] Ron, Uri(2000), "A Practical Guide to Swap Curve Construction",
    %     Working Papers 00-17, Bank of Canada.
    
    %   Copyright 2008 The MathWorks, Inc.
    %   $Revision: 1.1.6.2.2.1 $  $Date: 2008/08/01 15:31:49 $
    
    properties (SetAccess = protected, GetAccess = public)
        Dates
        Data
        InterpMethod = 'linear';
    end
    
    methods
        function obj = IRDataCurve(Type,Settle,Dates,Data,varargin)
            %IRDATACURVE Create an interest rate data curve.
            %   IRDC = IRDATACURVE(TYPE,SETTLE) creates a curve with specified
            %   Type and Settle date
            %
            %   IRDC = IRDATACURVE(TYPE, SETTLE, DATES, DATA) creates a curve
            %   with dates and data specified
            %
            %   Optional inputs, specified in parameter value pairs, are
            %   COMPOUNDING, BASIS, and INTERPMETHOD
            %
            %   Example:  Create a curve
            %
            %           c = IRDataCurve('Forward',today);
            %
            %   Example: Create a curve with dates and data
            %
            %           Dates = today:30:today+300;
            %           Data = rand(size(Dates));
            %           c = IRDataCurve('Forward',today,Dates,Data);
            %
            if nargin < 2
                error('finfixed:IRDataCurve:notEnoughInputs',...
                    'Must specify at least Type and Settle')
            end
            
            if nargin > 2
                if nargin == 3
                    error('finfixed:IRDataCurve:invalidInputs',...
                        'Must specify Dates and Rates')
                else
                    obj.Dates = datenum(Dates(:));
                    obj.Data = Data(:);
                end
            end
            
            % Parse curve type
            if all(~strcmpi(Type,{'forward','zero','discount'}))
                error('finfixed:IRDataCurve:invalidType',...
                    'Type must be forward, zero, or discount')
            end
            
            obj.Type = Type;
            try
                obj.Settle = datenum(Settle);
            catch E
                error('finfixed:IRDataCurve:invalidSettle',...
                    'Settle must be a Date')
            end
            
            % Parse inputs
            p = inputParser;
            
            p.addParamValue('compounding',2,@(x) ismember(x,[-1 1 2 3 4 6 12]));
            p.addParamValue('basis',0,@(x) ismember(x,0:12));
            p.addParamValue('interpmethod','linear',@ischar);
            
            try
                p.parse(varargin{:});
            catch ME
                newME = MException('finfixed:IRDataCurve:optionalInputError',...
                    'Error in optional parameter value inputs');
                newME = addCause(newME,ME);
                throw(newME)
            end
            
            obj.Compounding = p.Results.compounding;
            obj.Basis = p.Results.basis;
            obj.Type = Type;
            obj.Settle = datenum(Settle);
            
            tempInterpMethod = p.Results.interpmethod;
            if all(~strcmpi(tempInterpMethod,{'constant',...
                    'linear','spline','pchip'}))
                error('finfixed:IRDataCurve:invalidInterpMethod',...
                    'Interpolation method must be constant, linear, spline or pchip')
            else
                obj.InterpMethod = tempInterpMethod;
            end
            
        end
        function outForwardRates = getForwardRates(obj,inpDates,varargin)
            %IRDATACURVE/GETFORWARDRATES Get Forward Rates for input dates
            %   RATES = GETFORWARDRATES(IRDC,INPDATES) returns forward
            %   rates for the input dates -- where INPDATES is an N X 1
            %   vector of MATLAB date numbers after the Curve Settle.
            %
            %   Optional inputs include output BASIS and COMPOUNDING,
            %   specified in parameter value pairs
            %
            %   Example:  Get rates
            %
            %   ForwardRates = getForwardRates(IRDC,[today:30:today+365])
            %
            inpDates = inpDates(:);
            [OutComp,OutBasis] = locParseOptional(varargin{:});
            if isempty(OutComp),OutComp = obj.Compounding;end
            if isempty(OutBasis),OutBasis = obj.Basis;end
            switch lower(obj.Type)
                case 'forward'
                    outForwardRates = locInterp(obj.Dates,obj.Data,...
                        inpDates,obj.InterpMethod);
                    outForwardRates = locConvert(outForwardRates,obj.Compounding,...
                        obj.Basis,OutComp,OutBasis);
                case 'zero'
                    ZeroRates = locInterp(obj.Dates,obj.Data,...
                        inpDates,obj.InterpMethod);
                    outForwardRates = loczero2fwd(ZeroRates,inpDates, ...
                        obj.Settle, obj.Compounding, obj.Basis,OutComp,OutBasis);
                case 'discount'
                    DF = locInterp(obj.Dates,obj.Data,...
                        inpDates,obj.InterpMethod);
                    ZeroRates = disc2zero(DF,inpDates, ...
                        obj.Settle, obj.Compounding, obj.Basis);
                    outForwardRates = loczero2fwd(ZeroRates,inpDates, ...
                        obj.Settle, obj.Compounding, obj.Basis,OutComp,OutBasis);
            end
        end
        function outZeroRates = getZeroRates(obj,inpDates,varargin)
            %IRDATACURVE/GETZERORATES Get Zero Rates for input dates
            %   RATES = GETZERORATES(IRDC,INPDATES) returns zero
            %   rates for the input dates -- where INPDATES is an N X 1
            %   vector of MATLAB date numbers after the Curve Settle.
            %
            %   Optional inputs include output BASIS and COMPOUNDING,
            %   specified in parameter value pairs
            %
            %   Example:  Get rates
            %
            %   ZeroRates = getZeroRates(IRDC,[today:30:today+365])
            %
            inpDates = inpDates(:);
            [OutComp,OutBasis] = locParseOptional(varargin{:});
            if isempty(OutComp),OutComp = obj.Compounding;end
            if isempty(OutBasis),OutBasis = obj.Basis;end
            switch lower(obj.Type)
                case 'forward'
                    tmpDates = unique([obj.Dates;inpDates]);
                    tmpForwardRates = locInterp(obj.Dates,obj.Data,...
                        tmpDates,obj.InterpMethod);
                    tmpZeroRates = fwd2zero(tmpForwardRates,tmpDates, ...
                        obj.Settle, obj.Compounding, obj.Basis,OutComp,OutBasis);
                    outZeroRates = tmpZeroRates(ismember(tmpDates,inpDates));
                case 'zero'
                    outZeroRates = locInterp(obj.Dates,obj.Data,...
                        inpDates,obj.InterpMethod);
                    outZeroRates = locConvert(outZeroRates,obj.Compounding,...
                        obj.Basis,OutComp,OutBasis);
                case 'discount'
                    DF = locInterp(obj.Dates,obj.Data,...
                        inpDates,obj.InterpMethod);
                    outZeroRates = disc2zero(DF,inpDates, ...
                        obj.Settle, obj.Compounding, obj.Basis);
            end
        end
        function outDF = getDiscountFactors(obj,inpDates)
            %IRDATACURVE/GETDISCOUNTFACTORS Get Discount Factors for input dates
            %   RATES = GETDISCOUNTFACTORS(IRDC,INPDATES) returns discount
            %   factors for the input dates -- where INPDATES is an N X 1 
            %   vector of MATLAB date numbers after the Curve Settle.
            %
            %   Example:  Get discount factors
            %
            %   ZeroRates = getDiscountFactors(IRDC,[today:30:today+365])
            %
            inpDates = inpDates(:);
            switch lower(obj.Type)
                case 'zero'
                    ZeroRates = locInterp(obj.Dates,obj.Data,...
                        inpDates,obj.InterpMethod);
                    outDF = zero2disc(ZeroRates,inpDates, ...
                        obj.Settle, obj.Compounding, obj.Basis);
                case 'forward'
                    tmpDates = sort([obj.Dates;inpDates]);
                    tmpForwardRates = locInterp(obj.Dates,obj.Data,...
                        tmpDates,obj.InterpMethod);
                    tmpZeroRates = fwd2zero(tmpForwardRates,tmpDates, ...
                        obj.Settle, obj.Compounding, obj.Basis);
                    outZeroRates = tmpZeroRates(ismember(tmpDates,inpDates));
                    
                    outDF = zero2disc(outZeroRates,inpDates, ...
                        obj.Settle, obj.Compounding, obj.Basis);
                case 'discount'
                    outDF = locInterp(obj.Dates,obj.Data,...
                        inpDates,obj.InterpMethod);
            end
        end
        function outParYields = getParYields(obj,inpDates,varargin)
            %IRDATACURVE/GETPARYIELDS Get Par Yields for input dates
            %   PARYIELDS = GETPARYIELDS(IRDC,INPDATES) returns par
            %   yields for the input dates -- where INPDATES is an N X 1 
            %   vector of MATLAB date numbers after the Curve Settle.
            %
            %   Optional inputs include output BASIS and COMPOUNDING,
            %   specified in parameter value pairs
            %
            %   Example:  Get par yields
            %
            %   ParYields = getParYields(IRDC,[today:30:today+365])
            %
            inpDates = inpDates(:);
            [OutComp,OutBasis] = locParseOptional(varargin{:});
            if isempty(OutComp),OutComp = 2;end % Default for bonds
            if isempty(OutBasis),OutBasis = 0;end % Default for bonds
            switch lower(obj.Type)
                case 'forward'
                    tmpDates = sort([obj.Dates;inpDates]);
                    tmpForwardRates = locInterp(obj.Dates,obj.Data,...
                        tmpDates,obj.InterpMethod);
                    tmpZeroRates = fwd2zero(tmpForwardRates,tmpDates, ...
                        obj.Settle, obj.Compounding, obj.Basis,OutComp,OutBasis);
                    ZeroRates = tmpZeroRates(ismember(tmpDates,inpDates));
                    
                    outParYields = zero2pyld(ZeroRates, inpDates, obj.Settle,...
                        OutComp,OutBasis, obj.Compounding,obj.Basis);
                case 'zero'
                    ZeroRates = locInterp(obj.Dates,obj.Data,...
                        inpDates,obj.InterpMethod);
                    outParYields = zero2pyld(ZeroRates, inpDates, obj.Settle,...
                        OutComp,OutBasis, obj.Compounding,obj.Basis);
                case 'discount'
                    DF = locInterp(obj.Dates,obj.Data,...
                        inpDates,obj.InterpMethod);
                    ZeroRates = disc2zero(DF,inpDates, ...
                        obj.Settle, obj.Compounding, obj.Basis);
                    outParYields = zero2pyld(ZeroRates, inpDates, obj.Settle,...
                        OutComp,OutBasis, obj.Compounding,obj.Basis);
            end
        end
        function RateSpec = toRateSpec(obj,inpDates)
            %IRDATACURVE/TORATESPEC Converts to RateSpec
            %   RATESPEC = TORATESPEC(IRDC,INPDATES) returns a RateSpec
            %   object, like the one created by INTENVSET -- where INPDATES
            %   is an N X 1 vector of MATLAB date numbers after the Curve Settle.
            %
            %   Example:  Get a rate spec
            %
            %   RateSpec = toRateSpec(IRDC,[today:30:today+365])
            %
            inpDates = inpDates(:);
            ZeroRates = getZeroRates(obj,inpDates);
            RateSpec = intenvset('Rates', ZeroRates(:), 'EndDates',...
                inpDates(:),'StartDates',obj.Settle,...
                'Basis',obj.Basis,'Compounding',obj.Compounding);
        end
    end
    methods(Static = true)
        function obj = bootstrap(Type, Settle, InstrumentTypes, Instruments, ...
                varargin)
            %IRDATACURVE/BOOTSTRAP Bootstraps an interest rate curve
            %   MYCURVE = IRDATACURVE.BOOTSTRAP(TYPE, SETTLE,
            %              INSTRUMENTTYPES, INSTRUMENTS)
            %   bootstraps an interest rate curve from market data.  The
            %   dates of the bootstrapped curve correspond to the maturity
            %   dates of the input instruments.
            %
            %   TYPE: Forward, Zero
            %   SETTLE: Settle date
            %   INSTRUMENTTYPES: N X 1  cell array (N is number of instruments)
            %   indicating what kind of instrument is in the INSTRUMENTS
            %   matrix -- acceptable values are Deposit, Futures, Swap, Bond
            %
            %   INSTRUMENTS: N X 3 data matrix for Instruments where the
            %   first column is Settle date, the second column is Maturity,
            %   and the third column is market quote (dates must be
            %   MATLAB date numbers).  Note that market
            %   quote represents the following for each instrument:
            %
            %   Deposit: Rate
            %   Futures: Price (e.g.: 9628.54)
            %   Swap: Rate
            %   Bond: Dirty Price
            %
            %   BOOTSTRAP can also be called with the following optional input
            %   parameters, specified in parameter value pairs, where these
            %   input arguments correspond to those in the class definition
            %   above.
            %
            %   BASIS
            %   COMPOUNDING
            %   INTERPMETHOD
            %   IRBOOTSTRAPOPTIONS: An IRBOOTSTRAPOPTIONS object
            %
            %   Note that additional instrument parameters (Basis,
            %   Period, etc.) may be passed in via parameter value pairs by
            %   prepending the word 'instrument' to the parameter field
            %   (this distinguishes, for example, the instrument basis from
            %   the curve basis), e.g. the basis for all instruments would
            %   be specified by the parameter 'InstrumentBasis'.
            %
            %   For instruments of type deposit, futures, or swap, basis
            %   and compounding must be identical for each instance of the
            %   instrument.
            % 
            %   Further note that simple interest can be specified for an
            %   instrument by specifying the compounding as 0.
            %
            %   Finally, if instrument basis and instrument compounding are
            %   not specified, the following default values are used:
            %
            %   Deposit: Basis: 2 (act/360), Compounding: 0 (simple int)
            %   Futures: Basis: 2 (act/360), Compounding: 4 (quarterly)
            %   Swap: Basis: 2 (act/360), Compounding: 2
            %   Bond: Basis: 0 (act/act), Compounding: 2
            
            % Parse inputs
            p = inputParser;
            
            p.addRequired('type',@ischar);
            p.addRequired('settle');
            p.addRequired('instrumenttypes',@iscell);
            p.addRequired('instruments',@isnumeric);
            
            p.addParamValue('compounding',2);
            p.addParamValue('basis',0);
            p.addParamValue('irbootstrapoptions',IRBootstrapOptions);
            p.addParamValue('interpmethod','linear');
            
            % Make all of these empty -- each instrument has its own
            % defaults
            p.addParamValue('instrumentperiod',[]);
            p.addParamValue('instrumentcouponrate',[]);
            p.addParamValue('instrumentbasis',[]);
            p.addParamValue('instrumentendmonthrule',[]);
            p.addParamValue('instrumentissuedate', []);
            p.addParamValue('instrumentfirstcoupondate', []);
            p.addParamValue('instrumentlastcoupondate', []);
            p.addParamValue('instrumentstartdate', []);
            p.addParamValue('instrumentface',[]);
            
            if ~strcmpi(Type,{'forward','zero'})
                error('finfixed:IRDataCurve:invalidType',...
                    'Bootsrapping requires a forward or zero curve')
            end
            
            try
                p.parse(Type, Settle, InstrumentTypes, Instruments,varargin{:});
            catch ME
                newME = MException('finfixed:IRDataCurve:optionalInputError',...
                    'Error in input arguments');
                newME = addCause(newME,ME);
                throw(newME)
            end
            
            Period = p.Results.instrumentperiod;
            CouponRate = p.Results.instrumentcouponrate;
            Basis = p.Results.instrumentbasis;
            EndMonthRule = p.Results.instrumentendmonthrule;
            IssueDate = p.Results.instrumentissuedate;
            FirstCouponDate = p.Results.instrumentfirstcoupondate;
            LastCouponDate = p.Results.instrumentlastcoupondate;
            StartDate = p.Results.instrumentstartdate;
            Face = p.Results.instrumentface;
            
            fBootstrapOptions = p.Results.irbootstrapoptions;
            CurveCompounding = p.Results.compounding;
            CurveBasis = p.Results.basis;
            InterpMethod = p.Results.interpmethod;
            
            % Construct an object with the inputs
            obj = IRDataCurve(Type,Settle,[],[],'Compounding',CurveCompounding,...
                'Basis',CurveBasis,'InterpMethod',InterpMethod);
            
            % First assumption is that we will have a group of instruments
            % Go by group
            UniqueInstruments = unique(InstrumentTypes);
            
            OrderedInstruments = {'deposit','futures','swap','bond'};
            
            % Check to see if these instrument types are acceptable
            if ~all(ismember(lower(UniqueInstruments),OrderedInstruments))
                error('finfixed:IRDataCurve:invalidInstruments',...
                    'Instruments must be deposits, futures, swaps or bonds')
            end
            
            depositidx = strcmpi('deposit',InstrumentTypes);
            futuresidx = strcmpi('futures',InstrumentTypes);
            swapidx = strcmpi('swap',InstrumentTypes);
            bondidx = strcmpi('bond',InstrumentTypes);
            
            % check to make sure that no futures start earlier than
            % deposits end
            if any(depositidx)
                if any(Instruments(futuresidx,2) < max(Instruments(depositidx,2)))
                    error('finfixed:IRDataCurve:earlyFutures',...
                        'All Futures must mature after deposit rates')
                end
            end
            
            % Bonds must specify coupon rates
            if any(bondidx) && isempty(CouponRate)
                error('finfixed:IRDataCurve:missingCoupon',...
                    'Bonds must specify coupon rates')
            end
            
            %%%
            % DEPOSITS
            %%%
            
            % If there are deposits available, use these to build the first
            % part of the forward curve -- if not, initialize these
            % variables as empty
            if any(depositidx)
                
                DepRates = Instruments(depositidx,3);
                DepDates = Instruments(depositidx,2);
                DepSettle = Instruments(depositidx,1);
                
                % check for deposit basis and period -- if empty, use the
                % default values of 2 and 0 respectively
                if ~isempty(Period)
                    DepPeriod = unique(Period(depositidx));
                    DepPeriod = DepPeriod(1);
                else
                    DepPeriod = 0; % simple interest
                end
                
                if ~isempty(Basis)
                    DepBasis = unique(Basis(depositidx));
                    DepBasis = DepBasis(1);
                else
                    DepBasis = 2; %actual/360
                end
                
                switch obj.Type
                    case 'Forward'
                        [BootRates BootDates] = loczero2fwd(DepRates,...
                            DepDates,DepSettle,DepPeriod,...
                            DepBasis,obj.Compounding,obj.Basis);
                    case 'Zero'
                        BootDates = DepDates;
                        BootRates = locConvert(DepRates,DepPeriod,...
                            DepBasis,obj.Compounding,obj.Basis,...
                            DepSettle,DepDates);
                end
            else
                BootRates = [];
                BootDates = [];
            end
            
            %%%
            % FUTURES
            %%%
            
            if any(futuresidx)
                
                FutStartDates = Instruments(futuresidx,2);
                FutQuotes = Instruments(futuresidx,3);
                FutSettle = Instruments(futuresidx,1);
                
                if ~isempty(Basis)
                    FutBasis = unique(Basis(futuresidx));
                    FutBasis = FutBasis(1);
                else
                    FutBasis = 2; % act/360
                end
                
                if ~isempty(Period)
                    FutPeriod = unique(Period(futuresidx));
                    FutPeriod = FutPeriod(1);
                else
                    FutPeriod = 4;
                end
                
                % We want the day of the month here
                FutEndDates = daysadd(FutStartDates,12/FutPeriod*30,1);
                FutEndTime = yearfrac(FutSettle,FutEndDates,FutBasis);
                
                % Convert from price to forward rate
                FutRates = (10000-FutQuotes)/10000;
                
                inConvAdj = fBootstrapOptions.ConvexityAdjustment;
                
                if ~isempty(inConvAdj)
                    if isa(inConvAdj,'function_handle')
                        try
                            ForwardRatesTemp = FutRates - feval(inConvAdj,FutEndTime);
                        catch ME
                            newME = MException('finfixed:IRDataCurve:convexityAdjustment',...
                                'Error in convexity adjustment function');
                            newME = addCause(newME,ME);
                            throw(newME)
                        end
                    else
                        if length(inConvAdj) == length(FutEndTime)
                            ForwardRatesTemp = FutRates - inConvAdj;
                        else
                            error('finfixed:IRDataCurve:missingCoupon',...
                                ['Convexity Adjustment must be either a ' ...
                                'function handle or a vector with length ' ...
                                'equal to the number of futures'])
                        end
                    end
                else
                    ForwardRatesTemp = FutRates;
                end
                
                FutForwardDates = FutStartDates;
                FutForwardRates = locConvert(ForwardRatesTemp,FutPeriod,...
                    FutBasis,obj.Compounding,obj.Basis,FutStartDates,FutEndDates);
                
                % Check to see if there are any overlapping dates
                oldays = FutEndDates(1:end-1) - FutStartDates(2:end);
                olidx = find(oldays > 0);
                
                FutForwardRates(olidx) = FutForwardRates(olidx) + ...
                    oldays(olidx)/90.*(FutForwardRates(olidx+1) - ...
                    FutForwardRates(olidx));
                
                BootDates = [BootDates;FutForwardDates];
                
                switch obj.Type
                    case 'Zero'
                        FutZeroRates = fwd2zero(FutForwardRates, FutForwardDates,...
                            obj.Settle, obj.Compounding, obj.Basis);
                        BootRates = [BootRates;FutZeroRates];
                    case 'Forward'
                        BootRates = [BootRates;FutForwardRates];
                end
            end
            
            %%%
            % SWAPS
            %%%
            
            SwapMaturitys = Instruments(swapidx,2);
            SwapRates = Instruments(swapidx,3);
            SwapSettle = unique(Instruments(swapidx,1));
            
            if any(swapidx)
                
                if ~isempty(Period)
                    SwapPeriod = unique(Period(swapidx));
                    SwapPeriod = SwapPeriod(1);
                else
                    SwapPeriod = 2;
                end
                
                if ~isempty(Basis)
                    SwapBasis = unique(Basis(swapidx));
                    SwapBasis = SwapBasis(1);
                else
                    SwapBasis = 2;
                end
                
                % Preallocate outputs
                BootDates = [BootDates(:); SwapMaturitys(:)];
                
                SwapCFDates = cfdates(SwapSettle, SwapMaturitys, ...
                    SwapPeriod, SwapBasis);
                SwapDates = unique(SwapCFDates);
                
                SwapDates(isnan(SwapDates))=[];
                
                SwapTimes = yearfrac(obj.Settle,SwapDates,obj.Basis);
                BootTimes = yearfrac(obj.Settle,BootDates,obj.Basis);
                
                SwapYearMats = [SwapTimes(1);diff(SwapTimes)];
                
            end
            
            function yout = objfun(x)
                
                switch obj.Type
                    case 'Forward'
                        ForwardRatesGuess = [BootRates;x];
                        
                        SwapForwardRates = locInterp(BootTimes,ForwardRatesGuess,...
                            SwapTimes,obj.InterpMethod);
                        % Get discount factors between time zero and CurveDates
                        if obj.Compounding == -1
                            SwapFwdDF = exp( -SwapForwardRates .* SwapYearMats);
                            
                        else
                            SwapFwdDF = (1 + SwapForwardRates/obj.Compounding ).^...
                                (-SwapYearMats*obj.Compounding);
                        end
                        
                        % Comput Discounts from settlement
                        SwapDF = cumprod(SwapFwdDF);
                    case 'Zero'
                        ZeroRatesGuess = [BootRates;x];
                        
                        SwapZeroRates = locInterp(BootTimes,ZeroRatesGuess,...
                            SwapTimes,obj.InterpMethod);
                        % Get discount factors between time zero and CurveDates
                        if obj.Compounding == -1
                            SwapDF = exp( -SwapZeroRates .* SwapTimes);
                            
                        else
                            SwapDF = (1 + SwapZeroRates/obj.Compounding ).^...
                                (-SwapTimes*obj.Compounding);
                        end
                end
                
                % Loop through to calculate guess swap rates
                predSwapRates = zeros(size(SwapRates));
                for jdx=1:length(SwapRates)
                    lastidx = yearfrac(SwapSettle,SwapMaturitys(jdx),1)*SwapPeriod;
                    predSwapRates(jdx) = (1-SwapDF(lastidx))./ ...
                        (sum(SwapDF(1:lastidx).*SwapYearMats(1:lastidx)));
                end
                
                yout = SwapRates(:) - predSwapRates(:);
            end
            
            if any(swapidx)
                x0 = repmat(.05,size(SwapRates));
                lb = zeros(size(SwapRates));
                ub = [];
                
                options = optimset('lsqnonlin');
                options = optimset(options,'display','iter');
                
                [NewSwapRates,resnorm,residual,exitflag] = ...
                                    lsqnonlin(@objfun,x0,lb,ub,options);
            
                if (exitflag == 0)
                    warning('finfixed:IRDataCurve:SwapLimitExceeded',...
                        ['Function evaluation or iteration limit exceeded for ' ...
                        'bootstrapping bond rates.']);
                elseif (exitflag < 0)
                    error('finfixed:IRDataCurve:SwapNoSolution',...
                        'Cannot solve for bootstrapping swap rates.')
                end
                
                BootRates = [BootRates;NewSwapRates];
            end
            
            %%%
            % BONDS
            %%%
            
            if any(bondidx)
                
                BondMaturitys = Instruments(bondidx,2);
                BondPrices = Instruments(bondidx,3);
                Settle = unique(Instruments(bondidx,1));
                
                if ~isempty(Period),Period = Period(bondidx);end
                if ~isempty(Basis),Basis = Basis(bondidx);end
                if ~isempty(EndMonthRule),EndMonthRule = EndMonthRule(bondidx);end
                if ~isempty(IssueDate),IssueDate = IssueDate(bondidx);end
                if ~isempty(FirstCouponDate),FirstCouponDate = FirstCouponDate(bondidx);end
                if ~isempty(LastCouponDate),LastCouponDate = LastCouponDate(bondidx);end
                if ~isempty(StartDate),StartDate = StartDate(bondidx);end
                if ~isempty(Face), Face = Face(bondidx);end
                
                CouponRate = CouponRate(bondidx);
                
                [CFlowAmounts, BondCFDates] = cfamounts(CouponRate, Settle,...
                    BondMaturitys, Period, Basis,EndMonthRule, IssueDate, ...
                    FirstCouponDate, LastCouponDate,StartDate, Face);
                
                [CFBondDate, BondDates] = cfport(CFlowAmounts,BondCFDates);
                
                BondTimes = yearfrac(obj.Settle,BondDates,obj.Basis);
                FwdYearMats = [BondTimes(1);diff(BondTimes)];
                
                BootDates = [BootDates(:); unique(BondMaturitys(:))];
                BootTimes = yearfrac(obj.Settle,BootDates,obj.Basis);
                
            end
            
            function yout = bondobjfun(x)
                
                switch obj.Type
                    case 'Forward'
                        ForwardRatesGuess = [BootRates;x];
                        
                        BondForwardRates = locInterp(BootTimes,ForwardRatesGuess,...
                            BondTimes,obj.InterpMethod);
                        
                        % Get discount factors between time zero and CurveDates
                        if obj.Compounding == -1
                            BondFwdDF = exp( -BondForwardRates .* FwdYearMats);
                            
                        else
                            BondFwdDF = (1 + BondForwardRates/obj.Compounding ).^...
                                (-FwdYearMats*obj.Compounding);
                        end
                        
                        % Comput Discounts from settlement
                        BondDF = cumprod(BondFwdDF);
                    case 'Zero'
                        ZeroRatesGuess = [BootRates;x];
                        
                        BondZeroRates = locInterp(BootTimes,ZeroRatesGuess,...
                            BondTimes,obj.InterpMethod);
                        
                        % Get discount factors between time zero and CurveDates
                        if obj.Compounding == -1
                            BondDF = exp( -BondZeroRates .* BondTimes);
                            
                        else
                            BondDF = (1 + BondZeroRates/obj.Compounding ).^...
                                (-BondTimes*obj.Compounding);
                        end
                        
                end
                
                predBondPrices = CFBondDate*BondDF;
                
                yout = BondPrices(:) - predBondPrices(:);
            end
            
            if any(bondidx)
                
                x0 = repmat(.05,sum(bondidx),1);
                lb = zeros(sum(bondidx),1);
                ub = ones(sum(bondidx),1);
                
                options = optimset('lsqnonlin');
                options = optimset(options,'display','iter');
                
                [NewRates,resnorm,residual,exitflag] = ...
                                    lsqnonlin(@bondobjfun,x0,lb,ub,options);
                
                if (exitflag == 0)
                    warning('finfixed:IRDataCurve:BondLimitExceeded',...
                        ['Function evaluation or iteration limit exceeded for ' ...
                        'bootstrapping bond rates.']);
                elseif (exitflag < 0)
                    error('finfixed:IRDataCurve:BondNoSolution',...
                        'Cannot solve for bootstrapping bond prices.')
                end
                
                BootRates = [BootRates;NewRates];
            end
            
            obj.Dates = BootDates;
            obj.Data = BootRates;
        end
    end
end

function yi = locInterp(x,Y,xi,method)
%LOCINTERP Wrapper for INTERP function
%   LOCINTERP is necessary to piecewise constant interpolation
%

if any(strcmpi(method,{'linear','nearest','spline','pchip'}))
    yi = interp1(x,Y,xi,method,'extrap');
else
    yi = zeros(size(xi));
    for jdx=1:length(xi)
        iIndex = find(xi(jdx) > x,1,'last');
        if isempty(iIndex),iIndex = 1;end
        yi(jdx) = Y(iIndex);
    end;
end
end

function [outRates outDates] = loczero2fwd(Rates,Dates,Settle,inPeriod,inBasis,...
    outPeriod,outBasis)
%LOCZERO2FWD Wrapper for ZERO2FWD function
%   LOCZERO2FWD is necessary to handle simple compound interest
%

if inPeriod == 0
    
    % Get values for T in terms of fractional years from the settlement date
    InYearMats = yearfrac(Settle, Dates, inBasis);
    
    % Get discount factors between time zero and CurveDates
    DiscountFromSettle = (1./(1 + Rates.*InYearMats));
    
    % Compute Forward Discounts
    FwdDiscounts = [DiscountFromSettle(1); ...
        DiscountFromSettle(2:end)./DiscountFromSettle(1:end-1)];
    
    % Convert Fwd Discounts to Forward Rates
    OutYearMats = yearfrac(Settle, Dates, outBasis);
    FwdYearMats = [OutYearMats(1); diff(OutYearMats)];
    
    if outPeriod == -1
        outRates = -log(FwdDiscounts)./FwdYearMats;
        
    else
        outRates = outPeriod * ...
            (FwdDiscounts.^(-1./(FwdYearMats*outPeriod)) - 1);
    end
    outDates = Dates;
else
    [outRates outDates] = zero2fwd(Rates,Dates,Settle,inPeriod,inBasis,outPeriod,outBasis);
end
end

function [OutComp,OutBasis] = locParseOptional(varargin)
%LOCPARSEOPTIONAL Parses inputs to getForwardRates, getZeroRates,
%getDiscountFactors functions
%

p = inputParser;

p.addParamValue('compounding',[],@(x) ismember(x,[-1 1 2 3 4 6 12]));
p.addParamValue('basis',[],@(x) ismember(x,0:12));

try
    p.parse(varargin{:});
catch ME
    newME = MException('finfixed:IRDataCurve:optionalInputError',...
        'Error in optional parameter value inputs');
    newME = addCause(newME,ME);
    throw(newME)
end

OutComp = p.Results.compounding;
OutBasis = p.Results.basis;
end

function outRate = locConvert(inRate,inComp,inBasis,outComp,outBasis,...
    StartDates,EndDates) %#ok
%LOCCONVERT Converts compounding and day count conventions
%

% Simple interest is signified with a 0 -- replace with a 1
inComp(inComp == 0) = 1;
if outComp == inComp
    outRate = inRate;
elseif outComp == -1
    outRate = log(1 + inRate/inComp)*inComp;
elseif inComp == -1
    outRate = outComp.*((exp(inRate).^(1/outComp)) - 1);
else
    outRate = ((1 + inRate/inComp).^(inComp/outComp) - 1).^outComp;
end
end