function WAL = mbswal(Settle, Maturity, IssueDate, GrossRate, varargin)
%  MBSWAL Weighted Average Life of mortgage pool.
%    Computes weighted average life of NMBS mortgage pool, in unit of 
%    years.
%
%    WAL = mbswal(Settle, Maturity, IssueDate, GrossRate )
%    WAL = mbswal(Settle, Maturity, IssueDate, GrossRate, CouponRate )
%    WAL = mbswal(Settle, Maturity, IssueDate, GrossRate, CouponRate, ...
%       Delay ) 
%    WAL = mbswal(Settle, Maturity, IssueDate, GrossRate, CouponRate, ...
%       Delay, PrepaySpeed )
%    WAL = mbswal(Settle, Maturity, IssueDate, GrossRate, CouponRate,
%       Delay, [], PrepayMatrix )
%
%    Optional Inputs:  CouponRate, Delay, PrepaySpeed, PrepayMatrix
%
%    Inputs:
%               Settle - NMBSx1 vector of settlement date. 
%                    
%             Maturity - NMBSx1 vector of maturity date.   
%                   
%            IssueDate - NMBSx1 vector of issue date.      
%                     
%            GrossRate - NMBSx1 vector of gross coupon rate, in decimal. 
%
%    Optional Inputs:
%           CouponRate - NMBSx1 vector of Net Coupon Rate, in decimal. 
%                        Default is equal to GrossRate. 
%              
%                Delay - NMBSx1 vector of delay in days.
%   
%          PrepaySpeed - NMBSx1 vector of speed relative to PSA standard.
%                        PSA standard is 100. 
%                        Default is 0 (zero) prepayment speed.
%
%         PrepayMatrix - Customized prepayment vector. A matrix of size 
%                        [max(TermRemaining) x NMBS]. Missing values are
%                        padded with NaNs.  Each column corresponds to each
%                        MBS, and each row corresponds to each month after
%                        settlement. 
%
%    Outputs:
%                  WAL - Weighted Average Life of MBS, in number of years.
%
%    Example:
%     Settle    = datenum('15-Apr-2002');
%     Maturity  = datenum('01 Jan 2030');
%     IssueDate = datenum('01-Jan-2000');
%     GrossRate = 0.08125;
%     CouponRate = 0.075;
%     Delay = 14;
%     Speed = 100;
% 
%     WAL = mbswal(Settle, Maturity, IssueDate, GrossRate, ...
%          CouponRate, Delay, Speed)
%
%     WAL =
%        10.547737776
%
%    Note: This function is PSA compliant. 
%    Reference: PSA Uniform Practices, SF-49

%   Copyright 2002-2004 The MathWorks, Inc.
%   $Revision: 1.7.6.6 $  $Date: 2005/06/17 20:25:24 $

if nargin<4
    error('finfixed:mbswal:invalidMoreInputs',...
        'Not enough input arguments');
end

% Compute the Cash flow, Time Factors, and mortgage factors 
[CFlowAmounts dummy TFactors Factors] = ...
    mbscfamounts(Settle, Maturity, IssueDate, GrossRate,varargin{1:end});

% Calculate the Principal with Prepay value
Principal = diff(Factors,1,2);

% assign zeros to appending nans.
TFactors(isnan(TFactors)) = 0;
Principal(isnan(Principal)) = 0;

% Annualize time factors
TFactors  = TFactors./12;

% Calculate WAL based on PSA Uniform Practices, SF-49
WAL = sum([Principal .* TFactors(:,2:end)],2) ./  sum(Principal,2);

% [EOF]
