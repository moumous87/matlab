%CHAPTER 6

%UPLOAD DATASET FOR EXERCISE 5: SIMULATION BASED METHODS

[filename,pathname]=uigetfile('*.xls');
[prices1,textdata,raw] = xlsread(filename,1);

%--------------------------------------------------------------------------

%QUESTION N.1

%Calculate the returns
date=datenum(textdata(2:end,1),'dd/mm/yyyy');
f=['03/01/2005';'30/10/2008'];
date_find=datenum(f,'dd/mm/yyyy');
ind=datefind(date_find,date);
prices=prices1(ind(1):ind(2),end-4:end);

returns= 100*log(prices(2:end,:)./prices(1:end-1,:));
returns_eubp=returns(:,1);
returns_euusd=returns(:,2);
returns_msci_eu=returns(:,3);
returns_msci_usa=returns(:,4)+returns_euusd;
returns_msci_uk=returns(:,5)+returns_eubp;
weights=ones(3,1)./3;
port_returns=[returns_msci_eu,returns_msci_usa,returns_msci_uk]*weights;
%--------------------------------------------------------------------------

%QUESTION N.2

%GARCH(1,1) with Leverage Effect estimation for portfolio returns
spec=garchset('Distribution','Gaussian','VarianceModel','GJR','P',1,'Q',1,'K',0.00005,'GARCH',0.85,'ARCH',0.1,'Leverage',0.005);
[coeff,errors,llf,innovation,sigma,summary]=garchfit(spec,port_returns);
%--------------------------------------------------------------------------

%QUESTION N.3

%Calculate the returns for the 2006/2007
date=datenum(textdata(2:end,1),'dd/mm/yyyy');
f=['31/10/2008';'20/01/2009'];
date_find=datenum(f,'dd/mm/yyyy');
ind=datefind(date_find,date);
prices=prices1(ind(1):ind(2),end-4:end);

returns= 100*log(prices(2:end,:)./prices(1:end-1,:));
returns_eubp=returns(:,1);
returns_euusd=returns(:,2);
returns_msci_eu=returns(:,3);
returns_msci_usa=returns(:,4)+returns_euusd;
returns_msci_uk=returns(:,5)+returns_eubp;
weights=ones(3,1)./3;
port_returns_0607=[returns_msci_eu,returns_msci_usa,returns_msci_uk]*weights;
port_returns_all=[port_returns;port_returns_0607];

%Var Historical simulation
r=size(port_returns,1);
alpha=0.01;
for i=1:size(port_returns_0607,1)
    Var_HS(i)=prctile(port_returns_all(1:r+i-1),alpha*100);
end
%Var with Garch
spec=garchset('Distribution','Gaussian','C',coeff.C,'VarianceModel','GJR','P',coeff.P,'Q',coeff.Q,'K',coeff.K,'GARCH',coeff.GARCH,'ARCH',coeff.ARCH,'Leverage',coeff.Leverage);
SigmaForecast=garchpred(spec,port_returns(end),1);
for i=1: ind(2)-ind(1)-1
    SigmaForecast(i+1) = garchpred(spec,port_returns_0607(i),1);
end
Var_garch=norminv(alpha,0,SigmaForecast);
%Var Filtered Historical simulation
%%Boostrap
port_returns_std=port_returns./sigma;
f = ceil(size(port_returns_std,1).*rand(1,10000));
shock=port_returns_std(f);
port_returns_forecast=shock*SigmaForecast(1,1);
Var_FHS=prctile(port_returns_forecast,alpha*100);
for i= 1:ind(2)-ind(1)-1
    port_returns_std(end+1,:)=port_returns_0607(i)/SigmaForecast(i);
    f = ceil(size(port_returns_std,1).*rand(1,10000));
    shock=port_returns_std(f);
    port_returns_forecast=shock*SigmaForecast(i+1);
    Var_FHS(i+1,1)=prctile(port_returns_forecast,alpha*100);
    %pack
end

%Plot the results
figure
plot([Var_FHS,Var_HS',Var_garch',port_returns_0607]);
h = legend('Var FHS','Var HS','Var GARCH','Portfolio',2);