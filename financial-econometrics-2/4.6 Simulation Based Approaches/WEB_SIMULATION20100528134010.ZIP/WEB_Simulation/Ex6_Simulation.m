%% EXERCISE 6: SIMULATION-BASED METHODS

clc, clear,clear global,close all

path(path,'C:\Program Files\MATLAB\R2009a\toolbox\lesage\optimize');
path(path,'C:\Program Files\MATLAB\R2009a\toolbox\lesage\util');

%% QUESTION 1

% UPLOAD THE DATASET

[filename pathname]=uigetfile('*.xls');
[data textdata raw]=xlsread(filename,1);

f=['02/01/2006';'30/06/2006';'29/12/2006';'29/06/2007';'31/12/2007';'30/06/2008';'31/12/2008';'30/06/2009';'31/12/2009'];
date=datenum(textdata(3:end,1),'dd/mm/yyyy'); 
date_find=datenum(f,'dd/mm/yyyy');
index=datefind(date_find,date);
start=datefind(date_find(1,1),date(2:end));
final_2008=datefind(date_find(7,1),date(2:end)); 
final_2009=datefind(date_find(9,1),date(2:end)); 

% COMPUTE THE PORTFOLIO RETURNS
prices=data(:,18:22);
returns_all=100*log(prices(2:end,:)./prices(1:end-1,:));
ret_eubp=returns_all(:,1);
ret_euus=returns_all(:,2);
ret_msci_eu=returns_all(:,3);
ret_msci_usa=returns_all(:,4)-ret_euus;
ret_msci_uk=returns_all(:,5)-ret_eubp;
w=[1/3;1/3;1/3];
port_ret=[ret_msci_eu, ret_msci_usa, ret_msci_uk]*w;

% PLOT RETURNS between 1/1/2006 and 31/12/2008
t=1:final_2008;

figure;
plot(t',port_ret(start:final_2008,1),'color',[0 .5 0]);
set(gca,'fontname','garamond','fontsize',10);
set(gca,'xtick',index(1:7),'xticklabel','Jan2006|June2006|Dec2006|June2007|Jan2008|Jun2008|Dec2008','xlim',[1 rows(t')+1]);
xlabel('Time');
ylabel('Portfolio returns');
title('Portfolio Returns','fontname','garamond','fontsize',12,'Color', [.3 .3 .3]);
set(gcf,'color','w');
set(gca,'Box', 'off', 'TickDir', 'out', 'TickLength', [.02 .02],'XMinorTick', 'off','YMinorTick', 'off','XColor', [.3 .3 .3],'YColor',[.3 .3 .3],'LineWidth', 1, 'FontName', 'Garamond','fontsize',10);

%% QUESTION 2
% Note: to estimate a GARCH with leverage model both GJR and NGARCH models are allowed. Both solutions are provided.  

% GARCH WITH LEVERAGE MODEL
% NGARCH estimation (Method 1)
global cond_var
par_initial_ng(1:4,1)=[0.05;0.1;0.05;0.85]; % par_init=[omega;alpha;theta;beta]
[param_ng,mle_ng]=fminsearch('ngarch',par_initial_ng,[],port_ret(start:final_2008,:));
global param_ng
cond_vol_ng=sqrt(cond_var);
% GJR-GARCH estimation (Method 2) 
spec_gjr=garchset('VarianceModel','GJR','P',1,'Q',1);
[param_gjr,errors_gjr,llf_gjr,innovation_gjr,sigmas_gjr,summary_gjr]=garchfit(spec_gjr,port_ret(start:final_2008,:));
garchdisp(param_gjr,errors_gjr);
z_gjr=port_ret(start:final_2008,:) ./ sigmas_gjr;

% EXPONENTIAL SMOOTHING
global cond_var_es
par_initial_es=[0.1];
[lambda,mle_es]=fminsearch('exp_smoothing',par_initial_es,[],port_ret(start:final_2008,1));
cond_vol_es=sqrt(cond_var_es);

% COMPARE GARCH MODEL AND EXPONENTIAL SMOOTHING

%NGARCH
figure;
plot(t',cond_vol_ng,'k',t',cond_vol_es,'m');
set(gca,'fontname','garamond','fontsize',10);
set(gca,'xtick',index(1:7),'xticklabel','Jan2006|June2006|Dec2006|June2007|Jan2008|Jun2008|Dec2008','xlim',[1 rows(t')+1]);
xlabel('Time');
ylabel('Conditional Volatilities');
title('NGARCH vs EXPONENTIAL SMOOTHING','fontname','garamond','fontsize',12,'Color', [.3 .3 .3]);
set(gcf,'color','w');
set(gca,'Box', 'off', 'TickDir', 'out', 'TickLength', [.02 .02],'XMinorTick', 'off','YMinorTick', 'off','XColor', [.3 .3 .3],'YColor',[.3 .3 .3],'LineWidth', 1, 'FontName', 'Garamond','fontsize',10);
legend('NGARCH','Exp\_Smoothing',0);

%GJR-GARCH
figure;
plot(t',sigmas_gjr,'k',t',cond_vol_es,'m');
set(gca,'fontname','garamond','fontsize',10);
set(gca,'xtick',index(1:7),'xticklabel','Jan2006|June2006|Dec2006|June2007|Jan2008|Jun2008|Dec2008','xlim',[1 rows(t')+1]);
xlabel('Time');
ylabel('Conditional Volatilities');
title('GJR-GARCH vs EXPONENTIAL SMOOTHING','fontname','garamond','fontsize',12,'Color', [.3 .3 .3]);
set(gcf,'color','w');
set(gca,'Box', 'off', 'TickDir', 'out', 'TickLength', [.02 .02],'XMinorTick', 'off','YMinorTick', 'off','XColor', [.3 .3 .3],'YColor',[.3 .3 .3],'LineWidth', 1, 'FontName', 'Garamond','fontsize',10);
legend('GJR-GARCH','Exp\_Smoothing',0);


%% QUESTION 3
% Note: to estimate a GARCH with normal distribution alternative solutions
% are allowed. In the following we consider a GJR-GARCH, a GARCH(1,1) and a
% NGARCH.

f1=['01/01/2009';'31/03/2009';'30/06/2009';'30/09/2009';'31/12/2009'];
date_find1=datenum(f1,'dd/mm/yyyy');
index_2009=datefind(date_find1,date(final_2008+1:end));

% Parameters
p=0.01;
q_norm=norminv(p,0,1);

%% 3.1) GARCH with Normal Distribution

% a) NGARCH with Normal Distribution

cvar2009_ng(1,1)=param_ng(1,1)+param_ng(2,1)*...
    (port_ret(final_2008,1)-param_ng(3,1)*cond_vol_ng(final_2008,1))^2+...
    param_ng(4,1)*cond_var(final_2008,1);
ret_2009=port_ret(final_2008+1:final_2009);

for i=2:final_2009-final_2008
    cvar2009_ng(i,1)=param_ng(1,1)+param_ng(2,1)*...
        (ret_2009(i-1,1)-param_ng(3,1)*sqrt(cvar2009_ng(i-1,1))).^2+...
        param_ng(4,1)*cvar2009_ng(i-1,1);
end

sigma2009_ng=sqrt(cvar2009_ng);
VaR_ng=-q_norm*sigma2009_ng;

%% b) GJR-GARCH with Normal Distribution

% Note: to compute the forecasted conditional variance you can write a
% function (i.e. "gjr_fra") or use the command "garchpred". Pay attention
% to the inizialisation: in the first case you must choose an initial value for
% the conditional variance but in the second case Matlab does it for you!
% Compare the results.

% Method 1: function "gjr_fra"
p_gjr=[param_gjr.K;param_gjr.ARCH;param_gjr.Leverage;param_gjr.GARCH];
[mle_gjr,ret_gjr_std,cond_var_gjr]=gjr_fra(p_gjr,ret_2009,sigmas_gjr(final_2008,1)^2);
sigma2009_gjr_f=sqrt(cond_var_gjr);

% Method 2: "garchpred"
spec_gjr=garchset('C', param_gjr.C,'VarianceModel','GJR','P',1,'Q',1,'K', param_gjr.K,'GARCH', param_gjr.GARCH,'ARCH', param_gjr.ARCH,'leverage', param_gjr.Leverage);
for i=1:final_2009-final_2008
sigma2009_gjr_gp(i,1)=garchpred(spec_gjr,port_ret(start:final_2008+i-1),1);
end

VaR_gjr_1=-q_norm*sigma2009_gjr_f;
VaR_gjr_2=-q_norm*sigma2009_gjr_gp;

% Compare VaRs-gjr
s=1:final_2009-final_2008;
figure;
plot(s',-VaR_gjr_1(1:end),'b',s',-VaR_gjr_2(1:end),'m');
hold on
plot(s',port_ret(final_2008+1:final_2009),'color',[.5 0 .4]);
set(gca,'fontname','garamond','fontsize',10);
set(gca,'xtick',index_2009,'xticklabel','Jan2009|Mar2009|June2009|Sep2009|Dec2009','xlim',[1 rows(s')]);
xlabel('Time');
ylabel('VaRs-gjr & Returns');
title('VaRs: GJR vs RETURNS','fontname','garamond','fontsize',12,'Color', [.3 .3 .3]);
set(gcf,'color','w');
set(gca,'Box', 'off', 'TickDir', 'out', 'TickLength', [.02 .02],'XMinorTick', 'off','YMinorTick', 'off','XColor', [.3 .3 .3],'YColor',[.3 .3 .3],'LineWidth', 1, 'FontName', 'Garamond','fontsize',10);
legend('GJR-GARCH: Garchpred','GJR-GARCH: gjr-function','RETURNS',0);

%% c) GARCH(1,1) with Normal Distribution
% Note: see above.

spec_garch=garchset('P',1,'Q',1);
[coeff, errors,llf,innovation,sigma,summary]=garchfit(spec_garch,port_ret(start:final_2008,1));
garchdisp(coeff,errors);

% Method 1: by iteration
cvar2009_garch_f(1,1)=coeff.K+coeff.ARCH*port_ret(final_2008,1)^2+coeff.GARCH*sigma(final_2008,1)^2
for i=2:final_2009-final_2008
cvar2009_garch_f(i,1)=coeff.K+coeff.GARCH*cvar2009_garch_f(i-1,1)+coeff.ARCH*ret_2009(i-1,1).^2;
end
% Method 2: "garchpred"
for i=1:final_2009-final_2008
spec_garch=garchset('P',1,'Q',1,'C',coeff.C,'GARCH',coeff.GARCH,'ARCH',coeff.ARCH,'K',coeff.K);
sigma2009_garch_gp(i,1)=garchpred(coeff,port_ret(start:final_2008+i-1),1);
end

sigma2009_garch_f=sqrt(cvar2009_garch_f);

VaR_garch_1=-q_norm*sigma2009_garch_f;
VaR_garch_2=-q_norm*sigma2009_garch_gp;

% Compare VaRs - GARCH (1,1)
figure;
plot(s',-VaR_garch_1(1:end),'b',s',-VaR_garch_2(1:end),'m');
hold on
plot(s',port_ret(final_2008+1:final_2009),'color',[.5 0 .4]);
set(gca,'fontname','garamond','fontsize',10);
set(gca,'xtick',index_2009,'xticklabel','Jan2009|Mar2009|June2009|Sep2009|Dec2009','xlim',[1 rows(s')]);
xlabel('Time');
ylabel('VaRs-GARCH(1,1) & Returns');
title('VaRs: GARCH(1,1) vs RETURNS','fontname','garamond','fontsize',12,'Color', [.3 .3 .3]);
set(gcf,'color','w');
set(gca,'Box', 'off', 'TickDir', 'out', 'TickLength', [.02 .02],'XMinorTick', 'off','YMinorTick', 'off','XColor', [.3 .3 .3],'YColor',[.3 .3 .3],'LineWidth', 1, 'FontName', 'Garamond','fontsize',10);
legend('GARCH-Garchpred','GARCH-function','RETURNS',0);

%% GARCH with Normal Distribution: compare a)-b)-c)
y=1:final_2009-final_2008;
figure;
plot(y',-VaR_garch_2,'g',y',-VaR_ng,'m',y',-VaR_gjr_2,'b');
hold on
plot(y',port_ret(final_2008+1:final_2009),'color',[.5 0 .4]);
set(gca,'fontname','garamond','fontsize',10);
set(gca,'xtick',index_2009,'xticklabel','Jan2009|Mar2009|June2009|Sep2009|Dec2009','xlim',[1 rows(y')]);
xlabel('Time');
ylabel('VaRsGARCH vs Returns');
title('VaRs and GARCH: a Comparison ','fontname','garamond','fontsize',12,'Color', [.3 .3 .3]);
set(gcf,'color','w');
set(gca,'Box', 'off', 'TickDir', 'out', 'TickLength', [.02 .02],'XMinorTick', 'off','YMinorTick', 'off','XColor', [.3 .3 .3],'YColor',[.3 .3 .3],'LineWidth', 1, 'FontName', 'Garamond','fontsize',10);
legend('GARCH','NGARCH','GJR-GARCH','Returns',0);

%% 3.2) EXPONENTIAL SMOOTHING
N=final_2009-final_2008;
returns_es=port_ret(final_2008+1:final_2009,1);
cond_var_rm=NaN(N,1);
cond_var_rm(1,1)=lambda*cond_var_es(final_2008,1)+(1-lambda)*port_ret(final_2008,1).^2;
for i=2:N
cond_var_rm(i,1)=lambda*cond_var_rm(i-1,1)+(1-lambda)*returns_es(i-1,1).^2;
end

VaR_rm=-sqrt(cond_var_rm).*q_norm;

%% 3.3) HISTORICAL SIMULATION 
m=251;
returns=port_ret(final_2008-m+1:final_2009);

for k=1:N
VaR_HS(k,1)=-quantile(returns(k:k+m-1),p);
% remember: MATLAB interpolates automatically assuming cummulative
% distribution for the k-th observation of a sample of size m equal to
% (k-0.5)/m
 end

%% 3.4) FILTERED HISTORICAL SIMULATION

%Note: we are using ngarch model to construct the sample of z's.
%Remember: you must first be sure that the z's are independent! At least
%they should not be correlated. Are they? Check!

cond_var_ng(1,1)=var(port_ret);

for i=2:rows(port_ret)
    cond_var_ng(i,1)=param_ng(1,1)+param_ng(2,1)*(port_ret(i-1,1)-param_ng(3,1)*sqrt(cond_var_ng(i-1,1)))^2+param_ng(4,1)*cond_var_ng(i-1,1);
end

z_ret=port_ret(final_2008-m+1:final_2009)./sqrt(cond_var_ng(final_2008-m+1:final_2009));

for k=1:N
VaR_FHS(k,1)=-quantile(z_ret(k:k+m-1),p)*sqrt(cond_var_ng(final_2008+k,1));
end

%% COMPARE DAILY VaRs

figure;
plot(y',-VaR_ng,'b',y',-VaR_rm,'m',y',-VaR_HS,'g',y',-VaR_FHS,'c');
hold on
plot(y',port_ret(final_2008+1:final_2009),'color',[.5 0 .4]);
set(gca,'fontname','garamond','fontsize',10);
set(gca,'xtick',index_2009,'xticklabel','Jan2009|Mar2009|June2009|Sep2009|Dec2009','xlim',[1 rows(y')]);
xlabel('Time');
ylabel('VaRs & Returns');
title('ALTERNATIVE VaRs vs RETURNS','fontname','garamond','fontsize',12,'Color', [.3 .3 .3]);
set(gcf,'color','w');
set(gca,'Box', 'off', 'TickDir', 'out', 'TickLength', [.02 .02],'XMinorTick', 'off','YMinorTick', 'off','XColor', [.3 .3 .3],'YColor',[.3 .3 .3],'LineWidth', 1, 'FontName', 'Garamond','fontsize',10);
legend('NGARCH-NormalDist','ExpSmoothing','HS','FHS','Returns',0);

% In the graph, note how HS is too conservative. This is due
% to our sample size of 251 (one year of observations), the
% "backward-looking" feature of this procedure, and the fact that 2008
% was a crisis year!! Remember, the assumption is that the future will 
% have the same distribution as the past. If you are not comfortable with 
% this assumption you can always "improve" this procedure by
% cleaning the data from (what you consider to be) outliers.

%% QUESTION 4

% Note 1: the solution is based on Filtered Historical Simulation + NGARCH
% Note 2: pay attention to the results, the estimation sample includes the
% financial crisis!

mc=10000;
VaR_all_fh=NaN(4,1);
horizon=[1; 5; 20; 251];

for j=1:rows(horizon)
cond_var=NaN(mc,horizon(j,1));
cond_var(:,1)=cond_var_ng(final_2008+1);
ret_sim_fh=NaN(mc,horizon(j,1));
z_fh=port_ret(start:final_2008)./cond_vol_ng;
z_sim_fh=randsample(z_fh,mc,true);
ret_sim_fh(:,1)=z_sim_fh(:,1).*sqrt(cond_var(:,1));

for i=2:horizon(j,1)
cond_var(:,i)=param_ng(1,1)+param_ng(2,1)*(ret_sim_fh(:,i-1)-param_ng(3,1)*sqrt(cond_var(:,i-1))).^2+param_ng(4,1)*cond_var(:,i-1);
z_sim_fh=randsample(z_fh,mc,true);
ret_sim_fh(:,i)=z_sim_fh.*sqrt(cond_var(:,i));
clear z_sim_fh
end

ret_cum_fh=sum(ret_sim_fh,2);
VaR_all_fh(j,1)=-quantile(ret_cum_fh,p);
clear cond_var ret_sim_fh
end

disp('Table 1: QUESTION 4 - Multihorizon VaRs '); fprintf('\n');
 fprintf('HORIZON           '); fprintf('PERCENTAGE        ');fprintf('\n');
 fprintf('1 day               '); fprintf('%1.3f ',VaR_all_fh(1,1));fprintf('\n');
 fprintf('1 week             ');  fprintf('%1.3f ',VaR_all_fh(2));fprintf('\n');
 fprintf('1 month            ');  fprintf('%1.3f ',VaR_all_fh(3));fprintf('\n');
 fprintf('1 year            ');   fprintf('%1.3f ',VaR_all_fh(4));fprintf('\n');
 fprintf('\n');

% NOTE ON THE RESULTS: 
% Due to the "financial crisis effect", the results above seem too 
% conservative. Below we repeat the same exercise given the information 
% available until 31/12/2007. Compare the outcomes.

%% Excluding the crisis

final_2007=datefind(date_find(5,1),date(2:end)); 

% NGARCH estimation
global cond_var
par_initial_ng(1:4,1)=[0.05;0.1;0.05;0.85]; % par_init=[omega;alpha;theta;beta]
[param_ng2,mle_ng2]=fminsearch('ngarch',par_initial_ng,[],port_ret(start:final_2007,:));
cond_vol_ng2=sqrt(cond_var);

cvar_i2008=param_ng2(1,1)+param_ng2(2,1)*...
    (port_ret(final_2007,1)-param_ng2(3,1)*sqrt(cond_var(final_2007,1)))^2+...
    param_ng2(4,1)*cond_var(final_2007,1); 
% VaRs: FHS+NGARCH
VaR_all_fh2=NaN(4,1);

for j=1:rows(horizon)
cond_var2=NaN(mc,horizon(j,1));
cond_var2(:,1)=cvar_i2008;
ret_sim_fh2=NaN(mc,horizon(j,1));
z_fh2=port_ret(start:final_2007)./cond_vol_ng2;
z_sim_fh2=randsample(z_fh2,mc,true);
ret_sim_fh2(:,1)=z_sim_fh2(:,1).*sqrt(cond_var2(:,1));

for i=2:horizon(j,1)
cond_var2(:,i)=param_ng2(1,1)+param_ng2(2,1)*...
    (ret_sim_fh2(:,i-1)-param_ng2(3,1)*sqrt(cond_var2(:,i-1))).^2+...
    param_ng2(4,1)*cond_var2(:,i-1);
z_sim_fh2=randsample(z_fh2,mc,true);
ret_sim_fh2(:,i)=z_sim_fh2.*sqrt(cond_var2(:,i));

clear z_sim_fh2
end

ret_cum_fh2=sum(ret_sim_fh2,2);
VaR_all_fh2(j,1)=-quantile(ret_cum_fh2,p);
end

disp('Table 2: QUESTION 4 - Crisis vs No Crisis '); fprintf('\n');
 fprintf('HORIZON       '); fprintf('PERCENTAGE Crisis        '); fprintf('PERCENTAGE No Crisis');   fprintf('\n');
 fprintf('1 day               '); fprintf('%1.3f ',VaR_all_fh(1,1));  fprintf('                    '); fprintf('%1.3f ',VaR_all_fh2(1,1)); fprintf('\n');
 fprintf('1 week             ');  fprintf('%1.3f ',VaR_all_fh(2));    fprintf('                    '); fprintf('%1.3f ',VaR_all_fh2(2)); fprintf('\n');
 fprintf('1 month            ');  fprintf('%1.3f ',VaR_all_fh(3));    fprintf('                   '); fprintf('%1.3f ',VaR_all_fh2(3));  fprintf('\n');
 fprintf('1 year            ');   fprintf('%1.3f ',VaR_all_fh(4));    fprintf('                   '); fprintf('%1.3f ',VaR_all_fh2(4));  fprintf('\n');
 fprintf('\n');


%% Exercise: Repeat question 3 (VaRs for 2009) for NGARCH, HS, and FHS 
%  using the parameters of the NGARCH model estimated without the crisis 
% (param_ng2). Plot the results and compare them to Figure 7.





