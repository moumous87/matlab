function y = exp_smoothing(lambda,y)
global cond_var_es
ret=y;
R=rows(ret);
C=cols(ret);
global param_ng
cond_var_es=NaN(R,C);
cond_var_es(1,1)=param_ng(1)/(1-param_ng(2)*(1+param_ng(3)^2)-param_ng(4));
for i=2:R
cond_var_es(i,1)=(1-lambda)*ret(i-1,1).^2+lambda*cond_var_es(i-1,1);
end
z=ret./sqrt(cond_var_es);

y=-sum(-0.5*log(2*pi)-0.5*log(cond_var_es)-0.5*(z.^2));