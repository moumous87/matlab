function [sumloglik,z,cond_var_gjr] = gjr_fra(par,y,initial)
global cond_var_gjr 
%par=[omega;alpha;theta;beta]

ret=y;
R=rows(ret);
cond_var_gjr=NaN(R,1);
cond_var_gjr(1,1)=initial;
I=(ret<0);
for i=2:R
    cond_var_gjr(i,1)=par(1,1)+par(2,1)*ret(i-1,1).^2+par(3,1)*I(i-1,1)*ret(i-1,1).^2+par(4,1)*cond_var_gjr(i-1,1);
end
z=ret./sqrt(cond_var_gjr);

sumloglik=-sum(-0.5*log(2*pi)-0.5*log(cond_var_gjr)-0.5*(z.^2));


