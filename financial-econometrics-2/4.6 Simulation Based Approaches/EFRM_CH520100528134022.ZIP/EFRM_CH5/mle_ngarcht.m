function tloglik=mle_ngarcht(par,y)
ret=y;
R=rows(ret);
c_var=NaN(R,1);
c_var(1,1)=var(ret);
for i=2:R
    c_var(i,1)=par(1,1)+par(2,1)*(ret(i-1,1)-par(4,1)*sqrt(c_var(i-1,1)))^2+par(3,1)*c_var(i-1,1);

end

tloglik=-sum(gammaln((par(5,1)+1)/2)-gammaln(par(5,1)/2)-0.5*log(pi)-0.5*log(par(5,1)-2)-0.5*(1+par(5,1))*log(1+((ret.^2)./c_var)./(par(5,1)-2))-0.5*log(c_var));

%z=ret./sqrt(c_var);


