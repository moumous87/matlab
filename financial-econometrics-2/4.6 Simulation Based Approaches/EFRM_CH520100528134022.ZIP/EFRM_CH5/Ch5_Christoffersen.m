%% CHRISTOFFERSEN CHAPTER 5

clc, clear, close all

path(path,'C:\Program Files\MATLAB\R2009a\toolbox\lesage\optimize');
path(path,'C:\Program Files\MATLAB\R2009a\toolbox\lesage\util');


%% UPLOAD DATASET 

[filename1, pathname]=uigetfile('*.xls');
[price1,textdata1,raw1]=xlsread(filename1,1);

date=datenum(textdata1(3:end,1),'dd/mm/yyyy');
sp_ret=log(price1(2:end,:) ./ price1(1:end-1,:));

%% QUESTIONS 1 & 2
% Parameters

p=0.01;
m=250;
T=rows(sp_ret);
N=T-m;
eta=0.99;

%% Historical simulation

VaR_HS_long=NaN(N,1);
VaR_HS_short=NaN(N,1);
for k=1:N
VaR_HS_long(k,1)=-quantile(sp_ret(k:k+m-1,1),p);
VaR_HS_short(k,1)=-quantile(-sp_ret(k:k+m-1,1),p);
end

%% Weighted historical simulation

% Method 1: ignoring interpolation
for k=1:N

[ret_sort I]=sort(sp_ret(k:k+m-1,1));
weight=(eta.^(m-I)*(1-eta)/(1-eta^m));

csum=cumsum(weight);
ind=rows(csum(csum<p));

if ind==0
VaR_WS_long(k,1)=-ret_sort(ind+1); 
else
    
VaR_WS_long(k,1)=-ret_sort(ind);
end
end

% Method 2: interpolation
for i=1:2
if i==1
index=1;
elseif i==2
index=-1;
end
for k=1:N

[ret_sort I]=sort(sp_ret(k:k+m-1,1)*index);
weight=(eta.^(m-I)*(1-eta)/(1-eta^m));
csum=cumsum(weight);
ind=rows(csum(csum<p)); 
if ind==0
VaR_WS_int(k,i)=-ret_sort(ind+1); 
else
lambda=(p-csum(ind,1))./(csum(ind+1,1)-csum(ind));   
VaR_WS_int(k,i)=-(lambda*ret_sort(ind+1,1)+(1-lambda)*ret_sort(ind,1));
end  
end
end

VaR_WS_long_int=VaR_WS_int(:,1);
VaR_WS_short_int=VaR_WS_int(:,2);

%% Plot the results
f=['01/10/1987';'06/10/1987';'12/10/1987';'16/10/1987';'21/10/1987';'26/10/1987';'30/10/1987'];
date_find=datenum(f,'dd/mm/yyyy');
index_Oct=datefind(date_find(1,:),date);
index=datefind(date_find,date(index_Oct:end,:));
start=datefind(date_find(1,:),date);
final=datefind(date_find(end,:),date);

% Long Position
label=strvcat('HS: Long Position','WS: Long Position');

ret2=sp_ret(start:final,:).*100;
VaR_long=[VaR_HS_long*100 VaR_WS_long_int*100];
t=1:22;
figure;
for i=1:2
subplot(2,1,i)
plot(t',VaR_long(:,i),'-','color','k','Linewidth',2);
hold on
plot(t',-sp_ret(start:final,1)*100,'Marker','*','color',[0 .9 0]);
set(gca,'xtick',index,'xticklabel','1Oct|6Oct|12Oct|16Oct|21Oct|26Oct|30Oct','xlim',[1 rows(t')]);
ylabel('VaR and Loss');
xlabel('Loss Date');
set(gcf,'color','w');
set(gca,'Box', 'on','XColor', [.3 .3 .3],'YColor',[.3 .3 .3],'LineWidth', 1,'fontname','garamond','fontsize',10,'ylim',[-15 25]);
grid;
tit=label(i,:);
title(tit,'fontname','garamond','fontsize',12,'Color', [.3 .3 .3]);
legend('VaR','Returns',0);

end

% Short Position
VaR_short=[VaR_HS_short*100 VaR_WS_short_int*100];
label1=strvcat('HS: Short Position','WS: Short Position');
figure;
for i=1:2
subplot(2,1,i)
plot(t',VaR_short(:,i),'-','color','k','Linewidth',2);
hold on
plot(t',sp_ret(start:final,1)*100,'Marker','*','color',[0 .9 0]);
set(gca,'xtick',index,'xticklabel','1Oct|6Oct|12Oct|16Oct|21Oct|26Oct|30Oct','xlim',[1 rows(t')]);
ylabel('VaR and Loss');
xlabel('Loss Date');
set(gcf,'color','w');
set(gca,'Box', 'on','XColor', [.3 .3 .3],'YColor',[.3 .3 .3],'LineWidth', 1,'fontname','garamond','fontsize',10,'ylim',[-25 15]);
grid;
tit=label1(i,:);
title(tit,'fontname','garamond','fontsize',12,'Color', [.3 .3 .3]);
legend('VaR','Returns',0);

end

%% QUESTION 3

% UPLOAD DATASET
[price2,textdata2,raw2]=xlsread(filename1,2);

date_2=datenum(textdata2(3:end,1),'dd/mm/yyyy');
returns=log(price2(2:end,:) ./ price2(1:end-1,:));

f1=['29/12/2000';'02/01/2001';'31/12/2001'];
date_find2=datenum(f1,'dd/mm/yyyy');

%% Parameters
lambda=0.94;
T=rows(returns);
m=251;
N=T-m;
q_norm=norminv(p,0,1);

%% RiskMetrics VaR
rm_cv=NaN(T,1);
rm_cv=var(returns(1:m));
for i=2:T
rm_cv(i,1)=lambda*rm_cv(i-1,1)+(1-lambda)*returns(i-1,1).^2;
end

VaR_rm=-sqrt(rm_cv(m+1:T,1)).*q_norm;

%% GARCH VaR
[filename_ch4, pathname_ch4]=uigetfile('*.xls');
[price_ch4,textdata_ch4]=xlsread(filename_ch4,1);

date_ch4=datenum(textdata1(3:end,1),'dd/mm/yyyy');
sp_ret_ch4=log(price_ch4(2:end,3) ./ price_ch4(1:end-1,3));

par_initial(1:4,1)=[0.000005;0.1;0.5;0.85]; % par_init=[omega;alpha;theta;beta]
[param,mle_ng]=fminsearch('ngarch',par_initial,[],sp_ret_ch4);
initial=[param;10];

[fit_par,mle]=fminsearch('logL2',initial,[],sp_ret_ch4);
cond_var_mle(1,1)=var(returns(1:m,1));
for i=2:T;
    cond_var_mle(i,1)=fit_par(1,1)+fit_par(2,1)*(returns(i-1,1)-fit_par(3,1)*sqrt(cond_var_mle(i-1,1)))^2+fit_par(4,1)*cond_var_mle(i-1,1);
end
z_lev_mle=returns./sqrt(cond_var_mle);
df_mle=fit_par(5,1);
q_tstud=sqrt((df_mle-2) /df_mle)*tinv(p,df_mle);
VaR_garcht=-sqrt(cond_var_mle(m+1:T,1))*q_tstud;

%% Historical Simulation + Filtered historical simulation
garch_cv=cond_var_mle(m+1:T,1);
for k=1:N

% Historical Simulation + Interpolation

VaR_HS(k,1)=-quantile(returns(k:k+m-1,1),p);
%NB: Matlab function "quantile" assumes that the cumulative probability of
%the sorted return in position j is (j-0.5)/m. It interpolates linearly
%to find the return that accumulates exactly p.

r_hs_sort=sort(returns(k:k+m-1,1));

%NB: For the interpolation, we assume as in Matlab that the cumulative 
%prob. of the sorted return in position j is given by (j-0.5)/m. Compare
%VaR_HS with VaR_HS_int.

index(1:m)=1:m; %vector of indices from 1 to m
csum(1:m)=(index-0.5*ones(m,1))/m; %cum. probability up to each return

ind=rows(csum(csum<p)); 
if ind==0
VaR_HS_int(k,1)=-r_hs_sort(ind+1); 
else
lambda=(p-csum(ind,1))./(csum(ind+1,1)-csum(ind));   
VaR_HS_int(k,1)=-(lambda*r_hs_sort(ind+1,1)+(1-lambda)*r_hs_sort(ind,1));
end

% Filtered Historical Simulation with Interpolation
z_sort=sort(z_lev_mle(k:k+m-1,1));
if ind==0
quant(k,1)=z_sort(ind+1); 
else
quant(k,1)=(lambda*z_sort(ind+1,1)+(1-lambda)*z_sort(ind,1));
end
VaR_FHS_int(k,1)=-quant(k,1)*sqrt(garch_cv(k,1));
end
%% COMPARE VARs
f2=['02/01/2001';'01/02/2001';'01/03/2001';'02/04/2001';'01/05/2001';'01/06/2001';'02/07/2001';'01/08/2001';'04/09/2001';'01/10/2001';'01/11/2001';'03/12/2001';'31/12/2001'];
date_find3=datenum(f2,'dd/mm/yyyy');
index3=datefind(date_find3,date_2(m+1:end,:));
s=1:N;

VAR_1=[-VaR_rm*100 -VaR_garcht*100 -VaR_HS_int*100 -VaR_FHS_int*100];
label2=strvcat('1day-1%Vars using RM and GARCH vs Returns for 2001','1day-1%Vars using HS and FHS vs Returns for 2001');  
label3=strvcat('VaR\_RM','VaR\_garcht','VaR\_HS','VaR\_FHS');
figure;
for i=1:2
subplot(2,1,i)
plot(s',VAR_1(:,2*i-1:2*i));
hold on
plot(s',returns(m+1:T,1)*100,'color',[.5 0 .4]);
set(gca,'xtick',index3,'xticklabel','Jan|Feb|Mar|April|May|June|July|August|Sept|Oct|Nov|Dec|2002','xlim',[1 rows(s')]);
set(gcf,'color','w');
set(gca,'Box', 'off','XColor', [.3 .3 .3],'YColor',[.3 .3 .3],'LineWidth', 1,'fontname','garamond','fontsize',10,'ylim',[-8 8]);
ylabel('VaRs vs Returns');
xlabel('2001');
grid;
tit=label2(i,:);
title(tit,'fontname','garamond','fontsize',12,'Color', [.3 .3 .3]);
leg=label3(2*i-1:2*i,:);
legend(leg(1,:),leg(2,:),'Returns',1);
end

figure;
plot(s',-VaR_rm*100,'b',s',-VaR_garcht*100,'k',s',-VaR_HS_int*100,'g',s',-VaR_FHS_int*100,'r','linewidth',1);
hold on
plot(s',returns(m+1:T,1)*100,'color',[.5 0 .4]);
set(gca,'xtick',index3,'xticklabel','Jan|Feb|Mar|April|May|June|July|August|Sept|Oct|Nov|Dec|2002','xlim',[1 rows(s')]);
legend('VaR\_rm','VaR\_garcht','VaR\_HS','VaR\_FHS','Returns',0);
set(gcf,'color','w');
set(gca,'Box', 'off','XColor', [.3 .3 .3],'YColor',[.3 .3 .3],'LineWidth', 1,'fontname','garamond','fontsize',10,'ylim',[-8 8]);
ylabel('VaRs vs Returns');
xlabel('2001');
grid;
title('1day-1%Vars using HS, RM, GARCH-t and FHS vs Returns for 2001','fontname','garamond','fontsize',11,'Color', [.3 .3 .3]);

%% Number of violations:

index_rm=(returns(m+1:T)<-VaR_rm);
viol_rm=sum(index_rm);
index_garcht=(returns(m+1:T)<-VaR_garcht);
viol_garcht=sum(index_garcht);
index_fs=(returns(m+1:T)<-VaR_FHS_int);
viol_fs=sum(index_fs);
index_hs=(returns(m+1:T)<-VaR_HS_int);
viol_hs=sum(index_hs);

%% Display your results on the Command Windows
alpha=fit_par(2,1);
beta=fit_par(4,1);
omega=fit_par(1,1);
theta=fit_par(3,1);
df=fit_par(5,1);
disp('Table 1: QUESTION 3- Garch-t parameters.'); 
 
 fprintf('alpha ');  fprintf('%1.4f ',alpha);fprintf('\n');
 fprintf('beta  ');   fprintf('%1.4f ',beta);fprintf('\n');
 fprintf('omega ');  fprintf('%1.8f ',omega);fprintf('\n');
 fprintf('theta ');  fprintf('%1.4f ',theta);fprintf('\n');
 fprintf('\n');

 disp('Table 2: QUESTION 3- Number of violations.'); 
 
 fprintf('Risk Metrics                     '); fprintf('%1.1f' ,viol_rm);fprintf('\n');
 fprintf('GARCH-t                          '); fprintf('%1.1f ',viol_garcht);fprintf('\n');
 fprintf('Historical Simulation            '); fprintf('%1.1f ',viol_hs);fprintf('\n');
 fprintf('Filtered Historical Simulation   '); fprintf('%1.1f ',viol_hs);fprintf('\n');
 fprintf('\n');
%% QUESTION 4
hor=10;
mc=10000;

%% MC Simulation + Filtered Historical Simulation
% MC simulation
cond_var_mc=NaN(mc,hor);
cond_var_mc(:,1)=cond_var_mle(m+1,1);
ret_sim_mc=NaN(mc,hor);
z_sim_mc=random('t',df_mle,mc,1).*sqrt((df_mle-2)./df_mle);
ret_sim_mc(:,1)=z_sim_mc(:,1).*sqrt(cond_var_mc(:,1));

% Filtered Historical Simulation
ret_sim_fh=NaN(mc,hor);
cond_var_fh=NaN(mc,hor);
cond_var_fh(:,1)=cond_var_mle(m+1,1);
z_fh=z_lev_mle(1:m);
z_sim_fh=randsample(z_fh,mc,true);
ret_sim_fh(:,1)=z_sim_fh(:,1).*sqrt(cond_var_fh(:,1));

for i=2:hor
% MC simulation
cond_var_mc(:,i)=fit_par(1,1)+fit_par(2,1)*...
    (ret_sim_mc(:,i-1)-fit_par(3,1)*sqrt(cond_var_mc(:,i-1))).^2+...
    fit_par(4,1)*cond_var_mc(:,i-1);
z_sim_mc=random('t',df_mle,mc,1).*sqrt((df_mle-2)./df_mle);
ret_sim_mc(:,i)=z_sim_mc.*sqrt(cond_var_mc(:,i));

clear z_sim_mc

% Filtered Historical Simulation
cond_var_fh(:,i)=fit_par(1,1)+fit_par(2,1)*...
    (ret_sim_fh(:,i-1)-fit_par(3,1)*sqrt(cond_var_fh(:,i-1))).^2+...
    fit_par(4,1)*cond_var_fh(:,i-1);
z_sim_fh=randsample(z_fh,mc,true);
ret_sim_fh(:,i)=z_sim_fh.*sqrt(cond_var_fh(:,i));

clear z_sim_fh
end

% MC simulation
ret_cum_mc=sum(ret_sim_mc,2);
VaR_10d_mc=-quantile(ret_cum_mc,p)*100;


% Filtered Historical Simulation
ret_cum_fh=sum(ret_sim_fh,2);
VaR_10d_fh=-quantile(ret_cum_fh,p)*100;


%% RiskMetrics
VaR_10d_rm=-sqrt(10*rm_cv(m+1))*q_norm*100;

% Note: The solution for VaR RiskMetrics provided in the EFRM cd is wrong. 
% Instead of =-INV.NORM.ST(N6)*RADQ(10*E254) compute =-INV.NORM.ST(N6)*RADQ(10*D254)

%% Display your results on the Command Window
disp('Table 3: QUESTION 4 - 10day VaR on 29/12/2000.'); 
 
 fprintf('Risk Metrics   ');  fprintf('%1.2f ',VaR_10d_rm);fprintf('\n');
 fprintf('GARCH-t        ');   fprintf('%1.2f ',VaR_10d_mc);fprintf('\n');
 fprintf('FHS            ');  fprintf('%1.2f ',VaR_10d_fh);fprintf('\n');
 fprintf('\n');

