function [dyncorr]=dcc_mvgarch_for(par,y1,y2,y3,ltr12,ltr13,ltr23)

alpha=par(10,1);
beta=par(11,1);

sret1=y1;
sret2=y2;
sret3=y3;
T=rows(y1);
C=cols(y1);

Q11=NaN(T,1);
Q22=NaN(T,1);
Q33=NaN(T,1);
Q12=NaN(T,1);
Q23=NaN(T,1);
Q13=NaN(T,1);

Q11(1)=mean(sret1.*sret1);
Q22(1)=mean(sret2.*sret2);
Q33(1)=mean(sret3.*sret3);
Q12(1)=mean(sret1.*sret2);
Q23(1)=mean(sret3.*sret2);
Q13(1)=mean(sret1.*sret3);

for t=2:T
    Q11(t)= (1-alpha-beta)+alpha*(sret1(t-1).^2)+beta*Q11(t-1);
    Q22(t)= (1-alpha-beta)+alpha*(sret2(t-1).^2)+beta*Q22(t-1);
    Q33(t)= (1-alpha-beta)+alpha*(sret3(t-1).^2)+beta*Q33(t-1);
    Q12(t)= (1-alpha-beta)*ltr12+alpha*(sret1(t-1)*sret2(t-1))+beta*Q12(t-1);
    Q23(t)= (1-alpha-beta)*ltr23+alpha*(sret2(t-1)*sret3(t-1))+beta*Q23(t-1);
    Q13(t)= (1-alpha-beta)*ltr13+alpha*(sret1(t-1)*sret3(t-1))+beta*Q13(t-1);
end

rho12=Q12./sqrt(Q11.*Q22);
rho23=Q23./sqrt(Q33.*Q22);
rho13=Q13./sqrt(Q11.*Q33);

for i=1:T
dyncorr(:,:,i)=[1 rho12(i,1) rho13(1,1);rho12(i,1) 1 rho23(i,1); rho13(1,1) rho23(i,1) 1];
end

