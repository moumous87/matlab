function [y,dyncorr]=dcc_ES_3assets(x,y1,y2,y3)

ret1=y1;
ret2=y2;
ret3=y3;
R=rows(ret1);
C=cols(ret1);
Q11=NaN(R,C);
Q22=NaN(R,C);
Q33=NaN(R,C);
Q12=NaN(R,C);
Q23=NaN(R,C);
Q13=NaN(R,C);
Q11(1)=mean(ret1.*ret1);
Q22(1)=mean(ret2.*ret2);
Q33(1)=mean(ret3.*ret3);
Q12(1)=mean(ret1.*ret2);
Q23(1)=mean(ret3.*ret2);
Q13(1)=mean(ret1.*ret3);
for i=2:R
    Q11(i)=(1-x)*(ret1(i-1).^2)+x*Q11(i-1);
    Q22(i)=(1-x)*(ret2(i-1).^2)+x*Q22(i-1);
    Q33(i)=(1-x)*(ret3(i-1).^2)+x*Q33(i-1);
    Q12(i)=(1-x)*(ret1(i-1)*ret2(i-1))+x*Q12(i-1);
    Q23(i)=(1-x)*(ret2(i-1)*ret3(i-1))+x*Q23(i-1);
    Q13(i)=(1-x)*(ret1(i-1)*ret3(i-1))+x*Q13(i-1);

end
rho12=Q12./sqrt(Q11.*Q22);
rho23=Q23./sqrt(Q33.*Q22);
rho13=Q13./sqrt(Q11.*Q33);

for i=1:R
dyncorr(:,:,i)=[1 rho12(i,1) rho13(1,1);rho12(i,1) 1 rho23(i,1); rho13(1,1) rho23(i,1) 1];
z=[ret1(i) ret2(i) ret3(i)];
Lct(i)=log(det(dyncorr(:,:,i)))+z*inv(dyncorr(:,:,i))*z';
end

y=-0.5*sum(Lct);



