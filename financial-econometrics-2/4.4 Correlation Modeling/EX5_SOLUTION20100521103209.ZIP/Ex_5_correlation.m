clear, clc, close all

path(path,'C:\Program Files\MATLAB\R2009a\toolbox\lesage\util');
path(path,'C:\Program Files\MATLAB\R2009a\toolbox\UCSD_GARCH');
path(path,'C:\Program Files\MATLAB\R2009a\toolbox\UCSD_GARCH\MV Garch\Correlation MVGarch');
path(path,'C:\Program Files\MATLAB\R2009a\toolbox\UCSD_GARCH\Garch');

%% CORRELATION MODELING (EFRM CH.4)

% UPLOAD DATASET
[filename,pathname]=uigetfile('*.xls');
[data,textdata,raw]=xlsread(filename,1);

date=datenum(textdata(3:end,1),'dd/mm/yyyy');
f=['02/01/2006';'30/06/2006';'29/12/2006';'29/06/2007';'31/12/2007';'30/06/2008';'02/02/2009';'01/02/2010'];
date_find=datenum(f,'dd/mm/yyyy');
index=datefind(date_find,date);
first=datefind(date_find(1,1),date);
last=datefind(date_find(5,1),date); % End of  estimation smpl
final=datefind(date_find(6,1),date); % End of VaRs calculation
%% QUESTION 1

% Data transformation and currency conversion
prices=data(:,[18:22]);
returns=100*log(prices(2:end,:)./(prices(1:end-1,:)));
ret_eubp=returns(:,1);
ret_euusd=returns(:,2);
ret_msci_eu=returns(:,3);
ret_msci_usa=returns(:,4)-ret_euusd;
ret_msci_uk=returns(:,5)-ret_eubp;

% PLOT RETURNS
RET=[ret_msci_eu ret_msci_usa ret_msci_uk];

t=first:last;

figure;
plot(t', ret_msci_eu(first:last),'g',t',ret_msci_uk(first:last),'m',t',ret_msci_usa(first:last),'b');
set(gca,'fontname','garamond','fontsize',10);
set(gca,'xtick',index,'xticklabel','Jan2006|June2006|Dec2006|June2007|Dec2007','xlim',[1 rows(t')+1]);
xlabel('Time');
ylabel('Portfolio returns');
title('Daily Returns in Euro','fontname','garamond','fontsize',12,'Color', [.3 .3 .3]);
set(gcf,'color','w');
set(gca,'Box', 'off', 'TickDir', 'out', 'TickLength', [.02 .02],'XMinorTick', 'off','YMinorTick', 'off','XColor', [.3 .3 .3],'YColor',[.3 .3 .3],'LineWidth', 1, 'FontName', 'Garamond','fontsize',10);
legend('EU','UK','USA');

%% QUESTION N.2

Cov_matrix=cov(RET(first:last,:));
Corr_matrix=corr(RET(first:last,:));

%% QUESTION 3
w=[1/3;1/3;1/3];
port_ret=[ret_msci_eu,ret_msci_usa,ret_msci_uk]*w;

p=0.01;
VaR_port_unc=-ones(final-last,1)*norminv(p,0,sqrt(w'*Cov_matrix*w));
VaR_msci_eu=-ones(final-last,1)*norminv(p,0,sqrt(Cov_matrix(1,1)));
VaR_msci_usa=-ones(final-last,1)*norminv(p,0,sqrt(Cov_matrix(2,2)));
VaR_msci_uk=-ones(final-last,1)*norminv(p,0,sqrt(Cov_matrix(3,3)));
VaR_sum=[VaR_msci_eu, VaR_msci_usa, VaR_msci_uk]*w;

%% QUESTION 4
RET_all=[ret_msci_eu ret_msci_usa ret_msci_uk port_ret];
label=strvcat('EU','USA','UK','Port');

%% GARCH MODELS
for i=1:4
spec=garchset('Distribution','Gaussian','VarianceModel','GARCH','P',1,'Q',1);
[coeff,errors,llf,innovation,sigma,summary]=garchfit(spec,RET_all(first:last,i));
param(1:3,1)=[coeff.K,coeff.ARCH,coeff.GARCH];
[mle,z_garch,cond_var]=garch(param,RET_all(last:final-1,i));
%Alternative way of obtaining conditional sds:
%spec=garchset(spec,'C',0,'K',coeff.K,'ARCH',coeff.ARCH,'GARCH',coeff.GARCH)
%[innov,sigmas,llf]=garchinfer(spec,RET_all(last:final-1,i));
disp(['GARCH PARAMETERS FOR:' label(i,:)]);
garchdisp(coeff,errors);
var1=strcat('condvar_',label(i,:));
assignin('base',var1,cond_var);
var2=strcat('coeff_',label(i,:));
assignin('base',var2,coeff);
var3=strcat('z_',label(i,:));
assignin('base',var3,z_garch);
var4=strcat('sigma_',label(i,:));
assignin('base',var4,sigma);
end

%% Conditional Volatilities
vol_eu=sqrt(condvar_EU);
vol_usa=sqrt(condvar_USA);
vol_uk=sqrt(condvar_UK);
vol_port=sqrt(condvar_Port);

%% GARCH-VaRs:
VaR_garch_usa=-vol_usa*norminv(p,0,1);
VaR_garch_eu=-vol_eu*norminv(p,0,1);
VaR_garch_uk=-vol_uk*norminv(p,0,1);
VaR_garch_port=-vol_port*norminv(p,0,1);

%% Plot VaRs-GARCH
f1=['01/01/2008';'01/02/2008';'03/03/2008';'01/04/2008';'01/05/2008';'02/06/2008';'30/06/2008'];
date_find_1=datenum(f1,'dd/mm/yyyy');
index_1=datefind(date_find_1,date(last+1:final,1));

s=1:final-last;
figure;
plot(s',-VaR_garch_eu,'g',s',-VaR_garch_usa,'b',s',-VaR_garch_uk,'m',s',-VaR_garch_port,'c');
hold on
plot(s', port_ret(last+1:final,1),'color',[0.3 0 0.3]);
set(gca,'fontname','garamond','fontsize',10);
set(gca,'xtick',index_1,'xticklabel','Jan2008|Feb2008|Mar2008|Apr2008|May2008|Jun2008|July2008','xlim',[1 rows(s')]);
xlabel('Time');
ylabel('VaRs vs Returns');
title('GARCH VaRs','fontname','garamond','fontsize',12,'Color', [.3 .3 .3]);
set(gcf,'color','w');
set(gca,'Box', 'off', 'TickDir', 'out', 'TickLength', [.02 .02],'XMinorTick', 'off','YMinorTick', 'off','XColor', [.3 .3 .3],'YColor',[.3 .3 .3],'LineWidth', 1, 'FontName', 'Garamond','fontsize',10);
legend('EU','USA','UK','Portfolio','Returns',0);
%% Standardized returns
ret_std_EU=ret_msci_eu(first:last,1)./sigma_EU;
ret_std_USA=ret_msci_usa(first:last,1)./sigma_USA;
ret_std_UK=ret_msci_uk(first:last,1)./sigma_UK;

%% CCC-VaRs 
Gamma=corr([ret_std_EU ret_std_USA ret_std_UK]);
for i=1:final-last
D=diag([vol_eu(i) vol_usa(i) vol_uk(i)]);
VaR_CCC(i,1)=-norminv(p,0,sqrt(w'*D*Gamma*D*w));
end

%% Unconditional Covariance VaR vs CCC-VaR
s=1:final-last;

figure;
plot(s',-VaR_port_unc,'b',s',-VaR_CCC,'m');
hold on
plot(s', port_ret(last+1:final,1),'color',[0.3 0 0.3]);
set(gca,'fontname','garamond','fontsize',10);
set(gca,'xtick',index_1,'xticklabel','Jan2008|Feb2008|Mar2008|Apr2008|May2008|Jun2008|July2008','xlim',[1 rows(s')]);
xlabel('Time');
ylabel('VaRs vs Returns');
title('Unc Cov vs CCC VaR','fontname','garamond','fontsize',12,'Color', [.3 .3 .3]);
set(gcf,'color','w');
set(gca,'Box', 'off', 'TickDir', 'out', 'TickLength', [.02 .02],'XMinorTick', 'off','YMinorTick', 'off','XColor', [.3 .3 .3],'YColor',[.3 .3 .3],'LineWidth', 1, 'FontName', 'Garamond','fontsize',10);
legend('Uncond VaR','CCC VaR','Returns',0);

%% QUESTION 5
% Exponential Smoothing Estimate
MM=10000;
options  =  optimset('MaxIter',MM,'MaxFunEvals',MM);
%parm=[0.4 0.5 0.7 0.9];
parm=0.7;
%for j=1:4
for j=1:1
[lambda,mle]=fminsearch('dcc_ES_3assets',parm(1,j),options,ret_std_EU,ret_std_USA,ret_std_UK);
lambda_fit(j,1)=lambda;
fprintf('Final lambda: ');
fprintf('%5.3f ',lambda);
fprintf('\n');
end


%% Construct DCC Exponential Smoothing Var
[mle_dyn,Gamma_dyn]=dcc_ES_3assets(lambda_fit,ret_std_EU, ret_std_USA, ret_std_UK);
for i=1:final-last
D=diag([vol_eu(i) vol_usa(i) vol_uk(i)]);
VaR_DCC_es(i,1)=-norminv(p,0,sqrt(w'*D*Gamma_dyn(:,:,i)*D*w));
end

%% CCC VaR vs DCC-VaR
s=1:final-last;
figure;
plot(s',-VaR_CCC,'b',s',-VaR_DCC_es,'m');
hold on
plot(s', port_ret(last+1:final,1),'color',[0.3 0 0.3]);
set(gca,'fontname','garamond','fontsize',10);
set(gca,'xtick',index_1,'xticklabel','Jan2008|Feb2008|Mar2008|Apr2008|May2008|Jun2008|July2008','xlim',[1 rows(s')]);
xlabel('Time');
ylabel('VaRs vs Returns');
title('CCC vs DCC VaR','fontname','garamond','fontsize',12,'Color', [.3 .3 .3]);
set(gcf,'color','w');
set(gca,'Box', 'off', 'TickDir', 'out', 'TickLength', [.02 .02],'XMinorTick', 'off','YMinorTick', 'off','XColor', [.3 .3 .3],'YColor',[.3 .3 .3],'LineWidth', 1, 'FontName', 'Garamond','fontsize',10);
legend('CCC','DCC','Returns',0);
%% QUESTION 6

% DCC-GARCH - estimation
[par_dcc, loglikelihood, Ht, Qt,  stdresid, likelihoods, stderrors, A,B, jointscores]=...
    dcc_mvgarch([ret_msci_eu(first:last,1) ret_msci_usa(first:last,1) ret_msci_uk(first:last,1)],1,1,1,1);

% Parameters:
%garch_p: matrix with the single series GARCH parameters
%each row= parameters of one series in order: omega, alpha, beta

garch_p=[par_dcc(1,1) par_dcc(2,1) par_dcc(3,1); par_dcc(4,1) par_dcc(5,1) par_dcc(6,1); par_dcc(7,1) par_dcc(8,1), par_dcc(9,1)];

% Returns
RET=RET_all(last:final-1,1:3);

% Returns standardization:
T=rows(RET);
sigma2=NaN(T,3);
for i=1:3 
    sigma2(1,i)=garch_p(i,1)/(1-garch_p(i,2)-garch_p(i,3));
    for t=2:T %over time
        sigma2(t,i)=garch_p(i,1)+garch_p(i,2)*RET(t-1,i)^2+garch_p(i,3)*sigma2(t-1,i);
    end
end    

z=RET./sqrt(sigma2);

sret_eu=z(:,1);
sret_usa=z(:,2);
sret_uk=z(:,3);

% Gamma matrix:
[Gamma_dyn_garch]=dcc_mvgarch_for(par_dcc,sret_eu,sret_usa,sret_uk,Corr_matrix(1,2),Corr_matrix(1,3),Corr_matrix(2,3));

% Conditional volatilities for D matrix:

VOL=sqrt(sigma2);

% VaR DCC-GARCH
for i=1:final-last
Dt=diag([VOL(i,1) VOL(i,2) VOL(i,3)]);
VaR_DCC_garch(i,1)=-norminv(p,0,sqrt(w'*Dt*Gamma_dyn_garch(:,:,i)*Dt*w));
rho12(i,1) = Gamma_dyn_garch(1,2,i);
rho13(i,1) = Gamma_dyn_garch(1,3,i);
rho23(i,1) = Gamma_dyn_garch(2,3,i);
end

% Plot Dynamic Correlations
figure;
plot([rho12 rho23])
set(gca,'fontname','garamond','fontsize',10);
set(gca,'xtick',index_1,'xticklabel','Jan2008|Feb2008|Mar2008|Apr2008|May2008|Jun2008|July2008','xlim',[1 rows(s')]);
xlabel('Time');
ylabel('Dynamic Correlation');
title('Dynamic Correlations','fontname','garamond','fontsize',12,'Color', [.3 .3 .3]);
set(gcf,'color','w');
set(gca,'Box', 'off', 'TickDir', 'out', 'TickLength', [.02 .02],'XMinorTick', 'off','YMinorTick', 'off','XColor', [.3 .3 .3],'YColor',[.3 .3 .3],'LineWidth', 1, 'FontName', 'Garamond','fontsize',10);
legend('Corr EU-USA','Corr USA-UK',0);

% Compare VaRs
s=1:final-last;
figure;
plot(s',-VaR_port_unc,'r',s',-VaR_CCC,'b',s',-VaR_DCC_es,'m',s',-VaR_DCC_garch,'c');
hold on
plot(s', port_ret(last+1:final,1),'color',[0.3 0 0.3]);
set(gca,'fontname','garamond','fontsize',10);
set(gca,'xtick',index_1,'xticklabel','Jan2008|Feb2008|Mar2008|Apr2008|May2008|Jun2008|July2008','xlim',[1 rows(s')]);
xlabel('Time');
ylabel('VaRs vs Returns');
title('GARCH VaRs','fontname','garamond','fontsize',12,'Color', [.3 .3 .3]);
set(gcf,'color','w');
set(gca,'Box', 'off', 'TickDir', 'out', 'TickLength', [.02 .02],'XMinorTick', 'off','YMinorTick', 'off','XColor', [.3 .3 .3],'YColor',[.3 .3 .3],'LineWidth', 1, 'FontName', 'Garamond','fontsize',10);
legend('Unconditional','CCC','ES-DCC','GARCH-DCC','Returns',0);









