%CHAPTER 3

%UPLOAD DATASET FOR CHAPTER 3

[filename,pathname]=uigetfile('*.xls');
[prices,textdata,raw] = xlsread(filename,1);

%--------------------------------------------------------------------------

%QUESTION N.1


date=datenum(textdata(2:end,1),'dd/mm/yyyy');
f=['03/01/2005';'31/12/2008'];
date_find=datenum(f,'dd/mm/yyyy');
ind=datefind(date_find,date);
prices=prices(ind(1):ind(2),end-4:end);

returns= 100*log(prices(2:end,:)./prices(1:end-1,:));
returns_eubp=returns(:,1);
returns_euusd=returns(:,2);
returns_msci_eu=returns(:,3);
returns_msci_usa=returns(:,4)+returns_euusd;
returns_msci_uk=returns(:,5)+returns_eubp;

%plot the results

figure
plot(returns_msci_eu,'r');
hold on
plot(returns_msci_usa,'b');
plot(returns_msci_uk,'g');
h = legend('MSCI EU','MSCI US','MSCI UK',2);
hold off
%--------------------------------------------------------------------------

%QUESTION N.2

Cov_matrix=cov([returns_msci_eu,returns_msci_usa,returns_msci_uk]);
Corr_matrix=corr([returns_msci_eu,returns_msci_usa,returns_msci_uk]);
%--------------------------------------------------------------------------

%QUESTION N.3

alpha=0.01;
weights=ones(3,1)./3;
variance_stocks=diag(Cov_matrix);
Var_port_unc=norminv(alpha,0,sqrt(weights'*Cov_matrix*weights));
Var_msci_eu=norminv(alpha,0,sqrt(variance_stocks(1)));
Var_msci_us=norminv(alpha,0,sqrt(variance_stocks(2)));
Var_msci_uk=norminv(alpha,0,sqrt(variance_stocks(3)));
Var_port_sum=[Var_msci_eu,Var_msci_us,Var_msci_uk]*weights;
%--------------------------------------------------------------------------

%QUESTION N.4

%GARCH(1,1) estimation for MSCI EU
spec=garchset('Distribution','Gaussian','VarianceModel','GARCH','P',1,'Q',1,'K',0.00005,'GARCH',0.85,'ARCH',0.1);
[coeff_eu,errors,llf,innovation,ht_eu,summary]=garchfit(spec,returns_msci_eu);
%[parameters_eu, likelihood, ht_eu, stderrors, robustSE, scores, grad] = garchpq(returns_msci_eu, 1 , 1 , [0.00005; 0.1; 0.85],[]);

%GARCH(1,1) estimation for MSCI USA
spec=garchset('Distribution','Gaussian','VarianceModel','GARCH','P',1,'Q',1,'K',0.00005,'GARCH',0.85,'ARCH',0.1);
[coeff_us,errors,llf,innovation,ht_us,summary]=garchfit(spec,returns_msci_usa);
%[parameters_us, likelihood, ht_us, stderrors, robustSE, scores, grad] = garchpq(returns_msci_usa, 1 , 1 , [0.00005; 0.1; 0.85],[]);

%GARCH(1,1) estimation for MSCI UK
spec=garchset('Distribution','Gaussian','VarianceModel','GARCH','P',1,'Q',1,'K',0.00005,'GARCH',0.85,'ARCH',0.1);
[coeff_uk,errors,llf,innovation,ht_uk,summary]=garchfit(spec,returns_msci_uk);
%[parameters_uk, likelihood, ht_uk, stderrors, robustSE, scores, grad] = garchpq(returns_msci_uk, 1 , 1 , [0.00005; 0.1; 0.85],[]);

%Standardized the returns
std_returns_eu=returns_msci_eu./sqrt(ht_eu);
std_returns_us=returns_msci_usa./sqrt(ht_us);
std_returns_uk=returns_msci_uk./sqrt(ht_uk);
Corr_std=corr([std_returns_eu,std_returns_us,std_returns_uk]);

%VaR with CCC Model
variance=diag(sqrt([ht_eu(end),ht_us(end),ht_uk(end)]));
Var_CCC=norminv(alpha,0,sqrt(weights'*variance*Corr_std*variance*weights));
%--------------------------------------------------------------------------

%QUESTION N.5

%Estimation of ES for standardising the returns
parm=[0.1];
fun=@objfunction;
options=optimset('LargeScale','off');
x1=fminunc(fun,parm,options,returns_msci_eu);
x2=fminunc(fun,parm,options,returns_msci_usa);

%ESPONENTIAL SMOOTHING forecast
cond_var_es_eu(1,1)=var(returns_msci_eu);
for i=2:ind(2)-1
cond_var_es_eu(i,1)=(1-x1)*returns_msci_eu(i-1,1).^2+x1*cond_var_es_eu(i-1,1);
end
cond_std_es_eu=sqrt(cond_var_es_eu);

cond_var_es_usa(1,1)=var(returns_msci_usa);
for i=2:ind(2)-1
cond_var_es_usa(i,1)=(1-x2)*returns_msci_usa(i-1,1).^2+x2*cond_var_es_usa(i-1,1);
end
cond_std_es_usa=sqrt(cond_var_es_usa);

%Standardizing returns
ret_std_eu=returns_msci_eu./cond_std_es_eu;
ret_std_usa=returns_msci_usa./cond_std_es_usa;

%Estimate lambda
parm=[0.5];
fun=@dcc_es;
options=optimset('LargeScale','off');
%x3=fminunc(fun,parm,options,ret_std_eu,ret_std_usa);
x = maxlik(fun,parm,[],ret_std_eu,ret_std_usa);
x3=x.b;

%Estimate Var
variance_es=diag([cond_std_es_eu(end),cond_std_es_usa(end)]);
RO=dcc_es_out(x3,ret_std_eu, ret_std_usa);
weights2=[0.5;0.5];
Var_DCC_es=norminv(alpha,0,sqrt(weights2'*variance_es*RO*variance_es*weights2));
%--------------------------------------------------------------------------

%QUESTION N.6


[parameters, loglikelihood, Ht, Qt,  stdresid, likelihoods, stderrors, A,B, jointscores]=dcc_mvgarch([returns_msci_eu,returns_msci_usa,returns_msci_uk],1,1,[],[]);
Cov_dcc=Ht(:,:,end);
Var_DCC_garch=norminv(alpha,0,sqrt(weights'*Cov_dcc*weights));





