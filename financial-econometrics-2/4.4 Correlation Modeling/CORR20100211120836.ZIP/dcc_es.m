function y=dcc_es(x,y1,y2)

ret1=y1;
ret2=y2;
R=rows(ret1);
C=cols(ret1);
Q11=NaN(R,C);
Q22=NaN(R,C);
Q12=NaN(R,C);
Q11(1)=1;
Q22(1)=1;
Q12(1)=mean(ret1.*ret2);
for i=2:R
    Q11(i)=(1-x)*(ret1(i-1).^2)+x*Q11(i-1);
    Q22(i)=(1-x)*(ret2(i-1).^2)+x*Q22(i-1);
    Q12(i)=(1-x)*(ret1(i-1)*ret2(i-1))+x*Q12(i-1);
end
rho=Q12./sqrt(Q11.*Q22);

y=sum(log(abs(1-rho.^2))+(ret1.^2+ret2.^2-2*rho.*ret1.*ret2)./(1-rho.^2));