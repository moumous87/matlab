**********READ ME**********************************************************************************

The dataset is the xls file.


In order to use the scripts (SolutionMatlab_1):

1. Add to the path all the functions included into the zip file;
2. Be sure to have the optimization, statistics and econometrics toolboxes in your Matlab license.
3. SOme routines may require the Spacial Econometrics Toolbox developed by LeSage.
****************************************************************************************************